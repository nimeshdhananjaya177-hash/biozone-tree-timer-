import React, { useState, useEffect, useRef } from 'react';
import { NavTab, TimeOfDay, PlantedObject, FocusSession } from './types';
import { loadState, saveState, INITIAL_STATE } from './utils/storage';
import { getDeviceTimeOfDay, getTimeThemeDetails } from './utils/timeOfDay';
import { sound } from './utils/audio';
import { TREE_SPECIES_MAP } from './data/trees';
import { Header } from './components/Header';
import { FocusScreen } from './components/FocusScreen';
import { ForestScreen } from './components/ForestScreen';
import { ShopScreen } from './components/ShopScreen';
import { HistoryScreen } from './components/HistoryScreen';
import { BottomNav } from './components/BottomNav';
import { DownloadPackageModal } from './components/DownloadPackageModal';
import { OfflineIndicator } from './components/OfflineIndicator';

export default function App() {
  // Main persistent state
  const [state, setState] = useState(() => loadState());
  const [currentTab, setCurrentTab] = useState<NavTab>('focus');
  const [timeOfDay, setTimeOfDay] = useState<TimeOfDay>(() => getDeviceTimeOfDay());
  const [statusText, setStatusText] = useState('Ready to Focus');
  const [celebrationToast, setCelebrationToast] = useState<{ title: string; subtitle: string } | null>(null);
  const [placementRequest, setPlacementRequest] = useState<{ kind: 'tree' | 'decoration'; itemId: string } | null>(null);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [newlyPlantedId, setNewlyPlantedId] = useState<string | null>(null);

  // Sync sound engine
  useEffect(() => {
    sound.setEnabled(state.soundEnabled);
  }, [state.soundEnabled]);

  // Persist state changes
  useEffect(() => {
    saveState(state);
  }, [state]);

  // Real-time automatic theme switcher checking device clock
  useEffect(() => {
    const checkTime = () => {
      const nowTime = getDeviceTimeOfDay();
      setTimeOfDay(nowTime);
    };

    checkTime();
    const interval = setInterval(checkTime, 15000); // check every 15s
    return () => clearInterval(interval);
  }, []);

  // Calculate dynamic expanding island size:
  // Starts at 145px base, expanding gradually by +14px for every tree and +7px for every decoration
  const treeCount = state.plantedObjects.filter((o) => o.kind === 'tree').length;
  const decorCount = state.plantedObjects.filter((o) => o.kind === 'decoration').length;
  const dynamicIslandRadius = 145 + treeCount * 14 + decorCount * 7;

  // Algorithm to find an available space on the island for automatic tree sprouting
  const findAvailableSpaceOnIsland = (existing: PlantedObject[]): { x: number; y: number } => {
    if (existing.length === 0) {
      return { x: 0, y: 0 };
    }

    let bestCandidate = { x: 0, y: 0 };
    let maxMinDistance = -1;

    // Test 64 distributed candidates along a golden-spiral polar distribution
    const candidateCount = 64;
    for (let i = 0; i < candidateCount; i++) {
      const angle = i * 2.399963; // golden angle in radians (~137.5 deg)
      const r = Math.sqrt((i + 1) / candidateCount) * 64; // radius 0 to 64%
      const candX = Math.round(Math.cos(angle) * r);
      const candY = Math.round(Math.sin(angle) * r);

      let minDistanceToAny = Infinity;
      for (const obj of existing) {
        const dx = candX - obj.x;
        const dy = candY - obj.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < minDistanceToAny) {
          minDistanceToAny = dist;
        }
      }

      if (minDistanceToAny > maxMinDistance) {
        maxMinDistance = minDistanceToAny;
        bestCandidate = { x: candX, y: candY };
      }
    }

    // If existing spots are tightly packed, place in newly expanding perimeter
    if (maxMinDistance < 15) {
      const angle = Math.random() * Math.PI * 2;
      const r = 60 + Math.random() * 8;
      return {
        x: Math.round(Math.cos(angle) * r),
        y: Math.round(Math.sin(angle) * r),
      };
    }

    // Add slight organic jitter (+/- 2%) so trees settle naturally
    const jitterX = (Math.random() - 0.5) * 3;
    const jitterY = (Math.random() - 0.5) * 3;
    return {
      x: Math.round(Math.max(-68, Math.min(68, bestCandidate.x + jitterX))),
      y: Math.round(Math.max(-68, Math.min(68, bestCandidate.y + jitterY))),
    };
  };

  // Handle successful session completion: automatically plants tree in My Forest with zero manual intervention
  const handleSessionComplete = (durationMinutes: number, treeId: string) => {
    const species = TREE_SPECIES_MAP[treeId];
    const treeName = species?.name || 'Tree';
    const coinsEarned = durationMinutes + 5;
    const xpEarned = durationMinutes * 2;
    const newXp = state.xp + xpEarned;
    const newLevel = Math.floor(newXp / 100) + 1;

    const newSession: FocusSession = {
      id: `sess-${Date.now()}`,
      timestamp: Date.now(),
      dateStr: new Date().toISOString().slice(0, 10),
      durationMinutes,
      coinsEarned,
      xpEarned,
      treeId,
    };

    // Calculate an organic available space on the island so the new tree doesn't overlap
    const { x: autoX, y: autoY } = findAvailableSpaceOnIsland(state.plantedObjects);

    const newTreeObjId = `tree-${Date.now()}`;
    const newPlantedTree: PlantedObject = {
      id: newTreeObjId,
      kind: 'tree',
      itemId: treeId,
      x: autoX,
      y: autoY,
      scale: 1,
      rotation: Math.floor(Math.random() * 360),
      plantedAt: Date.now(),
      isSprouting: true,
    };

    setNewlyPlantedId(newTreeObjId);

    setState((prev) => ({
      ...prev,
      coins: prev.coins + coinsEarned,
      xp: newXp,
      level: newLevel,
      plantedObjects: [...prev.plantedObjects, newPlantedTree],
      sessions: [newSession, ...prev.sessions],
    }));

    // Step 1: Initial feedback that the plant is mature and automatically planting itself
    setCelebrationToast({
      title: `🌱 ${treeName} Harvested!`,
      subtitle: `Transporting to your floating island in My Forest…`,
    });

    // Step 2: Automatically navigate to 'My Forest' section without any manual intervention!
    setTimeout(() => {
      setCurrentTab('forest');
      setCelebrationToast({
        title: `🌳 ${treeName} Planted on Floating Island!`,
        subtitle: `+${coinsEarned} Coins • +${xpEarned} XP • Island auto-expanded to ${dynamicIslandRadius + 14}m`,
      });
      sound.playPlant();
    }, 1100);

    // Fade the newly planted highlight badge after 8.5 seconds
    setTimeout(() => {
      setNewlyPlantedId(null);
    }, 8500);

    setTimeout(() => {
      setCelebrationToast(null);
    }, 5500);
  };

  const handleUnlockTree = (treeId: string, cost: number) => {
    if (state.coins < cost || state.unlockedTrees.includes(treeId)) return;
    setState((prev) => ({
      ...prev,
      coins: prev.coins - cost,
      unlockedTrees: [...prev.unlockedTrees, treeId],
    }));
  };

  const handleBuyDecoration = (decorId: string, cost: number) => {
    if (state.coins < cost) return;
    setState((prev) => ({
      ...prev,
      coins: prev.coins - cost,
      purchasedDecorations: {
        ...prev.purchasedDecorations,
        [decorId]: (prev.purchasedDecorations[decorId] || 0) + 1,
      },
    }));
  };

  const handlePlaceObject = (newObj: PlantedObject) => {
    setState((prev) => {
      const nextPlaced = { ...prev.placedDecorationsCount };
      if (newObj.kind === 'decoration') {
        nextPlaced[newObj.itemId] = (nextPlaced[newObj.itemId] || 0) + 1;
      }
      return {
        ...prev,
        plantedObjects: [...prev.plantedObjects, newObj],
        placedDecorationsCount: nextPlaced,
      };
    });

    setCelebrationToast({
      title: 'Planted on Island & Expanded! 🌿',
      subtitle: `Island automatically expanded to ${dynamicIslandRadius + (newObj.kind === 'tree' ? 14 : 7)}m`,
    });
    setTimeout(() => setCelebrationToast(null), 3800);
  };

  const handleRemoveObject = (id: string) => {
    setState((prev) => {
      const target = prev.plantedObjects.find((p) => p.id === id);
      const nextPlaced = { ...prev.placedDecorationsCount };
      if (target && target.kind === 'decoration') {
        nextPlaced[target.itemId] = Math.max(0, (nextPlaced[target.itemId] || 0) - 1);
      }
      return {
        ...prev,
        plantedObjects: prev.plantedObjects.filter((p) => p.id !== id),
        placedDecorationsCount: nextPlaced,
      };
    });
  };

  const handleUpdateObjectScale = (id: string, newScale: number) => {
    setState((prev) => ({
      ...prev,
      plantedObjects: prev.plantedObjects.map((obj) =>
        obj.id === id ? { ...obj, scale: Math.max(0.4, Math.min(2.0, newScale)) } : obj
      ),
    }));
  };

  const theme = getTimeThemeDetails(timeOfDay);

  return (
    <div
      className="relative min-h-screen w-full flex flex-col font-sans transition-colors duration-1000 overflow-hidden"
      style={{
        background: theme.skyBg,
      }}
    >
      {/* Real-time Offline Connectivity Status */}
      <OfflineIndicator />

      {/* Background Ambience / Subtle Sunbeam */}
      {theme.sunbeam && (
        <div
          className="absolute -top-32 -left-32 w-96 h-96 rounded-full pointer-events-none opacity-40 blur-3xl"
          style={{ background: 'radial-gradient(circle, rgba(255,245,210,0.8) 0%, transparent 70%)' }}
        />
      )}

      {/* Main App Header with Heading at the Very Top */}
      <Header
        coins={state.coins}
        xp={state.xp}
        level={state.level}
        timeOfDay={timeOfDay}
        soundEnabled={state.soundEnabled}
        onToggleSound={() =>
          setState((prev) => ({ ...prev, soundEnabled: !prev.soundEnabled }))
        }
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
        statusText={statusText}
      />

      {/* Active Tab Screen */}
      <main className="flex-1 flex flex-col w-full relative overflow-hidden">
        {currentTab === 'focus' && (
          <FocusScreen
            selectedDuration={state.selectedDuration}
            onDurationChange={(mins) =>
              setState((prev) => ({ ...prev, selectedDuration: mins }))
            }
            selectedTreeId={state.selectedTreeId}
            onSelectTree={(tId) =>
              setState((prev) => ({ ...prev, selectedTreeId: tId }))
            }
            unlockedTrees={state.unlockedTrees}
            onSessionComplete={handleSessionComplete}
            onSessionCancel={() => {}}
            onStatusChange={setStatusText}
            onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
          />
        )}

        {currentTab === 'forest' && (
          <ForestScreen
            plantedObjects={state.plantedObjects}
            islandRadius={dynamicIslandRadius}
            timeOfDay={timeOfDay}
            unlockedTrees={state.unlockedTrees}
            purchasedDecorations={state.purchasedDecorations}
            placedDecorationsCount={state.placedDecorationsCount}
            onPlaceObject={handlePlaceObject}
            onRemoveObject={handleRemoveObject}
            onUpdateObjectScale={handleUpdateObjectScale}
            onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
            initialPlacementItem={placementRequest}
            onClearInitialPlacement={() => setPlacementRequest(null)}
            newlyPlantedId={newlyPlantedId}
          />
        )}

        {currentTab === 'shop' && (
          <ShopScreen
            coins={state.coins}
            unlockedTrees={state.unlockedTrees}
            purchasedDecorations={state.purchasedDecorations}
            placedDecorationsCount={state.placedDecorationsCount}
            onUnlockTree={handleUnlockTree}
            onBuyDecoration={handleBuyDecoration}
            onInitiatePlacement={(item) => {
              setPlacementRequest(item);
              setCurrentTab('forest');
            }}
          />
        )}

        {currentTab === 'history' && (
          <HistoryScreen
            state={state}
            onRestoreBackup={(restoredState) => setState(restoredState)}
            onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
          />
        )}
      </main>

      {/* Celebration Floating Toast */}
      {celebrationToast && (
        <div className="fixed top-20 inset-x-4 flex justify-center z-50 pointer-events-none animate-bounce-short">
          <div className="px-5 py-3 rounded-2xl bg-emerald-900/90 backdrop-blur-md text-white border border-emerald-400/50 shadow-2xl flex flex-col items-center text-center">
            <span className="text-xs font-black tracking-wide text-emerald-200">
              {celebrationToast.title}
            </span>
            <span className="text-[11px] font-medium text-emerald-100/90 mt-0.5">
              {celebrationToast.subtitle}
            </span>
          </div>
        </div>
      )}

      {/* Bottom Tab Navigation */}
      <BottomNav currentTab={currentTab} onTabChange={setCurrentTab} />

      {/* Complete Standalone Offline Sanctuary Package Modal */}
      <DownloadPackageModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        state={state}
        onRestoreState={(newState) => setState(newState)}
      />
    </div>
  );
}
