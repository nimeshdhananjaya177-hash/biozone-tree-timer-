import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ZoomIn, ZoomOut, RotateCcw, PlusCircle, Check, X, Compass, Trash2, ArrowLeft, ArrowRight, Play, Pause, Sparkles, Archive } from 'lucide-react';
import { PlantedObject, TimeOfDay } from '../types';
import { TreeArtwork, TREE_SPECIES_MAP } from '../data/trees';
import { DecorationArtwork, DECORATIONS_MAP } from '../data/decorations';
import { getTimeThemeDetails } from '../utils/timeOfDay';
import { sound } from '../utils/audio';
import { getProportionalAssetInfo } from '../utils/proportionalScaling';

interface ForestScreenProps {
  plantedObjects: PlantedObject[];
  islandRadius: number;
  timeOfDay: TimeOfDay;
  unlockedTrees: string[];
  purchasedDecorations: Record<string, number>;
  placedDecorationsCount: Record<string, number>;
  onPlaceObject: (newObj: PlantedObject) => void;
  onRemoveObject: (id: string) => void;
  onUpdateObjectScale?: (id: string, newScale: number) => void;
  onOpenDownloadModal?: () => void;
  initialPlacementItem?: { kind: 'tree' | 'decoration'; itemId: string } | null;
  onClearInitialPlacement?: () => void;
  newlyPlantedId?: string | null;
}

// Fixed isometric elevation pitch: permanently locks vertical tilt to prevent any vertical flips
const FIXED_ISOMETRIC_PITCH = 48;

export const ForestScreen: React.FC<ForestScreenProps> = ({
  plantedObjects,
  islandRadius,
  timeOfDay,
  unlockedTrees,
  purchasedDecorations,
  placedDecorationsCount,
  onPlaceObject,
  onRemoveObject,
  onUpdateObjectScale,
  onOpenDownloadModal,
  initialPlacementItem,
  onClearInitialPlacement,
  newlyPlantedId,
}) => {
  // 3D Camera: full 360-degree horizontal rotation around the island's center axis
  const [rotY, setRotY] = useState(35); // Azimuth rotation angle in degrees (0 to 360)
  const [zoom, setZoom] = useState(1); // Scale multiplier
  const [autoRotate, setAutoRotate] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isStepping, setIsStepping] = useState(false);

  // Free Placement Mode State
  const [placementMode, setPlacementMode] = useState<boolean>(false);
  const [selectedPlacementItem, setSelectedPlacementItem] = useState<{ kind: 'tree' | 'decoration'; itemId: string } | null>(null);
  const [previewCoords, setPreviewCoords] = useState<{ x: number; y: number } | null>(null);
  const [selectedPlantedObjId, setSelectedPlantedObjId] = useState<string | null>(null);

  // Drag interaction tracking for 360 lateral rotation
  const isDraggingRef = useRef(false);
  const hasDraggedRef = useRef(false);
  const dragStartPosRef = useRef({ x: 0, y: 0 });
  const islandSurfaceRef = useRef<HTMLDivElement>(null);

  // Auto-activate placement mode if initiated from Shop
  useEffect(() => {
    if (initialPlacementItem) {
      setSelectedPlacementItem(initialPlacementItem);
      setPlacementMode(true);
      setPreviewCoords({ x: 0, y: 0 });
      if (onClearInitialPlacement) {
        onClearInitialPlacement();
      }
    }
  }, [initialPlacementItem, onClearInitialPlacement]);

  // Counts for growth stats
  const treeCount = plantedObjects.filter((o) => o.kind === 'tree').length;
  const decorCount = plantedObjects.filter((o) => o.kind === 'decoration').length;

  // Celestial theme details based automatically on device time
  const theme = getTimeThemeDetails(timeOfDay);

  // Available items to place
  const availableTreesToPlant = unlockedTrees;
  const availableDecorToPlant = Object.keys(purchasedDecorations).filter((dId) => {
    const bought = purchasedDecorations[dId] || 0;
    const placed = placedDecorationsCount[dId] || 0;
    return bought > placed;
  });

  // High-performance 60/120fps continuous 360-degree horizontal auto-spin loop
  useEffect(() => {
    if (!autoRotate) return;
    let animId: number;
    let lastTime = performance.now();

    const loop = (now: number) => {
      const delta = (now - lastTime) / 1000;
      lastTime = now;
      // Rotate 14 degrees per second smoothly
      setRotY((prev) => (prev + delta * 14) % 360);
      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [autoRotate]);

  // Pointer Drag Handlers: Full 360-degree lateral rotation around island center axis
  const handlePointerDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('.prevent-drag')) return;
    isDraggingRef.current = true;
    hasDraggedRef.current = false;
    setIsDragging(true);
    dragStartPosRef.current = { x: e.clientX, y: e.clientY };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDraggingRef.current) return;
    const deltaX = e.clientX - dragStartPosRef.current.x;
    const deltaY = e.clientY - dragStartPosRef.current.y;

    if (Math.abs(deltaX) > 3 || Math.abs(deltaY) > 3) {
      hasDraggedRef.current = true;
    }

    // Smooth, unbounded full 360-degree lateral rotation around island's vertical center axis
    setRotY((prev) => {
      const next = (prev + deltaX * 0.55) % 360;
      return next < 0 ? next + 360 : next;
    });

    dragStartPosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    isDraggingRef.current = false;
    setIsDragging(false);
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}
  };

  // Island Surface Click in Placement Mode (accounts for current 360 rotation angle)
  const handleIslandClick = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (!placementMode || !selectedPlacementItem || !islandSurfaceRef.current) return;
      if (hasDraggedRef.current) return; // Ignore if user was rotating the island

      const rect = islandSurfaceRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      // Displacement from center of island surface in screen pixels
      const diffX = e.clientX - centerX;
      const diffY = e.clientY - centerY;

      // Compensate for 48-degree isometric tilt foreshortening
      const pitchRad = (FIXED_ISOMETRIC_PITCH * Math.PI) / 180;
      const unpitchedY = diffY / Math.cos(pitchRad);

      // Un-rotate by current rotation angle around center axis to get local island coordinate
      const rotRad = (-rotY * Math.PI) / 180;
      const localX = diffX * Math.cos(rotRad) - unpitchedY * Math.sin(rotRad);
      const localY = diffX * Math.sin(rotRad) + unpitchedY * Math.cos(rotRad);

      const radius = rect.width / 2;
      const normalizedX = (localX / radius) * 75;
      const normalizedY = (localY / radius) * 75;

      // Keep inside circular bounds of the island
      const dist = Math.sqrt(normalizedX * normalizedX + normalizedY * normalizedY);
      if (dist > 72) {
        const angle = Math.atan2(normalizedY, normalizedX);
        const clampedX = Math.cos(angle) * 70;
        const clampedY = Math.sin(angle) * 70;
        setPreviewCoords({ x: clampedX, y: clampedY });
      } else {
        setPreviewCoords({ x: normalizedX, y: normalizedY });
      }
    },
    [placementMode, selectedPlacementItem, rotY]
  );

  const confirmPlacement = () => {
    if (!selectedPlacementItem || !previewCoords) return;

    const newPlanted: PlantedObject = {
      id: `planted-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      kind: selectedPlacementItem.kind,
      itemId: selectedPlacementItem.itemId,
      x: previewCoords.x,
      y: previewCoords.y,
      scale: 1,
      rotation: Math.floor(Math.random() * 360),
      plantedAt: Date.now(),
      isSprouting: true,
    };

    sound.playPlant();
    onPlaceObject(newPlanted);
    setPreviewCoords(null);
    setPlacementMode(false);
    setSelectedPlacementItem(null);
  };

  const resetCamera = () => {
    setRotY(0);
    setZoom(1);
    setAutoRotate(false);
  };

  const selectedPlantedObj = plantedObjects.find((p) => p.id === selectedPlantedObjId);

  return (
    <div
      className="relative w-full flex-1 flex flex-col items-center justify-center overflow-hidden select-none touch-none"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      style={{ perspective: 1200 }}
    >
      {/* Background Celestial Body (Sunrise Sun, Midday Sun, Sunset Sun, Moonrise, or Night Moon) */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {/* Sky Stars during Moonrise & Night */}
        {theme.starCount > 0 && (
          <div
            className="absolute inset-0 transition-opacity duration-1000"
            style={{ opacity: theme.starOpacity }}
          >
            {[...Array(theme.starCount)].map((_, i) => {
              const left = (i * 37 + 13) % 100;
              const top = (i * 43 + 7) % 65;
              const size = (i % 3) + 1.2;
              const delay = (i % 5) * 0.7;
              return (
                <div
                  key={i}
                  className="absolute rounded-full bg-white animate-pulse"
                  style={{
                    left: `${left}%`,
                    top: `${top}%`,
                    width: `${size}px`,
                    height: `${size}px`,
                    boxShadow: '0 0 4px rgba(255,255,255,0.8)',
                    animationDuration: `${2 + (i % 3)}s`,
                    animationDelay: `${delay}s`,
                  }}
                />
              );
            })}
          </div>
        )}

        {/* Celestial Body: Sun or Moon with atmospheric halo */}
        <div
          className="absolute transition-all duration-1000 flex items-center justify-center"
          style={{
            top:
              timeOfDay === 'sunrise'
                ? '32%'
                : timeOfDay === 'day'
                ? '12%'
                : timeOfDay === 'sunset'
                ? '30%'
                : timeOfDay === 'moonrise'
                ? '24%'
                : '15%',
            left:
              timeOfDay === 'sunrise'
                ? '18%'
                : timeOfDay === 'day'
                ? '50%'
                : timeOfDay === 'sunset'
                ? '82%'
                : timeOfDay === 'moonrise'
                ? '75%'
                : '50%',
            transform: 'translate(-50%, -50%)',
          }}
        >
          {/* Luminous Glow Aura */}
          <div
            className="w-40 h-40 sm:w-56 sm:h-56 rounded-full blur-2xl transition-all duration-1000 pointer-events-none"
            style={{
              background: `radial-gradient(circle, ${theme.celestialGlow} 0%, transparent 75%)`,
            }}
          />

          {/* Actual Sun / Moon Graphic */}
          <div
            className="absolute rounded-full transition-all duration-1000 flex items-center justify-center shadow-2xl"
            style={{
              width: theme.celestialType === 'sun' ? '64px' : '56px',
              height: theme.celestialType === 'sun' ? '64px' : '56px',
              background:
                theme.celestialType === 'sun'
                  ? timeOfDay === 'sunset'
                    ? 'radial-gradient(circle at 35% 35%, #ffedd5 0%, #f97316 45%, #dc2626 90%)'
                    : 'radial-gradient(circle at 35% 35%, #ffffff 0%, #fde047 35%, #eab308 80%, #ca8a04 100%)'
                  : 'radial-gradient(circle at 35% 35%, #ffffff 0%, #e2e8f0 45%, #cbd5e1 80%, #94a3b8 100%)',
              boxShadow: `0 0 35px ${theme.celestialGlow}, inset -3px -3px 8px rgba(0,0,0,0.25)`,
            }}
          >
            {/* Realistic Moon Craters */}
            {theme.celestialType === 'moon' && (
              <div className="absolute inset-0 rounded-full overflow-hidden opacity-40">
                <span className="absolute top-2 left-3 w-3 h-2.5 rounded-full bg-slate-400/40" />
                <span className="absolute bottom-3 left-4 w-4 h-3.5 rounded-full bg-slate-400/50" />
                <span className="absolute top-4 right-3 w-3 h-3 rounded-full bg-slate-400/35" />
                <span className="absolute bottom-2 right-4 w-2 h-2 rounded-full bg-slate-400/30" />
              </div>
            )}
          </div>
        </div>

        {/* Ambient Fireflies in Night/Moonrise */}
        {(timeOfDay === 'moonrise' || timeOfDay === 'night') && (
          <div className="absolute inset-0 pointer-events-none">
            {[...Array(12)].map((_, i) => (
              <div
                key={`firefly-${i}`}
                className="absolute w-2 h-2 rounded-full bg-emerald-300/80 blur-[1px] animate-pulse"
                style={{
                  top: `${40 + (i * 17) % 45}%`,
                  left: `${15 + (i * 23) % 70}%`,
                  animationDuration: `${2.5 + (i % 3)}s`,
                  animationDelay: `${i * 0.4}s`,
                }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Top Floating Control Bar */}
      <div className="absolute top-2 left-4 right-4 flex items-center justify-between z-20 pointer-events-none">
        {/* Island Stats Pill with Expanding Size & Azimuth Angle Dial */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/85 backdrop-blur-md border border-emerald-200/80 text-emerald-950 text-xs font-semibold shadow-xs pointer-events-auto">
          {/* Rotating Compass Needle aligned with island azimuth */}
          <div
            className="w-4 h-4 rounded-full border border-emerald-600/50 flex items-center justify-center transition-transform"
            style={{ transform: `rotate(${Math.round(rotY)}deg)` }}
            title="Island Center-Axis Orientation"
          >
            <span className="w-1.5 h-1.5 border-t-2 border-l-2 border-emerald-700 -rotate-45 block" />
          </div>
          <span className="text-emerald-900 font-bold">{treeCount} Trees</span>
          <span className="text-gray-300">•</span>
          <span className="text-[11px] text-emerald-700 font-semibold" title="Island automatically expands as trees and decorations are planted">
            Size: {islandRadius}m 🌱
          </span>
          <span className="text-gray-300">•</span>
          <span className="text-[11px] font-mono text-emerald-800 bg-emerald-100/80 px-1.5 py-0.5 rounded-md font-bold" title="Lateral Rotation Angle">
            {Math.round(((rotY % 360) + 360) % 360)}°
          </span>
        </div>

        {/* Camera Horizontal 360-Degree Rotation & Zoom Tools */}
        <div className="flex items-center gap-1.5 pointer-events-auto">
          {/* Rotate Left 45 deg */}
          <button
            onClick={() => {
              setIsStepping(true);
              setRotY((r) => ((r - 45) % 360 + 360) % 360);
              setTimeout(() => setIsStepping(false), 220);
            }}
            title="Rotate Island Left (45°)"
            className="w-8 h-8 rounded-full bg-white/85 backdrop-blur-md border border-emerald-100 flex items-center justify-center text-emerald-900 shadow-2xs hover:bg-white active:scale-95 transition-all"
          >
            <ArrowLeft size={14} />
          </button>

          {/* Rotate Right 45 deg */}
          <button
            onClick={() => {
              setIsStepping(true);
              setRotY((r) => (r + 45) % 360);
              setTimeout(() => setIsStepping(false), 220);
            }}
            title="Rotate Island Right (45°)"
            className="w-8 h-8 rounded-full bg-white/85 backdrop-blur-md border border-emerald-100 flex items-center justify-center text-emerald-900 shadow-2xs hover:bg-white active:scale-95 transition-all"
          >
            <ArrowRight size={14} />
          </button>

          {/* Auto-Spin 360° Horizontal Toggle */}
          <button
            onClick={() => setAutoRotate((a) => !a)}
            title={autoRotate ? 'Pause 360° Auto-Spin' : 'Start 360° Auto-Spin'}
            className={`w-8 h-8 rounded-full backdrop-blur-md border flex items-center justify-center shadow-2xs active:scale-95 transition-all ${
              autoRotate
                ? 'bg-emerald-700 text-white border-emerald-800'
                : 'bg-white/85 text-emerald-900 border-emerald-100 hover:bg-white'
            }`}
          >
            {autoRotate ? <Pause size={13} /> : <Play size={13} className="ml-0.5" />}
          </button>

          <button
            onClick={() => setZoom((z) => Math.min(1.4, z + 0.1))}
            title="Zoom In"
            className="w-8 h-8 rounded-full bg-white/85 backdrop-blur-md border border-emerald-100 flex items-center justify-center text-emerald-900 shadow-2xs hover:bg-white active:scale-95 transition-all"
          >
            <ZoomIn size={14} />
          </button>

          <button
            onClick={() => setZoom((z) => Math.max(0.7, z - 0.1))}
            title="Zoom Out"
            className="w-8 h-8 rounded-full bg-white/85 backdrop-blur-md border border-emerald-100 flex items-center justify-center text-emerald-900 shadow-2xs hover:bg-white active:scale-95 transition-all"
          >
            <ZoomOut size={14} />
          </button>

          <button
            onClick={() => {
              setIsStepping(true);
              resetCamera();
              setTimeout(() => setIsStepping(false), 220);
            }}
            title="Reset Angle to Front (0°)"
            className="w-8 h-8 rounded-full bg-white/85 backdrop-blur-md border border-emerald-100 flex items-center justify-center text-emerald-900 shadow-2xs hover:bg-white active:scale-95 transition-all"
          >
            <RotateCcw size={13} />
          </button>

          {onOpenDownloadModal && (
            <button
              onClick={onOpenDownloadModal}
              title="Download Complete Offline Sanctuary Package (.zip)"
              className="w-8 h-8 rounded-full bg-emerald-100/90 border border-emerald-300 flex items-center justify-center text-emerald-800 shadow-2xs hover:bg-emerald-200 active:scale-95 transition-all ml-0.5"
            >
              <Archive size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Floating Island 3D Scene Root - Fixed Isometric Elevation Pitch */}
      <div
        className="relative flex items-center justify-center z-10"
        style={{
          transformStyle: 'preserve-3d',
          transform: `scale(${zoom}) rotateX(${FIXED_ISOMETRIC_PITCH}deg)`,
          transition: 'transform 0.15s ease-out',
        }}
      >
        {/* Soft Ambient Ground Shadow under the floating island (expands smoothly with island size) */}
        <div
          className="absolute rounded-full pointer-events-none transition-all duration-700 ease-out"
          style={{
            width: `${islandRadius * 2.2}px`,
            height: `${islandRadius * 2.2}px`,
            transform: 'translateZ(-140px)',
            background:
              timeOfDay === 'night'
                ? 'radial-gradient(ellipse at center, rgba(3, 15, 8, 0.6) 0%, rgba(3, 15, 8, 0.2) 55%, transparent 75%)'
                : 'radial-gradient(ellipse at center, rgba(16, 42, 23, 0.45) 0%, rgba(16, 42, 23, 0.15) 55%, transparent 75%)',
            filter: 'blur(18px)',
          }}
        />

        {/* 360-Degree Horizontally Rotating Island Body (Rotates Around Central Vertical Axis) */}
        <div
          className="relative flex items-center justify-center"
          style={{
            width: `${islandRadius * 2}px`,
            height: `${islandRadius * 2}px`,
            transformStyle: 'preserve-3d',
            transform: `rotateZ(${rotY}deg)`,
            transformOrigin: 'center center',
            transition: isStepping ? 'transform 0.22s ease-out' : 'none',
            willChange: 'transform',
          }}
        >
          {/* Floating Rock Strata Base (Dimensional Underbelly, expands smoothly) */}
          <div
            className="absolute rounded-full pointer-events-none transition-all duration-700 ease-out"
            style={{
              width: `${islandRadius * 2}px`,
              height: `${islandRadius * 2}px`,
              transform: 'translateZ(-30px)',
              background: 'radial-gradient(ellipse at 45% 45%, #5d4037 0%, #3e2723 60%, #271406 100%)',
              boxShadow: '0 40px 60px -15px rgba(20, 10, 5, 0.6), inset 0 8px 16px rgba(141, 110, 99, 0.4)',
              borderRadius: '50% 50% 48% 52% / 52% 48% 52% 48%',
            }}
          />

          {/* Geological Earth Cliffs (Middle strata layer, expands smoothly) */}
          <div
            className="absolute rounded-full pointer-events-none transition-all duration-700 ease-out"
            style={{
              width: `${islandRadius * 2.05}px`,
              height: `${islandRadius * 2.05}px`,
              transform: 'translateZ(-10px)',
              background: 'linear-gradient(180deg, #795548 0%, #4e342e 70%, #2e1c14 100%)',
              boxShadow: 'inset 0 4px 10px rgba(255, 255, 255, 0.15)',
              borderRadius: '49% 51% 50% 50% / 51% 49% 51% 49%',
            }}
          />

          {/* Organic Island Surface (Lush Green Grass Terrain - Expands gradually with tree growth) */}
          <div
            ref={islandSurfaceRef}
            onClick={handleIslandClick}
            className={`absolute inset-0 rounded-full transition-all duration-700 ease-out ${
              placementMode ? 'cursor-crosshair ring-4 ring-emerald-400/80 ring-offset-4 ring-offset-emerald-900' : 'cursor-grab active:cursor-grabbing'
            }`}
            style={{
              transformStyle: 'preserve-3d',
              background:
                timeOfDay === 'night'
                  ? 'radial-gradient(circle at 40% 35%, #2e7d32 0%, #1b5e20 50%, #0d3813 85%, #051d09 100%)'
                  : timeOfDay === 'sunset'
                  ? 'radial-gradient(circle at 40% 35%, #a5d6a7 0%, #66bb6a 40%, #388e3c 80%, #1b5e20 100%)'
                  : 'radial-gradient(circle at 40% 35%, #81c784 0%, #4caf50 45%, #2e7d32 85%, #1b5e20 100%)',
              boxShadow: `inset 0 6px 14px rgba(255, 255, 255, 0.4), inset 0 -8px 20px rgba(10, 40, 15, 0.5), 0 8px 24px ${theme.islandGlow}`,
              borderRadius: '50%',
            }}
          >
            {/* Subtle Organic Grass Sprigs & Wildflowers */}
            <div className="absolute inset-0 rounded-full pointer-events-none overflow-hidden opacity-45">
              <svg viewBox="0 0 200 200" className="w-full h-full">
                <circle cx="50" cy="65" r="1.5" fill="#c8e6c9" />
                <circle cx="140" cy="50" r="1.8" fill="#c8e6c9" />
                <circle cx="85" cy="130" r="1.5" fill="#c8e6c9" />
                <circle cx="160" cy="120" r="1.2" fill="#c8e6c9" />
                <circle cx="35" cy="110" r="1.6" fill="#c8e6c9" />
                <circle cx="110" cy="40" r="1.5" fill="#f8bbd0" />
                <circle cx="130" cy="150" r="1.5" fill="#ffe082" />
                <circle cx="65" cy="155" r="1.4" fill="#80deea" />
              </svg>
            </div>

            {/* Planted Objects (Trees, Buildings, Animals, Decorations) with Dynamic Proportional Scaling */}
            {plantedObjects.map((obj) => {
              const isSelected = selectedPlantedObjId === obj.id;
              const isNewlyPlanted = newlyPlantedId === obj.id;
              const isTree = obj.kind === 'tree';
              const assetInfo = getProportionalAssetInfo(obj.kind, obj.itemId);
              const proportionalSize = assetInfo.pixelHeight;
              const effectiveScale = obj.scale || 1.0;

              // Calculate dynamic depth sorting as island rotates laterally 360 degrees
              const rotRad = (rotY * Math.PI) / 180;
              const rotatedY = obj.x * Math.sin(rotRad) + obj.y * Math.cos(rotRad);

              // Elevate strictly above grass disc to eliminate z-fighting / polygon intersection flicker
              const zElevation = 2.0 + (rotatedY + 100) * 0.05;

              // Billboarding: counter-rotate horizontally by -rotY and fixed pitch -FIXED_ISOMETRIC_PITCH
              // Keeps 3D models completely upright and stable with zero warping during 360-degree rotation
              return (
                <div
                  key={obj.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedPlantedObjId(obj.id);
                  }}
                  className={`absolute flex items-end justify-center pointer-events-auto cursor-pointer ${
                    isNewlyPlanted
                      ? 'animate-sprout-grow'
                      : obj.isSprouting
                      ? 'animate-bounce-short'
                      : ''
                  }`}
                  style={{
                    left: `calc(50% + ${obj.x}%)`,
                    top: `calc(50% + ${obj.y}%)`,
                    transform: `translate3d(-50%, -90%, ${zElevation.toFixed(2)}px) rotateZ(${-rotY}deg) rotateX(${-FIXED_ISOMETRIC_PITCH}deg) scale(${effectiveScale})`,
                    transformOrigin: 'bottom center',
                    transformStyle: 'preserve-3d',
                    backfaceVisibility: 'hidden',
                    WebkitBackfaceVisibility: 'hidden',
                    zIndex: Math.floor(200 + rotatedY),
                    willChange: 'transform',
                    transition: 'opacity 0.2s ease',
                  }}
                >
                  {/* Floating Auto-Planted Badge for hands-free completed session tree */}
                  {isNewlyPlanted && (
                    <div className="absolute -top-8 px-2.5 py-1 rounded-full bg-emerald-900/95 text-emerald-100 text-[10px] font-extrabold shadow-xl border border-emerald-400/90 pointer-events-none flex items-center gap-1.5 animate-fade-in whitespace-nowrap z-50">
                      <Sparkles size={11} className="text-amber-300 animate-spin-slow" />
                      <span>Auto-Planted! 🌱</span>
                    </div>
                  )}

                  {/* Flat composite isolated from 3D buffer to eliminate internal polygon tearing */}
                  <div style={{ transformStyle: 'flat', willChange: 'transform' }}>
                    {isTree ? (
                      <TreeArtwork
                        speciesId={obj.itemId}
                        size={proportionalSize}
                        growthProgress={1.0}
                      />
                    ) : (
                      <DecorationArtwork id={obj.itemId} size={proportionalSize} />
                    )}
                  </div>

                  {/* Radiant Sprout Aura Glow for Newly Planted Tree */}
                  {isNewlyPlanted && (
                    <div className="absolute -bottom-2 w-16 h-5 rounded-full bg-emerald-400/50 border-2 border-emerald-300 animate-aura-glow pointer-events-none" />
                  )}

                  {/* Selection Highlight Ring */}
                  {isSelected && (
                    <div className="absolute -bottom-1 w-12 h-4 rounded-full border-2 border-emerald-400 bg-emerald-400/25 pointer-events-none animate-pulse" />
                  )}
                </div>
              );
            })}

            {/* Free Placement Live Preview Marker */}
            {placementMode && previewCoords && selectedPlacementItem && (() => {
              const previewInfo = getProportionalAssetInfo(selectedPlacementItem.kind, selectedPlacementItem.itemId);
              return (
                <div
                  className="absolute flex items-end justify-center pointer-events-none"
                  style={{
                    left: `calc(50% + ${previewCoords.x}%)`,
                    top: `calc(50% + ${previewCoords.y}%)`,
                    transform: `translate3d(-50%, -90%, 3px) rotateZ(${-rotY}deg) rotateX(${-FIXED_ISOMETRIC_PITCH}deg)`,
                    transformOrigin: 'bottom center',
                    zIndex: 999,
                  }}
                >
                  <div className="opacity-80 animate-pulse" style={{ transformStyle: 'flat' }}>
                    {selectedPlacementItem.kind === 'tree' ? (
                      <TreeArtwork speciesId={selectedPlacementItem.itemId} size={previewInfo.pixelHeight} growthProgress={1.0} />
                    ) : (
                      <DecorationArtwork id={selectedPlacementItem.itemId} size={previewInfo.pixelHeight} />
                    )}
                  </div>
                  <div className="absolute -bottom-2 w-14 h-5 rounded-full border-2 border-emerald-400 bg-emerald-500/30" />
                </div>
              );
            })()}
          </div>
        </div>
      </div>

      {/* Placement Mode Active Notification Pill */}
      {placementMode && (
        <div className="absolute top-14 inset-x-4 flex justify-center z-30 pointer-events-none">
          <div className="px-4 py-2 rounded-2xl bg-emerald-950/90 backdrop-blur-md text-white border border-emerald-500/50 shadow-lg text-xs font-semibold flex items-center gap-2 pointer-events-auto">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Tap anywhere on the floating island to place!</span>
          </div>
        </div>
      )}

      {/* Selected Planted Object Inspector Drawer with Proportional Dimensions & Scale Controls */}
      {selectedPlantedObj && !placementMode && (() => {
        const selectedAssetInfo = getProportionalAssetInfo(selectedPlantedObj.kind, selectedPlantedObj.itemId);
        const currentScale = selectedPlantedObj.scale || 1.0;

        return (
          <div className="absolute bottom-24 inset-x-4 max-w-sm mx-auto z-30 prevent-drag animate-fade-in">
            <div className="p-3.5 rounded-3xl bg-white/95 backdrop-blur-md border border-emerald-200 shadow-xl flex flex-col gap-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-11 h-11 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center overflow-hidden shrink-0">
                    {selectedPlantedObj.kind === 'tree' ? (
                      <TreeArtwork speciesId={selectedPlantedObj.itemId} size={42} growthProgress={1.0} />
                    ) : (
                      <DecorationArtwork id={selectedPlantedObj.itemId} size={36} />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-bold text-emerald-950">
                        {selectedAssetInfo.name}
                      </h4>
                      <span className="text-[9px] uppercase font-extrabold px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
                        {selectedAssetInfo.category}
                      </span>
                    </div>
                    <p className="text-[10px] text-emerald-700 font-medium mt-0.5">
                      {selectedAssetInfo.realWorldEstimate}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => {
                      onRemoveObject(selectedPlantedObj.id);
                      setSelectedPlantedObjId(null);
                    }}
                    className="p-2 rounded-xl bg-red-50 text-red-600 hover:bg-red-100 active:scale-95 transition-all text-xs font-semibold flex items-center gap-1"
                    title="Dig Up / Move Back to Inventory"
                  >
                    <Trash2 size={13} />
                    <span>Remove</span>
                  </button>
                  <button
                    onClick={() => setSelectedPlantedObjId(null)}
                    className="p-2 rounded-xl bg-gray-100 text-gray-700 hover:bg-gray-200 active:scale-95 transition-all"
                  >
                    <X size={13} />
                  </button>
                </div>
              </div>

              {/* Dynamic Fine-Scale Controls */}
              {onUpdateObjectScale && (
                <div className="pt-2 border-t border-emerald-100 flex items-center justify-between text-xs">
                  <span className="text-[10px] font-semibold text-gray-500">Proportional Scale:</span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onUpdateObjectScale(selectedPlantedObj.id, Math.max(0.6, currentScale - 0.1))}
                      className="w-6 h-6 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-xs"
                      title="Scale Down"
                    >
                      -
                    </button>
                    <span className="font-mono font-bold text-emerald-950 text-xs w-9 text-center">
                      {currentScale.toFixed(1)}x
                    </span>
                    <button
                      onClick={() => onUpdateObjectScale(selectedPlantedObj.id, Math.min(1.8, currentScale + 0.1))}
                      className="w-6 h-6 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-xs"
                      title="Scale Up"
                    >
                      +
                    </button>
                    <button
                      onClick={() => onUpdateObjectScale(selectedPlantedObj.id, 1.0)}
                      className="text-[10px] px-1.5 py-0.5 rounded-md bg-gray-100 text-gray-600 hover:bg-gray-200 font-semibold"
                      title="Reset Scale"
                    >
                      Reset
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        );
      })()}

      {/* Bottom Placement Mode Trigger / Action Bar */}
      <div className="absolute bottom-20 inset-x-4 flex justify-center z-30 pointer-events-none">
        {!placementMode ? (
          <button
            onClick={() => setPlacementMode(true)}
            className="pointer-events-auto px-5 py-2.5 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-2 shadow-lg active:scale-95 transition-all"
          >
            <PlusCircle size={16} />
            <span>Place Tree or Decor</span>
          </button>
        ) : (
          <div className="pointer-events-auto flex items-center gap-2">
            <button
              onClick={confirmPlacement}
              disabled={!previewCoords}
              className={`px-5 py-2.5 rounded-full font-bold text-xs flex items-center gap-1.5 shadow-lg transition-all ${
                previewCoords
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white active:scale-95'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              <Check size={16} />
              <span>Confirm Plant</span>
            </button>
            <button
              onClick={() => {
                setPlacementMode(false);
                setPreviewCoords(null);
                setSelectedPlacementItem(null);
              }}
              className="px-4 py-2.5 rounded-full bg-white text-gray-700 hover:bg-gray-100 font-bold text-xs flex items-center gap-1 shadow-md active:scale-95 transition-all border border-gray-200"
            >
              <X size={15} />
              <span>Cancel</span>
            </button>
          </div>
        )}
      </div>

      {/* Item Selection Drawer during Placement Mode */}
      {placementMode && (
        <div className="absolute bottom-32 inset-x-4 max-w-md mx-auto z-40 prevent-drag animate-fade-in">
          <div className="p-3.5 rounded-3xl bg-white/95 backdrop-blur-md border border-emerald-200 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-gray-100">
              <span className="text-xs font-bold text-emerald-950">Select Item to Plant on Island</span>
              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                {previewCoords ? 'Position Selected' : 'Tap Island to Position'}
              </span>
            </div>

            <div className="flex items-center gap-2.5 overflow-x-auto py-2.5 px-1 scrollbar-none">
              {/* Unlocked Trees */}
              {availableTreesToPlant.map((treeId) => {
                const tree = TREE_SPECIES_MAP[treeId];
                const isChosen =
                  selectedPlacementItem?.kind === 'tree' && selectedPlacementItem.itemId === treeId;
                return (
                  <button
                    key={treeId}
                    onClick={() =>
                      setSelectedPlacementItem({ kind: 'tree', itemId: treeId })
                    }
                    className={`shrink-0 p-2 rounded-2xl border flex flex-col items-center gap-1 transition-all ${
                      isChosen
                        ? 'border-emerald-600 bg-emerald-50 shadow-xs ring-2 ring-emerald-500'
                        : 'border-gray-200 bg-white hover:bg-emerald-50/50'
                    }`}
                  >
                    <div className="w-11 h-11 flex items-center justify-center">
                      <TreeArtwork speciesId={treeId} size={42} growthProgress={1.0} />
                    </div>
                    <span className="text-[10px] font-semibold text-gray-800 max-w-[56px] truncate text-center">
                      {tree?.name || 'Tree'}
                    </span>
                  </button>
                );
              })}

              {/* Purchased Decorations Available */}
              {availableDecorToPlant.map((decorId) => {
                const decor = DECORATIONS_MAP[decorId];
                const isChosen =
                  selectedPlacementItem?.kind === 'decoration' &&
                  selectedPlacementItem.itemId === decorId;
                return (
                  <button
                    key={decorId}
                    onClick={() =>
                      setSelectedPlacementItem({ kind: 'decoration', itemId: decorId })
                    }
                    className={`shrink-0 p-2 rounded-2xl border flex flex-col items-center gap-1 transition-all ${
                      isChosen
                        ? 'border-emerald-600 bg-emerald-50 shadow-xs ring-2 ring-emerald-500'
                        : 'border-gray-200 bg-white hover:bg-emerald-50/50'
                    }`}
                  >
                    <div className="w-11 h-11 flex items-center justify-center">
                      <DecorationArtwork id={decorId} size={34} />
                    </div>
                    <span className="text-[10px] font-semibold text-gray-800 max-w-[56px] truncate text-center">
                      {decor?.name || 'Decor'}
                    </span>
                  </button>
                );
              })}

              {availableTreesToPlant.length === 0 && availableDecorToPlant.length === 0 && (
                <div className="text-xs text-gray-500 py-2 px-3 text-center w-full">
                  No extra trees or decorations in inventory. Complete focus sessions or buy items in Shop!
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
