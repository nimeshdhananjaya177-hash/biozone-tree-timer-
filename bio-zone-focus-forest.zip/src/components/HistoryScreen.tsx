import React, { useState } from 'react';
import { Download, Upload, Calendar, Award, CheckCircle2, Archive } from 'lucide-react';
import { FocusSession, AppState } from '../types';
import { exportForestBackup, parseForestBackup } from '../utils/storage';
import { TREE_SPECIES_MAP } from '../data/trees';

interface HistoryScreenProps {
  state: AppState;
  onRestoreBackup: (newState: AppState) => void;
  onOpenDownloadModal?: () => void;
}

export const HistoryScreen: React.FC<HistoryScreenProps> = ({ state, onRestoreBackup, onOpenDownloadModal }) => {
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Group sessions by date
  const sessionsByDate: Record<string, FocusSession[]> = {};
  state.sessions.forEach((s) => {
    if (!sessionsByDate[s.dateStr]) {
      sessionsByDate[s.dateStr] = [];
    }
    sessionsByDate[s.dateStr].push(s);
  });

  const totalMinutes = state.sessions.reduce((acc, s) => acc + s.durationMinutes, 0);
  const totalCoinsEarned = state.sessions.reduce((acc, s) => acc + s.coinsEarned, 0);
  const totalTreesPlanted = state.plantedObjects.filter((o) => o.kind === 'tree').length;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const parsed = parseForestBackup(content);
      if (parsed) {
        onRestoreBackup(parsed);
        setImportStatus('Forest data restored successfully! 🎉');
        setTimeout(() => setImportStatus(null), 3500);
      } else {
        setImportStatus('Invalid backup file. Please check JSON format.');
        setTimeout(() => setImportStatus(null), 4000);
      }
    };
    reader.readAsText(file);
    e.target.value = ''; // reset input
  };

  const datesDesc = Object.keys(sessionsByDate).sort().reverse();

  return (
    <div className="w-full flex-1 flex flex-col px-4 pb-24 pt-2 overflow-y-auto max-w-lg mx-auto select-none">
      {/* High Level Stats Bento */}
      <div className="grid grid-cols-3 gap-2.5 mb-4">
        <div className="p-3 rounded-2xl bg-white/80 backdrop-blur-md border border-emerald-100 shadow-2xs flex flex-col items-center text-center">
          <span className="text-[10px] uppercase font-bold text-emerald-800">Total Focus</span>
          <span className="text-xl font-black text-emerald-950 mt-1">{totalMinutes}m</span>
          <span className="text-[10px] text-gray-500">{(totalMinutes / 60).toFixed(1)} hrs</span>
        </div>

        <div className="p-3 rounded-2xl bg-white/80 backdrop-blur-md border border-emerald-100 shadow-2xs flex flex-col items-center text-center">
          <span className="text-[10px] uppercase font-bold text-emerald-800">Sessions</span>
          <span className="text-xl font-black text-emerald-950 mt-1">{state.sessions.length}</span>
          <span className="text-[10px] text-gray-500">Completed</span>
        </div>

        <div className="p-3 rounded-2xl bg-white/80 backdrop-blur-md border border-emerald-100 shadow-2xs flex flex-col items-center text-center">
          <span className="text-[10px] uppercase font-bold text-emerald-800">Trees Planted</span>
          <span className="text-xl font-black text-emerald-950 mt-1">{totalTreesPlanted}</span>
          <span className="text-[10px] text-gray-500">In Forest</span>
        </div>
      </div>

      {/* Offline Backup & Restore Section */}
      <div className="p-4 rounded-3xl bg-white/90 backdrop-blur-md border border-emerald-200/80 shadow-xs mb-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Award size={16} className="text-emerald-700" />
            <h3 className="text-xs font-bold text-emerald-950">Offline Local Storage</h3>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold">
            100% Private
          </span>
        </div>

        <p className="text-[11px] text-gray-600 mb-3 leading-relaxed">
          All your focus stats, planted trees, and coins are safely stored on your device. Export a backup anytime or transfer to another device.
        </p>

        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={() => exportForestBackup(state)}
              className="flex-1 py-2 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs active:scale-95"
            >
              <Download size={14} />
              <span>Export JSON</span>
            </button>

            <label className="flex-1 py-2 px-3 rounded-xl bg-white border border-emerald-300 text-emerald-900 hover:bg-emerald-50 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer active:scale-95">
              <Upload size={14} />
              <span>Import JSON</span>
              <input type="file" accept=".json" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>

          {onOpenDownloadModal && (
            <button
              onClick={onOpenDownloadModal}
              className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-800 to-teal-800 hover:from-emerald-900 hover:to-teal-900 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs active:scale-95 transition-all"
            >
              <Archive size={14} />
              <span>Download Offline Sanctuary Package (.zip)</span>
            </button>
          )}
        </div>

        {importStatus && (
          <div className="mt-2 text-xs font-semibold text-center text-emerald-700 bg-emerald-50 p-1.5 rounded-xl border border-emerald-200">
            {importStatus}
          </div>
        )}
      </div>

      {/* Focus History Logs by Date */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-1.5 px-1 mb-1">
          <Calendar size={14} className="text-emerald-800" />
          <h3 className="text-xs font-bold text-emerald-950 uppercase tracking-wider">Revision Log</h3>
        </div>

        {datesDesc.length === 0 ? (
          <div className="p-8 rounded-3xl bg-white/70 border border-emerald-100 text-center flex flex-col items-center">
            <span className="text-2xl mb-1">🌱</span>
            <h4 className="text-xs font-bold text-emerald-900">No sessions logged yet</h4>
            <p className="text-[11px] text-gray-500 mt-0.5">
              Complete your first study timer on the Focus tab to plant a tree!
            </p>
          </div>
        ) : (
          datesDesc.map((dateStr) => {
            const sessions = sessionsByDate[dateStr];
            const dayMins = sessions.reduce((a, b) => a + b.durationMinutes, 0);

            return (
              <div
                key={dateStr}
                className="p-3.5 rounded-2xl bg-white/90 backdrop-blur-md border border-emerald-100 shadow-2xs"
              >
                <div className="flex items-center justify-between pb-2 border-b border-gray-100">
                  <span className="text-xs font-bold text-emerald-950">{dateStr}</span>
                  <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                    {dayMins} mins focused
                  </span>
                </div>

                <div className="mt-2 flex flex-col gap-1.5">
                  {sessions.map((sess) => {
                    const tree = TREE_SPECIES_MAP[sess.treeId];
                    const timeString = new Date(sess.timestamp).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    });

                    return (
                      <div
                        key={sess.id}
                        className="flex items-center justify-between text-xs py-1 px-2 rounded-xl bg-emerald-50/60"
                      >
                        <div className="flex items-center gap-1.5">
                          <CheckCircle2 size={13} className="text-emerald-600" />
                          <span className="font-semibold text-gray-800">{tree?.name || 'Tree'}</span>
                          <span className="text-[10px] text-gray-500">({sess.durationMinutes}m)</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold text-amber-700">+{sess.coinsEarned} 🪙</span>
                          <span className="text-[10px] text-gray-400">{timeString}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
