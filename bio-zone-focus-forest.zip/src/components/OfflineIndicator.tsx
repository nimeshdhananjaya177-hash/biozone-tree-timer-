import React from 'react';
import { WifiOff, CheckCircle2 } from 'lucide-react';
import { useOnlineStatus } from '../hooks/usePWAInstall';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      id="offline-banner"
      className="fixed top-16 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 rounded-full bg-emerald-900/90 text-white px-3.5 py-1.5 text-xs font-medium shadow-lg backdrop-blur-xs border border-emerald-500/40 animate-fade-in"
    >
      <WifiOff className="w-3.5 h-3.5 text-emerald-300 animate-pulse" />
      <span>100% Offline Mode Active — Local storage & timer running smoothly</span>
      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
    </div>
  );
};
