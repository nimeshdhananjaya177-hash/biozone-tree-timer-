import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Square, Plus, Minus, CheckCircle, AlertTriangle, Archive } from 'lucide-react';
import { TreeArtwork, TREE_SPECIES_MAP } from '../data/trees';
import { sound } from '../utils/audio';

interface FocusScreenProps {
  selectedDuration: number;
  onDurationChange: (minutes: number) => void;
  selectedTreeId: string;
  onSelectTree: (treeId: string) => void;
  unlockedTrees: string[];
  onSessionComplete: (durationMinutes: number, treeId: string) => void;
  onSessionCancel: () => void;
  onStatusChange: (status: string) => void;
  onOpenDownloadModal?: () => void;
}

export const FocusScreen: React.FC<FocusScreenProps> = ({
  selectedDuration,
  onDurationChange,
  selectedTreeId,
  onSelectTree,
  unlockedTrees,
  onSessionComplete,
  onSessionCancel,
  onStatusChange,
  onOpenDownloadModal,
}) => {
  // Session State
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [isWilting, setIsWilting] = useState(false);
  const [wiltingProgress, setWiltingProgress] = useState(0.4);
  const [previewFullGrowth, setPreviewFullGrowth] = useState(false);
  const [showTreePicker, setShowTreePicker] = useState(false);
  const [showConfirmCancel, setShowConfirmCancel] = useState(false);

  // Persistent Refs to prevent callback updates from resetting the timer
  const onSessionCompleteRef = useRef(onSessionComplete);
  onSessionCompleteRef.current = onSessionComplete;

  const onStatusChangeRef = useRef(onStatusChange);
  onStatusChangeRef.current = onStatusChange;

  const lastStatusTextRef = useRef<string>('');
  const setStatusOnce = (text: string) => {
    if (lastStatusTextRef.current !== text) {
      lastStatusTextRef.current = text;
      onStatusChangeRef.current(text);
    }
  };

  // Wall-clock tracking refs for resilience to tab throttling and zero timer resets
  const elapsedRef = useRef<number>(0);
  const startTimeRef = useRef<number | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const totalSeconds = selectedDuration * 60;
  const progress = Math.min(1, Math.max(0, elapsedSeconds / (totalSeconds || 1)));

  // Continuous biological growth progress passed smoothly to TreeArtwork
  const activeGrowthProgress = isWilting
    ? wiltingProgress
    : isCompleted || (elapsedSeconds >= totalSeconds && totalSeconds > 0)
    ? 1.0
    : isRunning
    ? progress
    : previewFullGrowth
    ? 1.0
    : 0.0;

  // Countdown timer displaying strictly whole minutes and whole seconds accurately without milliseconds or extra decimal places
  const wholeSecondsRemaining = Math.max(0, Math.ceil(totalSeconds - elapsedSeconds));
  const minutes = Math.floor(wholeSecondsRemaining / 60);
  const seconds = wholeSecondsRemaining % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const currentTree = TREE_SPECIES_MAP[selectedTreeId] || TREE_SPECIES_MAP['basic-sapling'];
  const coinsReward = selectedDuration + 5;
  const xpReward = selectedDuration * 2;

  // Active Timer Loop: Strictly monotonic progression, zero looping, zero resetting
  useEffect(() => {
    if (!isRunning || isPaused || isWilting) {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      return;
    }

    // Anchor the wall-clock start time relative to already accumulated elapsed seconds
    startTimeRef.current = performance.now() - elapsedRef.current * 1000;

    const tick = () => {
      if (!startTimeRef.current) return;
      const now = performance.now();
      const currentElapsed = Math.max(0, (now - startTimeRef.current) / 1000);

      if (currentElapsed >= totalSeconds) {
        // Complete!
        elapsedRef.current = totalSeconds;
        setElapsedSeconds(totalSeconds);
        setIsRunning(false);
        setIsPaused(false);
        setIsCompleted(true);
        startTimeRef.current = null;
        sound.playComplete();
        setStatusOnce('Mature Harvest! Automatically Planting in My Forest… 🌳✨');
        onSessionCompleteRef.current(selectedDuration, selectedTreeId);
      } else {
        elapsedRef.current = currentElapsed;
        setElapsedSeconds(currentElapsed);

        // Notify stage text changes cleanly without triggering repetitive re-renders
        const currentProgress = currentElapsed / totalSeconds;
        if (currentProgress < 0.15) {
          setStatusOnce('Planting Seed in Loam… 🌱');
        } else if (currentProgress < 0.58) {
          setStatusOnce('Branching & Foliage Growth… 🌿');
        } else if (currentProgress < 0.76) {
          setStatusOnce('Blossoming in Full Bloom… 🌸');
        } else if (currentProgress < 0.98) {
          setStatusOnce('Bearing Ripe Fruits… 🍎');
        } else {
          setStatusOnce('Ripening to Full Maturity… ✨');
        }

        animationFrameRef.current = requestAnimationFrame(tick);
      }
    };

    animationFrameRef.current = requestAnimationFrame(tick);

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [isRunning, isPaused, isWilting, totalSeconds, selectedDuration, selectedTreeId]);

  const handleStart = () => {
    setIsWilting(false);
    setShowConfirmCancel(false);
    setPreviewFullGrowth(false);
    setIsCompleted(false);
    elapsedRef.current = 0;
    setElapsedSeconds(0);
    startTimeRef.current = performance.now();
    setIsPaused(false);
    setIsRunning(true);
    sound.playStart();
    setStatusOnce('Planting Seed in Loam… 🌱');
  };

  const handlePauseToggle = () => {
    if (isPaused) {
      // Resume: anchor start time back to performance.now minus already elapsed time
      startTimeRef.current = performance.now() - elapsedRef.current * 1000;
      setIsPaused(false);
      setStatusOnce('Growing Your Tree… 🌱');
    } else {
      // Pause: lock elapsedRef
      setIsPaused(true);
      setStatusOnce('Session Paused');
    }
  };

  const handleCancelClick = () => {
    if (elapsedSeconds < 8) {
      // Less than 8s: soft cancel without full wilt
      resetSession();
      return;
    }
    setShowConfirmCancel(true);
  };

  const confirmCancelWithWilt = () => {
    setShowConfirmCancel(false);
    setIsRunning(false);
    setIsPaused(false);
    setWiltingProgress(Math.max(0.18, progress));
    setIsWilting(true);
    sound.playWilt();
    setStatusOnce('Tree Resting • Nourishing Earth');
    onSessionCancel();

    // Wilt gracefully for 4.2 seconds before resetting
    setTimeout(() => {
      resetSession();
      setIsWilting(false);
      setStatusOnce('Ready to Focus');
    }, 4200);
  };

  const resetSession = () => {
    setIsRunning(false);
    setIsPaused(false);
    setIsWilting(false);
    setIsCompleted(false);
    setElapsedSeconds(0);
    elapsedRef.current = 0;
    startTimeRef.current = null;
  };

  const adjustDuration = (delta: number) => {
    if (isRunning || isCompleted) return;
    const next = Math.max(1, Math.min(120, selectedDuration + delta));
    onDurationChange(next);
  };

  return (
    <div className="w-full flex-1 flex flex-col items-center justify-between px-4 pb-20 pt-1 select-none max-w-md mx-auto">
      {/* Species Selector & Growth Mode Controls */}
      {!isRunning && !isWilting && (
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowTreePicker(true)}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/85 backdrop-blur-md border border-emerald-200/80 shadow-2xs hover:bg-emerald-50 text-emerald-900 transition-all active:scale-95 text-xs font-semibold"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
            <span>Tree: {currentTree.name}</span>
            <span className="text-[10px] text-emerald-700/80 font-normal underline ml-1">Change</span>
          </button>

          <button
            onClick={() => setPreviewFullGrowth((p) => !p)}
            title="Toggle between resting seed and mature fruiting tree preview"
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all border shadow-2xs active:scale-95 flex items-center gap-1.5 ${
              previewFullGrowth
                ? 'bg-emerald-700 text-white border-emerald-800'
                : 'bg-white/80 text-emerald-900 border-emerald-200/70 hover:bg-white'
            }`}
          >
            <span>{previewFullGrowth ? 'Mature Fruiting Tree 🍎' : 'Seed Ready 🌱'}</span>
          </button>
        </div>
      )}

      {/* Central Floating Glass Orb with Tree Artwork */}
      <div className="relative my-auto flex flex-col items-center justify-center">
        {/* Progress Percentage & Stage */}
        <div className="mb-2 text-center">
          <span className="text-xs font-bold tracking-widest text-emerald-900/80 uppercase">
            {isWilting
              ? 'Wilted Gently'
              : isCompleted
              ? 'Fully Grown & Harvested! 🍎'
              : isRunning
              ? progress < 0.16
                ? 'Seed Sinking in Loam 🌱'
                : progress < 0.62
                ? `${Math.floor(progress * 100)}% Canopy Growth 🌿`
                : progress < 0.78
                ? `${Math.floor(progress * 100)}% Blossoming 🌸`
                : progress < 0.98
                ? `${Math.floor(progress * 100)}% Fruiting 🍎`
                : '100% Mature Fruiting Harvest! 🎉'
              : previewFullGrowth
              ? 'Mature Fruiting Preview 🍎'
              : 'Fertile Seed in Loam 🌱'}
          </span>
        </div>

        {/* Glass Orb Container */}
        <div
          className="relative w-64 h-64 rounded-full flex items-center justify-center shadow-xl transition-all"
          style={{
            background: 'radial-gradient(circle at 35% 30%, rgba(255, 255, 255, 0.95) 0%, rgba(220, 248, 230, 0.6) 40%, rgba(144, 219, 175, 0.3) 75%, rgba(65, 150, 100, 0.4) 100%)',
            border: '2px solid rgba(255, 255, 255, 0.8)',
            boxShadow: '0 20px 40px -10px rgba(27, 77, 43, 0.25), inset 0 -12px 24px rgba(45, 100, 60, 0.2), inset 0 8px 16px rgba(255, 255, 255, 0.8)',
          }}
        >
          {/* Glass highlight glare */}
          <div
            className="absolute top-3 left-6 w-24 h-12 rounded-full opacity-60 pointer-events-none"
            style={{
              background: 'radial-gradient(ellipse at center, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0) 75%)',
              transform: 'rotate(-25deg)',
            }}
          />

          {/* Internal Soil Mound Bed */}
          <div className="absolute bottom-6 w-44 h-14 rounded-full bg-gradient-to-b from-[#4e3825] to-[#342416] opacity-90 shadow-inner flex items-center justify-center overflow-hidden">
            {/* Organic grass lining inside orb */}
            <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-emerald-700 via-emerald-600 to-emerald-800 opacity-90" />
            <div className="absolute top-1.5 w-full flex justify-around opacity-60">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span className="w-1 h-1 rounded-full bg-emerald-300" />
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            </div>
          </div>

          {/* Tree Component (Continuous Growth: Seed sinks into loam -> Shoot uncurls -> Morph into Species) */}
          <div className="absolute bottom-10 z-10">
            <TreeArtwork
              speciesId={selectedTreeId}
              size={155}
              growthProgress={activeGrowthProgress}
              isWilting={isWilting}
            />
          </div>

          {/* Ambient Biological Solar Aura inside glass orb (Progressive with growth, no looping or resets) */}
          {(isRunning || isCompleted) && !isWilting && (
            <div
              className="absolute inset-0 pointer-events-none rounded-full"
              style={{
                background: `radial-gradient(circle at 50% 45%, rgba(134, 239, 172, ${0.06 + activeGrowthProgress * 0.18}) 0%, rgba(254, 240, 138, ${activeGrowthProgress * 0.15}) 40%, transparent 68%)`,
              }}
            />
          )}

          {/* Graceful Emotional Wilting Feedback Overlay */}
          {isWilting && (
            <div className="absolute inset-0 rounded-full bg-amber-950/30 backdrop-blur-[1px] flex flex-col items-center justify-center text-center p-5 animate-fade-in z-20">
              <span className="text-[11px] font-bold text-amber-900 bg-amber-50/95 border border-amber-300 px-3 py-1 rounded-full shadow-xs">
                Returning to the Earth
              </span>
              <p className="text-[11px] font-medium text-amber-50 drop-shadow-md mt-2 leading-relaxed max-w-[210px]">
                Every fallen leaf returns to nourish the soil. Rest your mind and begin again whenever you are ready.
              </p>
              <button
                onClick={() => {
                  resetSession();
                  setIsWilting(false);
                  setStatusOnce('Ready to Focus');
                }}
                className="mt-3 px-3.5 py-1 rounded-full bg-white/90 text-emerald-950 hover:bg-white text-[10px] font-bold shadow-md active:scale-95 transition-all"
              >
                Try Again Now
              </button>
            </div>
          )}
        </div>

        {/* Big Digital Timer Display */}
        <div className="mt-4 flex flex-col items-center">
          <div className="text-4xl sm:text-5xl font-extrabold tracking-tight text-emerald-950 font-mono">
            {formattedTime}
          </div>
          <div className="text-[11px] font-medium text-emerald-700/90 mt-0.5">
            Earn <span className="font-bold text-amber-700">+{coinsReward} Coins</span> & <span className="font-bold text-emerald-800">+{xpReward} XP</span>
          </div>
        </div>
      </div>

      {/* Preset Duration Buttons (Disabled while running) */}
      {!isRunning && !isWilting && !isCompleted && (
        <div className="w-full flex items-center justify-center gap-1.5 my-2">
          {[1, 5, 15, 25, 45, 60].map((mins) => (
            <button
              key={mins}
              onClick={() => onDurationChange(mins)}
              className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                selectedDuration === mins
                  ? 'bg-emerald-700 text-white shadow-sm scale-105'
                  : 'bg-white/70 text-emerald-900 border border-emerald-100 hover:bg-white'
              }`}
            >
              {mins}m
            </button>
          ))}
        </div>
      )}

      {/* Controls Container */}
      <div className="w-full flex flex-col items-center gap-3">
        {/* Steppers & Primary Action Button */}
        {!isRunning && !isWilting && !isCompleted ? (
          <div className="w-full flex items-center justify-center gap-3">
            <button
              onClick={() => adjustDuration(-5)}
              disabled={selectedDuration <= 1}
              aria-label="Decrease focus duration by 5 minutes"
              className="w-12 h-12 rounded-2xl bg-white/80 border border-emerald-100 text-emerald-900 flex items-center justify-center shadow-xs hover:bg-white active:scale-95 disabled:opacity-40 transition-all"
            >
              <Minus size={20} />
            </button>

            <button
              onClick={handleStart}
              id="start-focus-button"
              className="flex-1 max-w-[200px] h-13 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-base flex items-center justify-center gap-2 shadow-md hover:shadow-lg active:scale-98 transition-all"
            >
              <Play size={20} fill="currentColor" />
              <span>Start Focus</span>
            </button>

            <button
              onClick={() => adjustDuration(5)}
              disabled={selectedDuration >= 120}
              aria-label="Increase focus duration by 5 minutes"
              className="w-12 h-12 rounded-2xl bg-white/80 border border-emerald-100 text-emerald-900 flex items-center justify-center shadow-xs hover:bg-white active:scale-95 disabled:opacity-40 transition-all"
            >
              <Plus size={20} />
            </button>
          </div>
        ) : isRunning ? (
          <div className="w-full flex items-center justify-center gap-3">
            <button
              onClick={handleCancelClick}
              title="Stop & Wilt Tree"
              className="px-4 h-12 rounded-2xl bg-red-100 hover:bg-red-200 border border-red-200 text-red-700 font-semibold text-xs flex items-center gap-1.5 active:scale-95 transition-all shadow-xs"
            >
              <Square size={16} fill="currentColor" />
              <span>Give Up</span>
            </button>

            <button
              onClick={handlePauseToggle}
              className="flex-1 max-w-[180px] h-13 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md active:scale-98 transition-all"
            >
              {isPaused ? <Play size={18} fill="currentColor" /> : <Pause size={18} fill="currentColor" />}
              <span>{isPaused ? 'Resume Focus' : 'Pause'}</span>
            </button>
          </div>
        ) : isCompleted ? (
          <div className="w-full flex flex-col items-center gap-1.5 py-2 animate-fade-in">
            <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-emerald-100 text-emerald-950 text-xs font-bold shadow-xs border border-emerald-300/80">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
              <span>Auto-Planting in My Forest Floating Island… 🌱</span>
            </div>
            <p className="text-[11px] text-emerald-800 font-medium">
              Your mature tree is taking root on the island without any manual intervention!
            </p>
          </div>
        ) : (
          <div className="text-xs font-semibold text-emerald-800 py-3">Preparing soil for next session…</div>
        )}

        {/* Quick Offline Package Download trigger */}
        {!isRunning && !isWilting && onOpenDownloadModal && (
          <button
            onClick={onOpenDownloadModal}
            className="mt-2 text-[11px] text-emerald-700/80 hover:text-emerald-950 font-medium flex items-center justify-center gap-1.5 transition-colors py-1 px-3 rounded-full hover:bg-emerald-100/60"
            title="Download offline sanctuary files package (.zip)"
          >
            <Archive size={13} className="text-emerald-600" />
            <span>Package & Download All Files (.zip)</span>
          </button>
        )}
      </div>

      {/* Early Cancel Confirmation Modal */}
      {showConfirmCancel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-fade-in">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-red-100 flex flex-col items-center text-center gap-3">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center">
              <AlertTriangle size={24} />
            </div>
            <h3 className="text-base font-bold text-gray-900">Stop Focus Session?</h3>
            <p className="text-xs text-gray-600 leading-relaxed">
              If you leave now, your growing tree will wilt and return to the earth. No coins or XP will be earned for this session.
            </p>
            <div className="w-full flex items-center gap-2 mt-2">
              <button
                onClick={() => setShowConfirmCancel(false)}
                className="flex-1 py-2.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold text-xs transition-colors"
              >
                Keep Focusing
              </button>
              <button
                onClick={confirmCancelWithWilt}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-semibold text-xs transition-colors shadow-xs"
              >
                Wilt Tree & Stop
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tree Selector Modal */}
      {showTreePicker && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-5 shadow-2xl border border-emerald-100 flex flex-col max-h-[80vh]">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <h3 className="text-sm font-bold text-emerald-950">Choose Tree to Grow</h3>
              <button
                onClick={() => setShowTreePicker(false)}
                className="text-xs text-gray-500 hover:text-gray-800 px-2 py-1 rounded-md"
              >
                Done
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-3 grid grid-cols-2 gap-2.5 pr-1">
              {unlockedTrees.map((tId) => {
                const spec = TREE_SPECIES_MAP[tId];
                if (!spec) return null;
                const isSelected = selectedTreeId === tId;
                return (
                  <button
                    key={tId}
                    onClick={() => {
                      onSelectTree(tId);
                      setShowTreePicker(false);
                    }}
                    className={`flex flex-col items-center p-3 rounded-2xl border transition-all text-center ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50 shadow-xs'
                        : 'border-gray-200 hover:border-emerald-300 bg-white'
                    }`}
                  >
                    <div className="w-16 h-16 flex items-center justify-center">
                      <TreeArtwork speciesId={tId} size={54} growthProgress={1.0} />
                    </div>
                    <span className="text-xs font-bold text-gray-900 mt-2">{spec.name}</span>
                    <span className="text-[10px] text-emerald-700 capitalize font-medium">{spec.rarity}</span>
                    {isSelected && (
                      <span className="mt-1 flex items-center gap-1 text-[10px] font-bold text-emerald-700">
                        <CheckCircle size={12} /> Active
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
