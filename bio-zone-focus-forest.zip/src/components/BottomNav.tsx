import React from 'react';
import { Timer, Trees, ShoppingBag, History } from 'lucide-react';
import { NavTab } from '../types';

interface BottomNavProps {
  currentTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, onTabChange }) => {
  const tabs = [
    { id: 'focus' as NavTab, label: 'Focus', icon: Timer },
    { id: 'forest' as NavTab, label: 'My Forest', icon: Trees },
    { id: 'shop' as NavTab, label: 'Shop', icon: ShoppingBag },
    { id: 'history' as NavTab, label: 'History', icon: History },
  ];

  return (
    <nav
      id="bottom-navigation-bar"
      className="fixed bottom-0 inset-x-0 z-40 pb-safe pt-1.5 pb-2 px-4 bg-white/85 backdrop-blur-xl border-t border-emerald-100/90 shadow-lg select-none"
    >
      <div className="max-w-md mx-auto flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all ${
                isActive
                  ? 'text-emerald-800 scale-105 font-bold'
                  : 'text-gray-500 hover:text-emerald-700 font-medium'
              }`}
            >
              <div
                className={`p-1.5 rounded-xl transition-all ${
                  isActive ? 'bg-emerald-100/80 text-emerald-800 shadow-2xs' : 'bg-transparent'
                }`}
              >
                <Icon size={18} strokeWidth={isActive ? 2.5 : 2} />
              </div>
              <span className="text-[11px] mt-0.5 tracking-tight">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
