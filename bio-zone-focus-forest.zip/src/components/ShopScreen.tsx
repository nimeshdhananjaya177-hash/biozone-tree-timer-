import React, { useState } from 'react';
import { ShoppingBag, Lock, CheckCircle2 } from 'lucide-react';
import { TREE_SPECIES_LIST, TreeArtwork } from '../data/trees';
import { DECORATIONS_LIST, DecorationArtwork } from '../data/decorations';
import { sound } from '../utils/audio';

interface ShopScreenProps {
  coins: number;
  unlockedTrees: string[];
  purchasedDecorations: Record<string, number>;
  placedDecorationsCount: Record<string, number>;
  onUnlockTree: (treeId: string, cost: number) => void;
  onBuyDecoration: (decorId: string, cost: number) => void;
  onInitiatePlacement?: (item: { kind: 'tree' | 'decoration'; itemId: string }) => void;
}

export const ShopScreen: React.FC<ShopScreenProps> = ({
  coins,
  unlockedTrees,
  purchasedDecorations,
  placedDecorationsCount,
  onUnlockTree,
  onBuyDecoration,
  onInitiatePlacement,
}) => {
  // Main Category Tab: 'trees' or 'others'
  const [mainCategory, setMainCategory] = useState<'trees' | 'others'>('trees');
  // Sub-filter for 'others': 'all' | 'wildlife' | 'structures' | 'flora'
  const [othersFilter, setOthersFilter] = useState<'all' | 'wildlife' | 'structures' | 'flora'>('all');

  const filteredDecorations = DECORATIONS_LIST.filter((item) => {
    if (othersFilter === 'all') return true;
    return item.category === othersFilter;
  });

  return (
    <div className="w-full flex-1 flex flex-col px-4 pb-24 pt-2 overflow-y-auto max-w-lg mx-auto select-none">
      {/* Category Tabs: "Trees" and "Others" */}
      <div className="flex items-center p-1 rounded-2xl bg-white/70 backdrop-blur-md border border-emerald-100 shadow-2xs mb-3">
        <button
          onClick={() => setMainCategory('trees')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
            mainCategory === 'trees'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-emerald-900 hover:bg-emerald-50/60'
          }`}
        >
          Trees (20)
        </button>
        <button
          onClick={() => setMainCategory('others')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
            mainCategory === 'others'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-emerald-900 hover:bg-emerald-50/60'
          }`}
        >
          Others (Decor & Wildlife)
        </button>
      </div>

      {/* If "Others" is selected: Sub-category pill filters */}
      {mainCategory === 'others' && (
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-2 text-xs">
          {[
            { id: 'all', label: 'All Others' },
            { id: 'wildlife', label: 'Wildlife' },
            { id: 'structures', label: 'Structures' },
            { id: 'flora', label: 'Flora & Crystals' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setOthersFilter(tab.id as 'all' | 'wildlife' | 'structures' | 'flora')}
              className={`px-3 py-1.5 rounded-full whitespace-nowrap text-xs font-semibold transition-all ${
                othersFilter === tab.id
                  ? 'bg-emerald-800 text-white shadow-2xs'
                  : 'bg-white/80 text-emerald-900 border border-emerald-100 hover:bg-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      )}

      {/* Grid of Items */}
      {mainCategory === 'trees' ? (
        <div className="grid grid-cols-2 gap-3">
          {TREE_SPECIES_LIST.map((tree) => {
            const isUnlocked = unlockedTrees.includes(tree.id);
            const canAfford = coins >= tree.cost;

            return (
              <div
                key={tree.id}
                className={`p-3.5 rounded-3xl border flex flex-col justify-between transition-all ${
                  isUnlocked
                    ? 'bg-white/90 border-emerald-200/80 shadow-xs'
                    : 'bg-white/60 border-gray-200 shadow-2xs'
                }`}
              >
                <div className="w-full flex flex-col items-center">
                  <div className="w-20 h-20 flex items-center justify-center relative">
                    <TreeArtwork speciesId={tree.id} size={68} growthProgress={1.0} />
                    {!isUnlocked && (
                      <div className="absolute top-0 right-0 p-1 rounded-full bg-gray-100 text-gray-500">
                        <Lock size={12} />
                      </div>
                    )}
                  </div>
                  <h4 className="text-xs font-bold text-gray-900 mt-2 text-center">{tree.name}</h4>
                  <span className="text-[10px] text-emerald-700 capitalize font-semibold">{tree.rarity}</span>
                  <p className="text-[10px] text-gray-500 text-center line-clamp-2 mt-1 px-1 leading-snug">
                    {tree.description}
                  </p>
                </div>

                <div className="mt-3 pt-2 border-t border-gray-100/80 w-full flex flex-col gap-1.5">
                  {isUnlocked ? (
                    <div className="flex flex-col gap-1.5 w-full">
                      <div className="w-full flex items-center justify-center gap-1 py-1 text-emerald-800 text-xs font-bold bg-emerald-50 rounded-xl">
                        <CheckCircle2 size={14} /> Unlocked
                      </div>
                      {onInitiatePlacement && (
                        <button
                          onClick={() => onInitiatePlacement({ kind: 'tree', itemId: tree.id })}
                          className="w-full py-1.5 rounded-xl font-bold text-xs bg-emerald-700 hover:bg-emerald-800 text-white flex items-center justify-center gap-1 shadow-xs active:scale-95 transition-all"
                        >
                          <span>🌱 Plant on Island</span>
                        </button>
                      )}
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        if (canAfford) {
                          sound.playCoin();
                          onUnlockTree(tree.id, tree.cost);
                        }
                      }}
                      disabled={!canAfford}
                      className={`w-full py-1.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs ${
                        canAfford
                          ? 'bg-amber-500 hover:bg-amber-600 text-white active:scale-95'
                          : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                      }`}
                    >
                      <span>🪙 {tree.cost}</span>
                      <span>Unlock</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {filteredDecorations.map((item) => {
            const purchasedCount = purchasedDecorations[item.id] || 0;
            const placedCount = placedDecorationsCount[item.id] || 0;
            const availableToPlace = purchasedCount - placedCount;
            const canAfford = coins >= item.cost;

            return (
              <div
                key={item.id}
                className="p-3.5 rounded-3xl border border-emerald-100 bg-white/90 shadow-xs flex flex-col justify-between transition-all"
              >
                <div className="w-full flex flex-col items-center">
                  <div className="w-16 h-16 flex items-center justify-center">
                    <DecorationArtwork id={item.id} size={54} />
                  </div>
                  <h4 className="text-xs font-bold text-gray-900 mt-2 text-center">{item.name}</h4>
                  <span className="text-[10px] text-amber-800 capitalize font-medium">{item.category}</span>
                  <p className="text-[10px] text-gray-500 text-center line-clamp-2 mt-1 px-1 leading-snug">
                    {item.description}
                  </p>
                  {purchasedCount > 0 && (
                    <span className="mt-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                      Owned: {purchasedCount} ({availableToPlace} unplaced)
                    </span>
                  )}
                </div>

                <div className="mt-3 pt-2 border-t border-gray-100 w-full flex flex-col gap-1.5">
                  {purchasedCount > 0 && availableToPlace > 0 && onInitiatePlacement && (
                    <button
                      onClick={() => onInitiatePlacement({ kind: 'decoration', itemId: item.id })}
                      className="w-full py-1.5 rounded-xl font-bold text-xs bg-emerald-700 hover:bg-emerald-800 text-white flex items-center justify-center gap-1 shadow-xs active:scale-95 transition-all"
                    >
                      <span>📍 Place on Island</span>
                    </button>
                  )}
                  <button
                    onClick={() => {
                      if (canAfford) {
                        sound.playCoin();
                        onBuyDecoration(item.id, item.cost);
                      }
                    }}
                    disabled={!canAfford}
                    className={`w-full py-1.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs ${
                      canAfford
                        ? 'bg-amber-500 hover:bg-amber-600 text-white active:scale-95'
                        : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    <ShoppingBag size={13} />
                    <span>🪙 {item.cost}</span>
                    <span>{purchasedCount > 0 ? 'Buy Another' : 'Buy'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
