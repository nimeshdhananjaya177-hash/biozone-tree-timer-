import React, { useState, useRef } from 'react';
import { Download, Archive, FileJson, Upload, CheckCircle2, ShieldCheck, X, HardDrive, RefreshCw } from 'lucide-react';
import { AppState } from '../types';
import { downloadForestZipPackage, downloadForestJsonBackup, importForestStateFromFile } from '../utils/forestPackager';
import { sound } from '../utils/audio';

interface DownloadPackageModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: AppState;
  onRestoreState: (newState: AppState) => void;
}

export const DownloadPackageModal: React.FC<DownloadPackageModalProps> = ({
  isOpen,
  onClose,
  state,
  onRestoreState,
}) => {
  const [isZipping, setIsZipping] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      setDownloadSuccess(null);
      await downloadForestZipPackage(state);
      sound.playComplete();
      setDownloadSuccess('Offline ZIP package successfully downloaded!');
    } catch (e) {
      console.error(e);
      setImportError('Failed to generate ZIP package.');
    } finally {
      setIsZipping(false);
    }
  };

  const handleDownloadJson = () => {
    try {
      downloadForestJsonBackup(state);
      sound.playClick();
      setDownloadSuccess('JSON backup file successfully saved!');
    } catch (e) {
      console.error(e);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setImportError(null);
      const imported = await importForestStateFromFile(file);
      onRestoreState(imported);
      sound.playPurchase();
      setDownloadSuccess(`Successfully imported forest! Level ${imported.level}, ${imported.plantedObjects.length} objects.`);
    } catch (err) {
      setImportError('Invalid backup file. Please select a valid BioZone forest JSON file.');
    }
  };

  const treeCount = state.plantedObjects.filter((o) => o.kind === 'tree').length;
  const decorCount = state.plantedObjects.filter((o) => o.kind === 'decoration').length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-fade-in">
      <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl border border-emerald-100 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-emerald-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-800">
              <Archive className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-emerald-950">Download & Offline Package</h2>
              <p className="text-xs text-emerald-700">Self-contained offline storage & downloadable formats</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Offline Architecture Banner */}
        <div className="mt-4 p-3.5 rounded-2xl bg-emerald-50/80 border border-emerald-200/80 flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
          <div className="text-xs text-emerald-900 leading-relaxed">
            <strong className="text-emerald-950 font-bold block mb-0.5">100% Offline Local-Only Architecture</strong>
            All timer mechanics, forest growth algorithms, and island states execute exclusively inside your device's memory. No remote servers, tracking, or cloud dependencies exist.
          </div>
        </div>

        {/* Status Alerts */}
        {downloadSuccess && (
          <div className="mt-3 p-3 rounded-xl bg-emerald-100/90 text-emerald-900 text-xs font-semibold flex items-center gap-2 animate-fade-in border border-emerald-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-700" />
            <span>{downloadSuccess}</span>
          </div>
        )}

        {importError && (
          <div className="mt-3 p-3 rounded-xl bg-rose-100 text-rose-900 text-xs font-semibold flex items-center gap-2 animate-fade-in border border-rose-300">
            <span>{importError}</span>
          </div>
        )}

        {/* Package Options */}
        <div className="mt-5 space-y-3">
          {/* Main Option: Complete ZIP Package */}
          <div className="p-4 rounded-2xl border-2 border-emerald-500/80 bg-emerald-50/40 hover:bg-emerald-50/70 transition-all flex flex-col gap-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                <Archive className="w-4 h-4 text-emerald-700" />
                Complete Offline Sanctuary Package (.ZIP)
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-200/80 text-emerald-900">
                Recommended
              </span>
            </div>
            <p className="text-[11px] text-emerald-800/90 leading-relaxed">
              Includes standalone <strong>offline-forest.html</strong> (full 360° rotatable 3D island with zero jitter/warping), <strong>offline-growth-timer.html</strong> (continuous seed-to-tree animation timer), <strong>forest-data.json</strong>, <strong>study-journal.md</strong>, <strong>species-catalog.json</strong>, and manifest.
            </p>
            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="mt-1 w-full py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm active:scale-98 transition disabled:opacity-50"
            >
              {isZipping ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Packaging Files into ZIP…</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Download Complete Package (.ZIP)</span>
                </>
              )}
            </button>
          </div>

          {/* Secondary Option: Direct JSON State */}
          <div className="p-4 rounded-2xl border border-gray-200 bg-gray-50/50 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-900 flex items-center gap-1.5">
                <FileJson className="w-4 h-4 text-gray-600" />
                Raw State Backup (.JSON)
              </span>
              <span className="text-[10px] text-gray-500 font-medium">Fast Sync</span>
            </div>
            <p className="text-[11px] text-gray-600">
              Direct JSON state containing your {treeCount} mature trees, {decorCount} placed sanctuary items, {state.coins} coins, and study history.
            </p>
            <button
              onClick={handleDownloadJson}
              className="mt-1 w-full py-2 px-4 rounded-xl bg-white border border-gray-300 hover:bg-gray-100 text-gray-800 font-semibold text-xs flex items-center justify-center gap-2 shadow-2xs active:scale-98 transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download JSON State Backup</span>
            </button>
          </div>

          {/* Restore / Import Section */}
          <div className="p-4 rounded-2xl border border-dashed border-emerald-300 bg-white flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                <Upload className="w-4 h-4 text-emerald-600" />
                Restore / Import Backup
              </span>
            </div>
            <p className="text-[11px] text-gray-600">
              Select a downloaded JSON file from your computer or phone to restore your forest anytime.
            </p>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".json"
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="mt-1 w-full py-2 px-4 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-900 font-semibold text-xs flex items-center justify-center gap-2 active:scale-98 transition"
            >
              <HardDrive className="w-3.5 h-3.5 text-emerald-700" />
              <span>Choose File to Restore</span>
            </button>
          </div>
        </div>

        {/* Footer info */}
        <div className="mt-5 pt-3 border-t border-gray-100 text-center">
          <p className="text-[10px] text-gray-400">
            Bio Zone Focus Forest — Portable, offline-first productivity platform for Sri Lankan A/L students
          </p>
        </div>
      </div>
    </div>
  );
};
