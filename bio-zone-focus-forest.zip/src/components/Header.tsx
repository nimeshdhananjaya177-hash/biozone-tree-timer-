import React from 'react';
import { Volume2, VolumeX, Sparkles, Download, Archive } from 'lucide-react';
import { TimeOfDay } from '../types';
import { getTimeThemeDetails } from '../utils/timeOfDay';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  coins: number;
  xp: number;
  level: number;
  timeOfDay: TimeOfDay;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenDownloadModal?: () => void;
  statusText?: string;
}

export const Header: React.FC<HeaderProps> = ({
  coins,
  xp,
  level,
  timeOfDay,
  soundEnabled,
  onToggleSound,
  onOpenDownloadModal,
  statusText = 'Ready to Focus',
}) => {
  const theme = getTimeThemeDetails(timeOfDay);
  const celestialEmoji = {
    sunrise: '🌅',
    day: '☀️',
    sunset: '🌇',
    moonrise: '🌙',
    night: '✨',
  }[timeOfDay];

  return (
    <header className="w-full pt-3 pb-2 px-4 flex flex-col items-center justify-between gap-2 select-none z-30">
      {/* Main Heading positioned at the very top */}
      <div className="w-full flex items-center justify-between">
        <div className="flex flex-col items-start">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse inline-block" />
            <h1 className="text-sm tracking-wider font-extrabold text-emerald-950 uppercase">
              Bio Zone • A/L Focus
            </h1>
          </div>
          <div className="text-[10px] font-semibold text-emerald-800/90 flex items-center gap-1 mt-0.5">
            <span>{celestialEmoji}</span>
            <span>{theme.label}</span>
            <span className="text-gray-500 font-normal">({theme.timeFormatted})</span>
            <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 font-medium">Auto Cycle</span>
          </div>
        </div>

        {/* Action Group: PWA Install, Package/Download, Audio */}
        <div className="flex items-center gap-1.5">
          <PWAInstallButton />

          {onOpenDownloadModal && (
            <button
              onClick={onOpenDownloadModal}
              title="Download Offline Forest Package (.zip / .json)"
              aria-label="Download Package"
              className="p-1.5 rounded-full bg-white/75 backdrop-blur-md border border-emerald-200/80 text-emerald-800 hover:bg-white hover:text-emerald-950 transition-all shadow-2xs active:scale-95 flex items-center gap-1 text-xs font-semibold px-2.5"
            >
              <Archive size={14} className="text-emerald-700" />
              <span className="hidden sm:inline">Package</span>
            </button>
          )}

          {/* Audio Mute/Unmute Toggle */}
          <button
            onClick={onToggleSound}
            title={soundEnabled ? 'Mute Sounds' : 'Unmute Sounds'}
            aria-label={soundEnabled ? 'Mute Audio' : 'Enable Audio'}
            className="p-1.5 rounded-full bg-white/70 backdrop-blur-md border border-emerald-100/80 text-emerald-800 hover:bg-white transition-all shadow-sm active:scale-95"
          >
            {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} className="text-gray-400" />}
          </button>
        </div>
      </div>

      {/* Top Header Row: Coins Badge, Dynamic Status, Level/XP Badge */}
      <div className="w-full flex items-center justify-between gap-2 mt-1">
        {/* Coins Badge */}
        <div
          id="header-coins-badge"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/80 backdrop-blur-md border border-amber-200/70 shadow-xs text-amber-900 font-semibold text-xs transition-transform active:scale-95"
        >
          <span className="text-sm leading-none">🪙</span>
          <span>{coins}</span>
          <span className="text-[10px] text-amber-700/80 font-normal">Coins</span>
        </div>

        {/* Dynamic Session Status */}
        <div
          id="header-status-pill"
          className="px-3 py-1 rounded-full bg-emerald-100/70 border border-emerald-200/60 text-emerald-900 text-xs font-medium tracking-wide shadow-2xs whitespace-nowrap"
        >
          {statusText}
        </div>

        {/* Level / XP Badge */}
        <div
          id="header-xp-badge"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/80 backdrop-blur-md border border-emerald-200/70 shadow-xs text-emerald-900 font-semibold text-xs"
        >
          <Sparkles size={13} className="text-emerald-600" />
          <span>Lvl {level}</span>
          <span className="text-[10px] text-emerald-700/80 font-normal">{xp} XP</span>
        </div>
      </div>
    </header>
  );
};
