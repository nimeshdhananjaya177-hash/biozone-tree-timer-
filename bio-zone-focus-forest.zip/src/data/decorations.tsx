import React from 'react';
import { DecorationItem } from '../types';

export const DECORATIONS_LIST: DecorationItem[] = [
  // WILDLIFE
  {
    id: 'squirrel',
    name: 'Squirrel',
    category: 'wildlife',
    cost: 15,
    description: 'An inquisitive bushy-tailed visitor holding an acorn.',
  },
  {
    id: 'rabbit',
    name: 'White Rabbit',
    category: 'wildlife',
    cost: 18,
    description: 'Gentle forest dweller hopping among clover patches.',
  },
  {
    id: 'hedgehog',
    name: 'Little Hedgehog',
    category: 'wildlife',
    cost: 20,
    description: 'A cozy nocturnal companion resting in the grass.',
  },
  {
    id: 'owl',
    name: 'Wise Owl',
    category: 'wildlife',
    cost: 30,
    description: 'Perched sentinel watching over quiet midnight study hours.',
  },
  {
    id: 'deer',
    name: 'Graceful Deer',
    category: 'wildlife',
    cost: 45,
    description: 'Majestic golden-spotted fawn that brings tranquil energy.',
  },
  {
    id: 'turtle',
    name: 'Pond Turtle',
    category: 'wildlife',
    cost: 22,
    description: 'Patient, steady crawler reminding you that slow and steady wins the A/L race.',
  },
  {
    id: 'butterflies',
    name: 'Meadow Butterflies',
    category: 'wildlife',
    cost: 25,
    description: 'A flutter of azure and gold wings above the blossoms.',
  },
  {
    id: 'fireflies',
    name: 'Night Fireflies',
    category: 'wildlife',
    cost: 28,
    description: 'Bioluminescent sprites lighting up evening study sessions.',
  },

  // STRUCTURES & DECOR
  {
    id: 'log-cabin',
    name: 'Log Cabin',
    category: 'structures',
    cost: 50,
    description: 'A cozy timber refuge tucked safely into the grove.',
  },
  {
    id: 'wooden-bridge',
    name: 'Wooden Bridge',
    category: 'structures',
    cost: 35,
    description: 'An arched rustic footbridge spanning gentle grassy knolls.',
  },
  {
    id: 'swing',
    name: 'Tree Swing',
    category: 'structures',
    cost: 30,
    description: 'A nostalgic rope swing suspended from a sturdy branch.',
  },
  {
    id: 'bench',
    name: 'Garden Bench',
    category: 'structures',
    cost: 20,
    description: 'A quiet carved timber bench for taking mindful study pauses.',
  },
  {
    id: 'fountain',
    name: 'Stone Fountain',
    category: 'structures',
    cost: 40,
    description: 'Tiered carved fountain bubbling with clear alpine water.',
  },
  {
    id: 'birdhouse',
    name: 'Wooden Birdhouse',
    category: 'structures',
    cost: 18,
    description: 'A miniature sanctuary welcoming songbirds.',
  },
  {
    id: 'fence',
    name: 'Rustic Fence',
    category: 'structures',
    cost: 16,
    description: 'Natural wooden fence defining your quiet sanctuary.',
  },
  {
    id: 'stone-path',
    name: 'Stepping Stones',
    category: 'structures',
    cost: 15,
    description: 'Smooth river stones paving your study journey.',
  },
  {
    id: 'rune-stone',
    name: 'Ancient Rune Stone',
    category: 'structures',
    cost: 45,
    description: 'Mystic monolith etched with luminous memory glyphs.',
  },
  {
    id: 'lantern',
    name: 'Garden Lantern',
    category: 'structures',
    cost: 22,
    description: 'Warm glass lantern casting a gentle glow on night turf.',
  },
  {
    id: 'mushroom-house',
    name: 'Mushroom House',
    category: 'structures',
    cost: 55,
    description: 'Whimsical speckled toadstool home with tiny chimney.',
  },
  {
    id: 'pond',
    name: 'Lotus Pond',
    category: 'structures',
    cost: 48,
    description: 'Still water reflecting the sky with floating lily pads.',
  },
  {
    id: 'waterfall',
    name: 'Mini Waterfall',
    category: 'structures',
    cost: 60,
    description: 'Crisp mountain cascade tumbling over mossy crags.',
  },

  // FLORA & CRYSTALS
  {
    id: 'flower-patch',
    name: 'Wildflower Patch',
    category: 'flora',
    cost: 12,
    description: 'A vibrant carpet of pink, blue, and yellow buttercups.',
  },
  {
    id: 'crystal-cyan',
    name: 'Glowing Crystal — Cyan',
    category: 'flora',
    cost: 35,
    description: 'Prismatic spire pulsing with focused clarity.',
  },
  {
    id: 'crystal-purple',
    name: 'Glowing Crystal — Purple',
    category: 'flora',
    cost: 35,
    description: 'Amethyst shard resonating with deep concentration.',
  },
  {
    id: 'crystal-green',
    name: 'Glowing Crystal — Green',
    category: 'flora',
    cost: 35,
    description: 'Emerald crystal channeling restorative earth vitality.',
  },
  {
    id: 'magic-mushrooms',
    name: 'Magic Mushrooms',
    category: 'flora',
    cost: 25,
    description: 'Glowing spotted fungi that shimmer gently in twilight.',
  },
  {
    id: 'clover-patch',
    name: 'Four-Leaf Clover Patch',
    category: 'flora',
    cost: 18,
    description: 'Rare lucky clovers offering exam day blessings.',
  },
];

export const DECORATIONS_MAP = DECORATIONS_LIST.reduce((acc, item) => {
  acc[item.id] = item;
  return acc;
}, {} as Record<string, DecorationItem>);

interface DecorationArtworkProps {
  id: string;
  size?: number;
}

export const DecorationArtwork: React.FC<DecorationArtworkProps> = ({ id, size = 64 }) => {
  return (
    <div
      className="relative flex items-end justify-center select-none"
      style={{ width: `${size}px`, height: `${size}px` }}
    >
      {/* Contact Shadow & Base Soil */}
      <svg
        className="absolute bottom-0 pointer-events-none"
        width={size * 0.8}
        height={size * 0.3}
        viewBox="0 0 80 30"
      >
        <ellipse cx="40" cy="18" rx="28" ry="8" fill="#1b3820" opacity="0.3" />
        <ellipse cx="40" cy="17" rx="12" ry="3.5" fill="#3d2a1c" opacity="0.6" />
      </svg>
      {renderDecorationSvg(id)}
    </div>
  );
};

function renderDecorationSvg(id: string): React.ReactNode {
  switch (id) {
    case 'squirrel':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <ellipse cx="28" cy="42" rx="12" ry="10" fill="#a0522d" />
          <circle cx="20" cy="34" r="8" fill="#b25d30" />
          <ellipse cx="40" cy="32" rx="10" ry="16" fill="#8b4513" transform="rotate(25 40 32)" />
          <circle cx="18" cy="32" r="1.5" fill="#fff" />
          <circle cx="17.5" cy="32" r="1" fill="#000" />
          <ellipse cx="14" cy="38" rx="3" ry="2" fill="#d7ccc8" />
        </svg>
      );
    case 'rabbit':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <ellipse cx="30" cy="45" rx="12" ry="9" fill="#f5f5f5" />
          <circle cx="22" cy="38" r="7" fill="#ffffff" />
          <ellipse cx="20" cy="22" rx="3" ry="9" fill="#ffcdd2" stroke="#fff" strokeWidth="1.5" />
          <ellipse cx="25" cy="23" rx="3" ry="8" fill="#ffcdd2" stroke="#fff" strokeWidth="1.5" />
          <circle cx="19" cy="36" r="1.2" fill="#000" />
          <circle cx="42" cy="44" r="3.5" fill="#f5f5f5" />
        </svg>
      );
    case 'hedgehog':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <path d="M16 48 Q 14 30 35 30 Q 52 30 50 48 Z" fill="#5d4037" />
          <ellipse cx="20" cy="45" rx="8" ry="6" fill="#d7ccc8" />
          <circle cx="17" cy="43" r="1.2" fill="#000" />
          <path d="M26 35 L 24 28 M 32 32 L 32 24 M 39 33 L 42 26 M 45 36 L 49 30" stroke="#3e2723" strokeWidth="2.2" strokeLinecap="round" />
        </svg>
      );
    case 'owl':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <ellipse cx="30" cy="38" rx="12" ry="15" fill="#795548" />
          <circle cx="25" cy="30" r="5" fill="#ffe082" />
          <circle cx="35" cy="30" r="5" fill="#ffe082" />
          <circle cx="25" cy="30" r="2.5" fill="#212121" />
          <circle cx="35" cy="30" r="2.5" fill="#212121" />
          <polygon points="30,34 28,39 32,39" fill="#ff9800" />
          <path d="M20 22 L 23 26 M 40 22 L 37 26" stroke="#4e342e" strokeWidth="3" strokeLinecap="round" />
        </svg>
      );
    case 'deer':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <ellipse cx="32" cy="40" rx="13" ry="8" fill="#a16207" />
          <path d="M22 38 L 18 24 L 23 20" stroke="#a16207" strokeWidth="4" strokeLinecap="round" fill="none" />
          <circle cx="24" cy="20" r="4.5" fill="#ca8a04" />
          <path d="M23 16 L 20 10 M 23 16 L 25 9" stroke="#713f12" strokeWidth="1.8" strokeLinecap="round" />
          <path d="M24 46 L 24 54 M 38 46 L 38 54" stroke="#713f12" strokeWidth="2" strokeLinecap="round" />
          <circle cx="32" cy="37" r="1" fill="#fef08a" />
          <circle cx="36" cy="39" r="1" fill="#fef08a" />
        </svg>
      );
    case 'turtle':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <ellipse cx="30" cy="45" rx="14" ry="9" fill="#2e7d32" stroke="#1b5e20" strokeWidth="1.5" />
          <circle cx="16" cy="44" r="4" fill="#66bb6a" />
          <circle cx="14.5" cy="43" r="0.8" fill="#000" />
          <path d="M24 45 L 36 45 M 30 38 L 30 52" stroke="#1b5e20" strokeWidth="1.2" />
        </svg>
      );
    case 'butterflies':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          {/* Blue Butterfly */}
          <path d="M22 28 C 16 20 12 32 22 34 C 14 38 18 46 24 38 Z" fill="#42a5f5" />
          <path d="M26 28 C 32 20 36 32 26 34 C 34 38 30 46 24 38 Z" fill="#1e88e5" />
          {/* Gold Butterfly */}
          <path d="M40 38 C 36 32 32 40 40 42 C 34 45 38 50 42 45 Z" fill="#ffd54f" />
          <path d="M44 38 C 48 32 52 40 44 42 C 50 45 46 50 42 45 Z" fill="#ffca28" />
        </svg>
      );
    case 'fireflies':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <circle cx="20" cy="25" r="3" fill="#eeff41" opacity="0.9" />
          <circle cx="20" cy="25" r="7" fill="#c6ff00" opacity="0.3" filter="blur(1px)" />
          <circle cx="42" cy="32" r="3.5" fill="#eeff41" opacity="0.9" />
          <circle cx="42" cy="32" r="8" fill="#c6ff00" opacity="0.3" filter="blur(1px)" />
          <circle cx="32" cy="45" r="2.5" fill="#eeff41" opacity="0.8" />
        </svg>
      );
    case 'log-cabin':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <rect x="18" y="32" width="24" height="18" rx="2" fill="#6d4c41" />
          <polygon points="14,32 30,16 46,32" fill="#3e2723" />
          <rect x="27" y="38" width="6" height="12" fill="#3e2723" />
          <rect x="36" y="35" width="4" height="4" fill="#ffe082" />
        </svg>
      );
    case 'wooden-bridge':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <path d="M12 48 Q 30 34 48 48" stroke="#5d4037" strokeWidth="5" fill="none" />
          <path d="M14 43 Q 30 29 46 43" stroke="#8d6e63" strokeWidth="2.5" fill="none" />
          <path d="M20 40 L 20 48 M 30 35 L 30 46 M 40 40 L 40 48" stroke="#4e342e" strokeWidth="2" />
        </svg>
      );
    case 'fountain':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <ellipse cx="30" cy="48" rx="16" ry="6" fill="#78909c" />
          <rect x="28" y="32" width="4" height="16" fill="#546e7a" />
          <ellipse cx="30" cy="32" rx="10" ry="4" fill="#90a4ae" />
          <path d="M30 32 Q 24 20 22 30 M 30 32 Q 36 20 38 30" stroke="#80deea" strokeWidth="1.8" fill="none" />
        </svg>
      );
    case 'lantern':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <rect x="26" y="30" width="8" height="14" rx="1" fill="#fff9c4" stroke="#424242" strokeWidth="1.5" />
          <polygon points="24,30 30,22 36,30" fill="#212121" />
          <line x1="30" y1="44" x2="30" y2="52" stroke="#424242" strokeWidth="2" />
          <circle cx="30" cy="37" r="8" fill="#ffe082" opacity="0.4" filter="blur(2px)" />
        </svg>
      );
    case 'pond':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <ellipse cx="30" cy="44" rx="20" ry="10" fill="#4fc3f7" stroke="#81c784" strokeWidth="2" />
          <circle cx="26" cy="43" r="3" fill="#388e3c" />
          <circle cx="36" cy="46" r="2.5" fill="#388e3c" />
          <circle cx="27" cy="41" r="1.5" fill="#f48fb1" />
        </svg>
      );
    case 'crystal-cyan':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <polygon points="30,12 36,32 30,50 24,32" fill="#00e5ff" opacity="0.9" />
          <polygon points="30,12 33,32 30,50" fill="#e0f7fa" />
          <polygon points="20,26 25,38 21,50 17,38" fill="#18ffff" opacity="0.75" />
          <circle cx="30" cy="30" r="14" fill="#00e5ff" opacity="0.25" filter="blur(3px)" />
        </svg>
      );
    case 'crystal-purple':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <polygon points="30,12 36,32 30,50 24,32" fill="#d500f9" opacity="0.9" />
          <polygon points="30,12 33,32 30,50" fill="#f3e5f5" />
          <polygon points="20,26 25,38 21,50 17,38" fill="#ea80fc" opacity="0.75" />
          <circle cx="30" cy="30" r="14" fill="#d500f9" opacity="0.25" filter="blur(3px)" />
        </svg>
      );
    case 'crystal-green':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <polygon points="30,12 36,32 30,50 24,32" fill="#00e676" opacity="0.9" />
          <polygon points="30,12 33,32 30,50" fill="#e8f5e9" />
          <polygon points="20,26 25,38 21,50 17,38" fill="#69f0ae" opacity="0.75" />
          <circle cx="30" cy="30" r="14" fill="#00e676" opacity="0.25" filter="blur(3px)" />
        </svg>
      );
    case 'flower-patch':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <circle cx="20" cy="42" r="4" fill="#ff4081" />
          <circle cx="20" cy="42" r="1.5" fill="#ffeb3b" />
          <circle cx="38" cy="44" r="4" fill="#7c4dff" />
          <circle cx="38" cy="44" r="1.5" fill="#ffeb3b" />
          <circle cx="28" cy="36" r="4.5" fill="#ffeb3b" />
          <circle cx="28" cy="36" r="1.5" fill="#ff5722" />
        </svg>
      );
    case 'magic-mushrooms':
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <rect x="23" y="36" width="5" height="12" rx="2" fill="#eceff1" />
          <path d="M16 36 C 16 24 35 24 35 36 Z" fill="#e91e63" />
          <circle cx="22" cy="30" r="1.8" fill="#fff" />
          <circle cx="30" cy="28" r="1.5" fill="#fff" />
          <rect x="36" y="40" width="4" height="10" rx="1.5" fill="#eceff1" />
          <path d="M30 40 C 30 30 46 30 46 40 Z" fill="#9c27b0" />
          <circle cx="38" cy="35" r="1.5" fill="#fff" />
        </svg>
      );
    default:
      // Generic organic garden element
      return (
        <svg viewBox="0 0 60 60" className="w-full h-full">
          <circle cx="30" cy="42" r="8" fill="#4caf50" />
          <circle cx="24" cy="45" r="5" fill="#81c784" />
          <circle cx="36" cy="45" r="5" fill="#81c784" />
        </svg>
      );
  }
}
