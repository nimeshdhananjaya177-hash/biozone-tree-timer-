import React from 'react';
import { TreeSpecies } from '../types';

export const TREE_SPECIES_LIST: TreeSpecies[] = [
  {
    id: 'basic-sapling',
    name: 'Basic Sapling',
    category: 'Starter',
    cost: 0,
    rarity: 'common',
    description: 'A delicate young sapling just rooted in fresh soil, symbolizing your first study commitment.',
    height: 60,
  },
  {
    id: 'evergreen-pine',
    name: 'Evergreen Pine',
    category: 'Conifer',
    cost: 20,
    rarity: 'common',
    description: 'A hardy, fragrant pine that stands resilient through long study nights.',
    height: 75,
  },
  {
    id: 'bushy-shrub',
    name: 'Bushy Shrub',
    category: 'Shrub',
    cost: 25,
    rarity: 'common',
    description: 'A lush rounded shrub with dense clusters of emerald leaves.',
    height: 55,
  },
  {
    id: 'young-birch',
    name: 'Young Birch',
    category: 'Deciduous',
    cost: 35,
    rarity: 'uncommon',
    description: 'Slender silver bark with fluttering mint-green foliage.',
    height: 70,
  },
  {
    id: 'forest-elm',
    name: 'Forest Elm',
    category: 'Deciduous',
    cost: 45,
    rarity: 'uncommon',
    description: 'An elegant vase-shaped canopy offering calm shade and steady energy.',
    height: 80,
  },
  {
    id: 'sprawling-oak',
    name: 'Sprawling Oak',
    category: 'Broadleaf',
    cost: 55,
    rarity: 'uncommon',
    description: 'Wide, sturdy boughs that represent deep comprehension and memory.',
    height: 85,
  },
  {
    id: 'tall-birch',
    name: 'Tall Birch',
    category: 'Deciduous',
    cost: 65,
    rarity: 'rare',
    description: 'A soaring white birch crowned with delicate golden-green leaves.',
    height: 95,
  },
  {
    id: 'dense-pine-cluster',
    name: 'Dense Pine Cluster',
    category: 'Conifer',
    cost: 75,
    rarity: 'rare',
    description: 'A triad of alpine needles creating a cozy woodland grove.',
    height: 85,
  },
  {
    id: 'cherry-blossom',
    name: 'Cherry Blossom',
    category: 'Ornamental',
    cost: 90,
    rarity: 'rare',
    description: 'Delicate pastel pink sakura petals symbolizing mindful, peaceful concentration.',
    height: 80,
  },
  {
    id: 'maple-tree',
    name: 'Maple Tree',
    category: 'Broadleaf',
    cost: 100,
    rarity: 'rare',
    description: 'Crisp green palmate leaves that rustle softly with every breakthrough.',
    height: 85,
  },
  {
    id: 'autumn-maple',
    name: 'Autumn Maple',
    category: 'Broadleaf',
    cost: 120,
    rarity: 'epic',
    description: 'Fiery amber and crimson crown glowing with warm academic passion.',
    height: 85,
  },
  {
    id: 'weeping-willow',
    name: 'Weeping Willow',
    category: 'Waterfront',
    cost: 140,
    rarity: 'epic',
    description: 'Sweeping tendrils of soft lime leaves creating a serene quiet sanctuary.',
    height: 90,
  },
  {
    id: 'twisted-bonsai-oak',
    name: 'Twisted Bonsai Oak',
    category: 'Artisan',
    cost: 160,
    rarity: 'epic',
    description: 'Sculpted through disciplined practice with ancient weathered character.',
    height: 70,
  },
  {
    id: 'ancient-oak',
    name: 'Ancient Oak',
    category: 'Broadleaf',
    cost: 180,
    rarity: 'epic',
    description: 'Centuries of quiet strength in a colossal gnarled trunk.',
    height: 100,
  },
  {
    id: 'flowering-shrub',
    name: 'Flowering Shrub',
    category: 'Ornamental',
    cost: 200,
    rarity: 'epic',
    description: 'Bursting with fragrant violet blossoms that celebrate completed chapters.',
    height: 60,
  },
  {
    id: 'golden-canopy-tree',
    name: 'Golden Canopy Tree',
    category: 'Celestial',
    cost: 240,
    rarity: 'legendary',
    description: 'Glints with pure solar warmth, radiating clarity of mind.',
    height: 95,
  },
  {
    id: 'magic-glowing-pine',
    name: 'Magic Glowing Pine',
    category: 'Mystic',
    cost: 280,
    rarity: 'legendary',
    description: 'Bioluminescent needles emitting a soft cyan aura across the turf.',
    height: 90,
  },
  {
    id: 'ancient-golden-pine',
    name: 'Ancient Golden Pine',
    category: 'Mystic',
    cost: 320,
    rarity: 'legendary',
    description: 'An immortal conifer dusted with timeless starlight.',
    height: 105,
  },
  {
    id: 'magic-forest-cluster',
    name: 'Magic Forest Cluster',
    category: 'Enchanted',
    cost: 380,
    rarity: 'legendary',
    description: 'A harmonious trio of glowing willow, pine, and fairy crystals.',
    height: 100,
  },
  {
    id: 'grand-mythic-world-tree',
    name: 'Grand Mythic World Tree',
    category: 'Mythic',
    cost: 500,
    rarity: 'mythic',
    description: 'The ultimate Yggdrasil of Bio Zone: Colossal runic bark, cascading starry vines, and cosmic canopy.',
    height: 120,
  },
];

// Helper to look up species
export const TREE_SPECIES_MAP: Record<string, TreeSpecies> = TREE_SPECIES_LIST.reduce(
  (acc, t) => {
    acc[t.id] = t;
    return acc;
  },
  {} as Record<string, TreeSpecies>
);

interface TreeArtworkProps {
  speciesId: string;
  size?: number; // visual height / box width
  growthProgress?: number; // 0.0 to 1.0
  isWilting?: boolean;
}

// Hermite smoothstep for mathematically continuous C1 progression
function smoothstep(min: number, max: number, val: number): number {
  if (val <= min) return 0;
  if (val >= max) return 1;
  const t = (val - min) / (max - min);
  return t * t * (3 - 2 * t);
}

export const TreeArtwork: React.FC<TreeArtworkProps> = ({
  speciesId,
  size = 120,
  growthProgress = 1.0,
  isWilting = false,
}) => {
  // Normalize progress strictly between 0 and 1
  const p = Math.max(0, Math.min(1, growthProgress));

  // 1. Unified Subterranean Root Anchoring: Monotonically deepens as the tree grows
  const shadowRadiusX = 26 + p * 16;
  const shadowRadiusY = 7 + p * 4;
  const rootDepth = 12 + p * 8;
  const radicleLength = smoothstep(0.01, 0.28, p);

  // 2. Continuous Germinating Seed & Cotyledon Transition:
  // The seed is nestled in loam at p=0, settles firmly, splits as the shoot emerges,
  // and smoothly integrates as the woody root collar flare at the trunk base
  const seedPresence = Math.max(0, 1 - smoothstep(0.06, 0.30, p));
  const seedSinkY = smoothstep(0, 0.14, p) * 5; // Sinks gently 5px into rich loam

  // Tender sprout tip uncurling directly from the seed into the rising trunk
  const sproutTipPresence = p < 0.03 ? 0 : Math.max(0, 1 - smoothstep(0.12, 0.25, p));
  const sproutTipScale = smoothstep(0.03, 0.10, p);

  // 3. Continuous Species Architecture Growth (Direct Parametric Mathematical Scale):
  // Scaling anchored at bottom center so the trunk emerges directly from the seed location.
  // Sy (height) and Sx (width) are smooth monotonic functions across the timer duration.
  // NO abrupt stage resets and NO CSS transitions fighting continuous requestAnimationFrame updates.
  const treeHeightProgress = smoothstep(0.05, 0.95, p);
  const treeWidthProgress = smoothstep(0.09, 0.98, p);
  const scaleY = Math.pow(treeHeightProgress, 0.82);
  const scaleX = Math.pow(treeWidthProgress, 0.92);
  const treeOpacity = smoothstep(0.04, 0.14, p);

  // Emotional Wilting Animation Attributes (only triggered on graceful cancel)
  const wiltFilter = isWilting
    ? 'grayscale(0.8) sepia(0.45) saturate(0.6) brightness(0.68) contrast(0.95)'
    : 'none';
  const wiltTransform = isWilting
    ? 'scale(0.82) rotate(-9deg) translateY(12px) skewX(3deg)'
    : 'none';

  return (
    <div
      className="relative flex items-end justify-center select-none"
      style={{
        width: `${size}px`,
        height: `${size}px`,
        filter: wiltFilter,
        transition: isWilting
          ? 'filter 1.8s ease-in-out, transform 2.2s cubic-bezier(0.25, 0.8, 0.25, 1)'
          : 'none',
        transform: wiltTransform,
      }}
    >
      {/* Root Grounding & Contact Shadow */}
      <svg
        className="absolute bottom-0 pointer-events-none"
        width={size * 0.95}
        height={size * 0.32}
        viewBox="0 0 100 35"
        style={{ overflow: 'visible' }}
      >
        <defs>
          <radialGradient id={`tree-shadow-${speciesId}`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#1b3820" stopOpacity={isWilting ? 0.2 : 0.45} />
            <stop offset="60%" stopColor="#244d2b" stopOpacity={isWilting ? 0.08 : 0.22} />
            <stop offset="100%" stopColor="#244d2b" stopOpacity={0} />
          </radialGradient>
          <linearGradient id={`soil-flare-${speciesId}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#4a3728" />
            <stop offset="60%" stopColor="#3d2a1c" />
            <stop offset="100%" stopColor="#2d1e13" />
          </linearGradient>
        </defs>

        {/* Ambient Contact Shadow */}
        <ellipse
          cx="50"
          cy="22"
          rx={shadowRadiusX}
          ry={shadowRadiusY}
          fill={`url(#tree-shadow-${speciesId})`}
        />

        {/* Earthen Root Flare Mound */}
        <ellipse cx="50" cy="21" rx={rootDepth} ry={4.5 + p * 1.5} fill={`url(#soil-flare-${speciesId})`} opacity="0.88" />
        
        {/* Radiating Subterranean Anchor Roots Monotonically Deepening into Soil */}
        <path
          d={`M${50 - radicleLength * 12} 22 Q 48 21, 50 20 Q 52 21, ${50 + radicleLength * 12} 22`}
          stroke="#332115"
          strokeWidth={1.4 + p * 1.2}
          strokeLinecap="round"
          fill="none"
          opacity={0.5 + p * 0.4}
        />
        {radicleLength > 0.4 && (
          <path
            d={`M${48 - radicleLength * 8} 23 Q 46 25, 43 27 M${52 + radicleLength * 8} 23 Q 54 25, 57 27`}
            stroke="#2d1e13"
            strokeWidth="1.2"
            strokeLinecap="round"
            fill="none"
            opacity={0.65}
          />
        )}
        {/* Soft grass blades around root collar */}
        <path d="M43 21 L 41 17 M 47 21.5 L 46 16 M 53 21.5 L 55 16.5 M 57 22 L 59 17.5" stroke="#48995a" strokeWidth="1.3" strokeLinecap="round" />
      </svg>

      {/* Biological Seed Resting in Earth at p=0, Germinating as Roots Form */}
      {seedPresence > 0 && (
        <div
          className="absolute bottom-3 z-10 pointer-events-none"
          style={{
            transform: `translateY(${seedSinkY}px) scale(${1 - seedSinkY * 0.05})`,
            opacity: seedPresence,
          }}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" className="overflow-visible">
            <defs>
              <linearGradient id="seedGradOrganic" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#b07d58" />
                <stop offset="45%" stopColor="#8d5b36" />
                <stop offset="100%" stopColor="#533118" />
              </linearGradient>
            </defs>
            {/* Seed Body */}
            <path
              d="M12 3 C16 7, 18 13, 17 18 C16 21, 8 21, 7 18 C6 13, 8 7, 12 3 Z"
              fill="url(#seedGradOrganic)"
              stroke="#3d2008"
              strokeWidth="1.1"
            />
            {/* Primary root radicle pushing into loam */}
            {radicleLength > 0.1 && (
              <path
                d="M12 18 Q 12 22, 13 25"
                stroke="#d4a373"
                strokeWidth="1.5"
                strokeLinecap="round"
                fill="none"
                opacity={radicleLength}
              />
            )}
            {/* Embryonic life spark inside the seed */}
            <circle cx="12" cy="13" r="2.2" fill="#fef08a" opacity={0.65} />
          </svg>
        </div>
      )}

      {/* Tender First Cotyledon Sprout emerging from Seed Apex */}
      {sproutTipPresence > 0 && (
        <div
          className="absolute bottom-5 z-10 pointer-events-none origin-bottom"
          style={{
            transform: `scale(${sproutTipScale})`,
            opacity: sproutTipPresence,
          }}
        >
          <svg width="28" height="34" viewBox="0 0 28 34" className="overflow-visible">
            <defs>
              <linearGradient id="sprout-stem" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#86efac" />
                <stop offset="100%" stopColor="#22c55e" />
              </linearGradient>
            </defs>
            <path
              d="M14 32 Q 13 22, 14 15"
              stroke="url(#sprout-stem)"
              strokeWidth="2.6"
              strokeLinecap="round"
              fill="none"
            />
            <ellipse
              cx="9"
              cy="14"
              rx="5"
              ry="3"
              fill="#4ade80"
              stroke="#15803d"
              strokeWidth="0.7"
              transform="rotate(-26 9 14)"
            />
            <ellipse
              cx="19"
              cy="14"
              rx="5"
              ry="3"
              fill="#86efac"
              stroke="#15803d"
              strokeWidth="0.7"
              transform="rotate(26 19 14)"
            />
          </svg>
        </div>
      )}

      {/* Continuous Progressive Species Tree Architecture */}
      {scaleY > 0 && (
        <div
          className="w-full h-full flex items-end justify-center origin-bottom relative"
          style={{
            transform: `scale(${scaleX}, ${scaleY})`,
            opacity: treeOpacity,
          }}
        >
          {renderTreeSvg(speciesId, size)}

          {/* Culminating Development: Blossoming & Fruiting Lifecycle */}
          {renderTreeBlossomsAndFruits(speciesId, p, isWilting)}
        </div>
      )}

      {/* Graceful Falling Leaves during Emotional Wilting (only on user cancel) */}
      {isWilting && (
        <div className="absolute inset-0 pointer-events-none overflow-visible z-20">
          {[
            { id: 1, left: '38%', delay: '0.2s', dur: '2.8s' },
            { id: 2, left: '55%', delay: '0.6s', dur: '3.2s' },
            { id: 3, left: '26%', delay: '1.0s', dur: '2.6s' },
            { id: 4, left: '68%', delay: '1.4s', dur: '3.0s' },
            { id: 5, left: '48%', delay: '1.8s', dur: '2.9s' },
          ].map((leaf) => (
            <div
              key={leaf.id}
              className="absolute top-8 animate-leaf-fall"
              style={{
                left: leaf.left,
                animationDelay: leaf.delay,
                animationDuration: leaf.dur,
              }}
            >
              <svg width="10" height="10" viewBox="0 0 12 12">
                <path
                  d="M6 1 C8 3, 10 7, 6 11 C2 7, 4 3, 6 1 Z"
                  fill="#b45309"
                  opacity="0.8"
                  transform={`rotate(${leaf.id * 35})`}
                />
              </svg>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// Vector Artworks for all 20 Tree Species
function renderTreeSvg(speciesId: string, size: number): React.ReactNode {
  switch (speciesId) {
    case 'basic-sapling':
      // Redesigned: organic young sapling, gentle curved brown trunk entering soil, natural layered leaves, delicate branches
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full" style={{ overflow: 'visible' }}>
          <defs>
            <linearGradient id="bs-trunk" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#634832" />
              <stop offset="40%" stopColor="#8d6e53" />
              <stop offset="100%" stopColor="#563b25" />
            </linearGradient>
            <linearGradient id="bs-leaf-1" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#9ee37d" />
              <stop offset="100%" stopColor="#58b34c" />
            </linearGradient>
            <linearGradient id="bs-leaf-2" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#b4f08a" />
              <stop offset="100%" stopColor="#43a047" />
            </linearGradient>
            <linearGradient id="bs-leaf-shadow" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#388e3c" />
              <stop offset="100%" stopColor="#256029" />
            </linearGradient>
          </defs>

          {/* Curved Natural Trunk entering soil with root base */}
          <path
            d="M50 102 C49 88, 52 75, 48 62 C46 54, 49 46, 51 38"
            stroke="url(#bs-trunk)"
            strokeWidth="5.5"
            strokeLinecap="round"
            fill="none"
          />
          {/* Trunk Root flares into soil */}
          <path d="M46 102 Q48 96 50 94 Q52 96 54 102" fill="#563b25" />
          <path d="M44 102 Q47 98 48 94" stroke="#48311f" strokeWidth="2" strokeLinecap="round" fill="none" />
          <path d="M56 102 Q53 98 52 94" stroke="#48311f" strokeWidth="2" strokeLinecap="round" fill="none" />

          {/* Natural Stem Branches */}
          {/* Lower left branch */}
          <path d="M49 70 C42 66, 35 68, 30 65" stroke="url(#bs-trunk)" strokeWidth="3" strokeLinecap="round" fill="none" />
          {/* Lower right branch */}
          <path d="M50 63 C57 58, 65 61, 71 57" stroke="url(#bs-trunk)" strokeWidth="2.8" strokeLinecap="round" fill="none" />
          {/* Upper left branch */}
          <path d="M49 48 C43 42, 38 43, 33 40" stroke="url(#bs-trunk)" strokeWidth="2.4" strokeLinecap="round" fill="none" />
          {/* Upper right branch */}
          <path d="M51 44 C56 38, 62 39, 66 35" stroke="url(#bs-trunk)" strokeWidth="2.2" strokeLinecap="round" fill="none" />

          {/* Layered Fresh Leaves (Shadow layers) */}
          <path d="M26 66 C22 62, 23 55, 30 57 C37 59, 36 67, 26 66 Z" fill="url(#bs-leaf-shadow)" />
          <path d="M68 60 C74 56, 75 49, 68 48 C61 47, 60 57, 68 60 Z" fill="url(#bs-leaf-shadow)" />
          <path d="M29 42 C25 36, 27 30, 34 32 C41 34, 38 43, 29 42 Z" fill="url(#bs-leaf-shadow)" />

          {/* Layered Fresh Leaves (Bright front layers) */}
          <path d="M28 64 C23 60, 24 53, 31 55 C38 57, 38 65, 28 64 Z" fill="url(#bs-leaf-1)" />
          <path d="M69 57 C75 53, 76 46, 69 45 C62 44, 61 54, 69 57 Z" fill="url(#bs-leaf-2)" />
          <path d="M31 39 C27 33, 29 27, 36 29 C43 31, 40 40, 31 39 Z" fill="url(#bs-leaf-1)" />
          <path d="M64 34 C70 30, 71 23, 64 22 C57 21, 57 31, 64 34 Z" fill="url(#bs-leaf-2)" />

          {/* Crown Leaves */}
          <path d="M51 35 C44 26, 45 15, 51 12 C57 15, 58 26, 51 35 Z" fill="url(#bs-leaf-2)" />
          <path d="M46 28 C38 23, 40 14, 47 17 C52 20, 51 28, 46 28 Z" fill="url(#bs-leaf-1)" />
          <path d="M56 28 C64 23, 62 14, 55 17 C50 20, 51 28, 56 28 Z" fill="url(#bs-leaf-1)" />

          {/* Leaf Midrib Vein Details */}
          <path d="M51 32 L51 18" stroke="#71c456" strokeWidth="1" strokeLinecap="round" />
          <path d="M30 61 L36 57" stroke="#71c456" strokeWidth="0.8" strokeLinecap="round" />
          <path d="M68 53 L62 49" stroke="#71c456" strokeWidth="0.8" strokeLinecap="round" />

          {/* Soft Ground Grass Tufts at base */}
          <path d="M45 102 C43 97, 40 98, 38 96" stroke="#48995a" strokeWidth="1.5" strokeLinecap="round" fill="none" />
          <path d="M54 102 C56 97, 59 98, 62 96" stroke="#48995a" strokeWidth="1.5" strokeLinecap="round" fill="none" />
        </svg>
      );

    case 'evergreen-pine':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <defs>
            <linearGradient id="ep-trunk" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#4a3525" />
              <stop offset="100%" stopColor="#302014" />
            </linearGradient>
            <linearGradient id="ep-tier1" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#387a50" />
              <stop offset="100%" stopColor="#1e4d2f" />
            </linearGradient>
            <linearGradient id="ep-tier2" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#4ca16a" />
              <stop offset="100%" stopColor="#28633e" />
            </linearGradient>
          </defs>
          <path d="M47 102 L48 70 L52 70 L53 102 Z" fill="url(#ep-trunk)" />
          {/* Pine Tiers */}
          <path d="M18 78 L50 48 L82 78 L65 74 L50 68 L35 74 Z" fill="url(#ep-tier1)" />
          <path d="M24 62 L50 36 L76 62 L62 58 L50 53 L38 58 Z" fill="url(#ep-tier2)" />
          <path d="M30 46 L50 20 L70 46 L58 43 L50 38 L42 43 Z" fill="url(#ep-tier1)" />
          <path d="M38 28 L50 8 L62 28 L50 24 Z" fill="url(#ep-tier2)" />
          {/* Highlights */}
          <path d="M50 8 L50 78" stroke="#68c98c" strokeWidth="1.2" opacity="0.4" strokeDasharray="3,3" />
        </svg>
      );

    case 'bushy-shrub':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <defs>
            <radialGradient id="shrub-grad1" cx="40%" cy="35%" r="60%">
              <stop offset="0%" stopColor="#81c784" />
              <stop offset="70%" stopColor="#388e3c" />
              <stop offset="100%" stopColor="#1b5e20" />
            </radialGradient>
            <radialGradient id="shrub-grad2" cx="35%" cy="30%" r="65%">
              <stop offset="0%" stopColor="#a5d6a7" />
              <stop offset="80%" stopColor="#43a047" />
              <stop offset="100%" stopColor="#2e7d32" />
            </radialGradient>
          </defs>
          <path d="M48 102 L50 80 L52 102" stroke="#5d4037" strokeWidth="4" strokeLinecap="round" />
          <circle cx="34" cy="74" r="22" fill="url(#shrub-grad1)" />
          <circle cx="66" cy="74" r="22" fill="url(#shrub-grad1)" />
          <circle cx="50" cy="58" r="28" fill="url(#shrub-grad2)" />
          <circle cx="35" cy="52" r="16" fill="url(#shrub-grad2)" opacity="0.9" />
          <circle cx="65" cy="52" r="16" fill="url(#shrub-grad2)" opacity="0.9" />
          {/* Highlights */}
          <ellipse cx="44" cy="46" rx="10" ry="6" fill="#c8e6c9" opacity="0.45" />
        </svg>
      );

    case 'young-birch':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <defs>
            <linearGradient id="birch-bark" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#eceff1" />
              <stop offset="50%" stopColor="#ffffff" />
              <stop offset="100%" stopColor="#cfd8dc" />
            </linearGradient>
            <radialGradient id="birch-leaves" cx="45%" cy="35%" r="55%">
              <stop offset="0%" stopColor="#c5e1a5" />
              <stop offset="65%" stopColor="#7cb342" />
              <stop offset="100%" stopColor="#4b831f" />
            </radialGradient>
          </defs>
          {/* Slender white trunk with marks */}
          <path d="M48 102 Q 51 65 49 28 L 52 28 Q 54 65 52 102 Z" fill="url(#birch-bark)" />
          <path d="M48 85 H 52 M 49 68 H 53 M 49 50 H 52 M 48 35 H 51" stroke="#37474f" strokeWidth="1.5" />
          {/* Floating leafy canopies */}
          <ellipse cx="40" cy="40" rx="16" ry="14" fill="url(#birch-leaves)" />
          <ellipse cx="62" cy="35" rx="18" ry="15" fill="url(#birch-leaves)" />
          <ellipse cx="50" cy="22" rx="15" ry="14" fill="url(#birch-leaves)" />
        </svg>
      );

    case 'forest-elm':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <defs>
            <radialGradient id="elm-leaf" cx="40%" cy="35%" r="60%">
              <stop offset="0%" stopColor="#9ccc65" />
              <stop offset="70%" stopColor="#558b2f" />
              <stop offset="100%" stopColor="#33691e" />
            </radialGradient>
          </defs>
          <path d="M46 102 C 48 75 42 60 36 45 M 54 102 C 52 75 58 60 64 45 M 50 70 L 50 40" stroke="#4e342e" strokeWidth="5" strokeLinecap="round" />
          <path d="M25 45 C 20 20 50 15 50 30 C 50 15 80 20 75 45 C 85 65 65 75 50 65 C 35 75 15 65 25 45 Z" fill="url(#elm-leaf)" />
        </svg>
      );

    case 'sprawling-oak':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <defs>
            <radialGradient id="oak-grad" cx="40%" cy="35%" r="60%">
              <stop offset="0%" stopColor="#81c784" />
              <stop offset="60%" stopColor="#388e3c" />
              <stop offset="100%" stopColor="#1b5e20" />
            </radialGradient>
          </defs>
          <path d="M42 102 C 46 80 44 65 30 55 M 58 102 C 54 80 56 65 70 55 M 50 75 L 50 50" stroke="#5d4037" strokeWidth="7" strokeLinecap="round" />
          <circle cx="30" cy="45" r="22" fill="url(#oak-grad)" />
          <circle cx="70" cy="45" r="22" fill="url(#oak-grad)" />
          <circle cx="50" cy="35" r="26" fill="url(#oak-grad)" />
          <circle cx="50" cy="52" r="20" fill="url(#oak-grad)" opacity="0.95" />
        </svg>
      );

    case 'tall-birch':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <path d="M48 102 L 50 15 L 53 102 Z" fill="#cfd8dc" stroke="#90a4ae" strokeWidth="0.5" />
          <path d="M49 90 H 52 M 49 70 H 52 M 50 50 H 53 M 50 30 H 52" stroke="#263238" strokeWidth="1.5" />
          <ellipse cx="50" cy="30" rx="20" ry="24" fill="#81c784" />
          <ellipse cx="48" cy="22" rx="14" ry="16" fill="#a5d6a7" />
          <ellipse cx="52" cy="12" rx="10" ry="10" fill="#c8e6c9" />
        </svg>
      );

    case 'dense-pine-cluster':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          {/* Left pine */}
          <path d="M30 102 L 30 75" stroke="#3e2723" strokeWidth="3" />
          <polygon points="12,78 30,45 48,78" fill="#2d6a4f" />
          <polygon points="16,60 30,32 44,60" fill="#40916c" />
          {/* Right pine */}
          <path d="M70 102 L 70 75" stroke="#3e2723" strokeWidth="3" />
          <polygon points="52,78 70,45 88,78" fill="#2d6a4f" />
          <polygon points="56,60 70,32 84,60" fill="#40916c" />
          {/* Tall center pine */}
          <path d="M50 102 L 50 65" stroke="#4e342e" strokeWidth="4" />
          <polygon points="26,72 50,30 74,72" fill="#1b4332" />
          <polygon points="32,50 50,15 68,50" fill="#2d6a4f" />
          <polygon points="38,32 50,5 62,32" fill="#52b788" />
        </svg>
      );

    case 'cherry-blossom':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <defs>
            <radialGradient id="sakura-pink" cx="40%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#fce4ec" />
              <stop offset="45%" stopColor="#f48fb1" />
              <stop offset="100%" stopColor="#c2185b" />
            </radialGradient>
          </defs>
          <path d="M46 102 C 48 70 40 55 32 45 M 54 102 C 52 70 60 55 68 45 M 50 65 L 50 42" stroke="#5d4037" strokeWidth="5.5" strokeLinecap="round" />
          <circle cx="32" cy="40" r="18" fill="url(#sakura-pink)" />
          <circle cx="68" cy="40" r="18" fill="url(#sakura-pink)" />
          <circle cx="50" cy="30" r="22" fill="url(#sakura-pink)" />
          <circle cx="50" cy="48" r="16" fill="url(#sakura-pink)" opacity="0.9" />
          {/* Falling flower petals */}
          <circle cx="28" cy="70" r="2.5" fill="#f8bbd0" />
          <circle cx="72" cy="68" r="2.2" fill="#f8bbd0" />
          <circle cx="45" cy="80" r="2" fill="#f48fb1" />
        </svg>
      );

    case 'maple-tree':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <path d="M48 102 L 50 55 M 50 70 L 35 55 M 50 65 L 65 50" stroke="#4e342e" strokeWidth="5" strokeLinecap="round" />
          <path d="M50 18 L 62 32 L 80 30 L 70 48 L 78 62 L 60 62 L 50 78 L 40 62 L 22 62 L 30 48 L 20 30 L 38 32 Z" fill="#66bb6a" />
          <path d="M50 25 L 58 35 L 70 33 L 62 46 L 68 56 L 55 56 L 50 68 L 45 56 L 32 56 L 38 46 L 30 33 L 42 35 Z" fill="#81c784" />
        </svg>
      );

    case 'autumn-maple':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <defs>
            <radialGradient id="autumn-glow" cx="45%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#fff3e0" />
              <stop offset="35%" stopColor="#ff9800" />
              <stop offset="85%" stopColor="#d84315" />
              <stop offset="100%" stopColor="#bf360c" />
            </radialGradient>
          </defs>
          <path d="M47 102 C 50 70 44 55 35 45 M 53 102 C 50 70 56 55 65 45" stroke="#3e2723" strokeWidth="5.5" strokeLinecap="round" />
          <circle cx="34" cy="44" r="20" fill="url(#autumn-glow)" />
          <circle cx="66" cy="44" r="20" fill="url(#autumn-glow)" />
          <circle cx="50" cy="32" r="25" fill="url(#autumn-glow)" />
          {/* Amber fallen leaves */}
          <circle cx="38" cy="98" r="3" fill="#ff9800" />
          <circle cx="62" cy="100" r="3" fill="#d84315" />
        </svg>
      );

    case 'weeping-willow':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <defs>
            <linearGradient id="willow-droop" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#aed581" />
              <stop offset="100%" stopColor="#689f38" />
            </linearGradient>
          </defs>
          <path d="M48 102 Q 52 65 50 42" stroke="#5d4037" strokeWidth="6" strokeLinecap="round" />
          {/* Cascading droops */}
          <path d="M50 42 Q 25 45 20 80 M 50 42 Q 35 50 32 85 M 50 42 Q 65 50 68 85 M 50 42 Q 75 45 80 80 M 50 42 Q 45 55 45 88 M 50 42 Q 55 55 55 88" stroke="url(#willow-droop)" strokeWidth="4.5" strokeLinecap="round" fill="none" />
          <circle cx="50" cy="40" r="16" fill="#8bc34a" opacity="0.8" />
        </svg>
      );

    case 'twisted-bonsai-oak':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <path d="M45 102 C 52 85 30 75 40 60 C 48 48 65 55 60 40 L 55 35" stroke="#4e342e" strokeWidth="6" strokeLinecap="round" fill="none" />
          <ellipse cx="35" cy="55" rx="14" ry="8" fill="#388e3c" />
          <ellipse cx="65" cy="42" rx="18" ry="10" fill="#4caf50" />
          <ellipse cx="50" cy="30" rx="15" ry="9" fill="#81c784" />
        </svg>
      );

    case 'ancient-oak':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <defs>
            <radialGradient id="ancient-oak-grad" cx="40%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#a5d6a7" />
              <stop offset="50%" stopColor="#388e3c" />
              <stop offset="100%" stopColor="#1b5e20" />
            </radialGradient>
          </defs>
          <path d="M38 102 C 45 75 40 60 25 50 M 62 102 C 55 75 60 60 75 50 M 45 70 L 45 42 M 55 70 L 55 42" stroke="#3e2723" strokeWidth="8" strokeLinecap="round" />
          <circle cx="26" cy="42" r="22" fill="url(#ancient-oak-grad)" />
          <circle cx="74" cy="42" r="22" fill="url(#ancient-oak-grad)" />
          <circle cx="50" cy="30" r="30" fill="url(#ancient-oak-grad)" />
          <circle cx="50" cy="50" r="22" fill="url(#ancient-oak-grad)" opacity="0.9" />
        </svg>
      );

    case 'flowering-shrub':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <circle cx="35" cy="70" r="20" fill="#43a047" />
          <circle cx="65" cy="70" r="20" fill="#43a047" />
          <circle cx="50" cy="55" r="25" fill="#66bb6a" />
          {/* Lavender flowers */}
          <circle cx="32" cy="65" r="4" fill="#ab47bc" />
          <circle cx="48" cy="48" r="4.5" fill="#ba68c8" />
          <circle cx="66" cy="62" r="4" fill="#ab47bc" />
          <circle cx="56" cy="66" r="3.5" fill="#ce93d8" />
          <circle cx="38" cy="52" r="3.5" fill="#e1bee7" />
        </svg>
      );

    case 'golden-canopy-tree':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <defs>
            <radialGradient id="solar-gold" cx="45%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#fff9c4" />
              <stop offset="40%" stopColor="#fbc02d" />
              <stop offset="85%" stopColor="#f57f17" />
              <stop offset="100%" stopColor="#e65100" />
            </radialGradient>
          </defs>
          <path d="M47 102 C 50 70 45 55 35 42 M 53 102 C 50 70 55 55 65 42" stroke="#4e342e" strokeWidth="6" strokeLinecap="round" />
          <circle cx="34" cy="42" r="22" fill="url(#solar-gold)" />
          <circle cx="66" cy="42" r="22" fill="url(#solar-gold)" />
          <circle cx="50" cy="30" r="28" fill="url(#solar-gold)" />
          {/* Radiant sparkling aura */}
          <circle cx="50" cy="30" r="32" stroke="#ffeb3b" strokeWidth="1" opacity="0.6" strokeDasharray="4,4" />
        </svg>
      );

    case 'magic-glowing-pine':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <defs>
            <linearGradient id="magic-cyan" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#80deea" />
              <stop offset="50%" stopColor="#00acc1" />
              <stop offset="100%" stopColor="#006064" />
            </linearGradient>
          </defs>
          <path d="M48 102 L 50 65 L 52 102" stroke="#37474f" strokeWidth="5" />
          <polygon points="18,78 50,45 82,78" fill="url(#magic-cyan)" />
          <polygon points="24,60 50,32 76,60" fill="url(#magic-cyan)" />
          <polygon points="32,42 50,15 68,42" fill="url(#magic-cyan)" />
          <polygon points="40,25 50,5 60,25" fill="#b2ebf2" />
          {/* Bioluminescent sparks */}
          <circle cx="36" cy="55" r="2" fill="#e0f7fa" />
          <circle cx="62" cy="45" r="2" fill="#e0f7fa" />
          <circle cx="50" cy="22" r="2.5" fill="#ffffff" />
        </svg>
      );

    case 'ancient-golden-pine':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <defs>
            <linearGradient id="gold-pine" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#fff59d" />
              <stop offset="50%" stopColor="#fbc02d" />
              <stop offset="100%" stopColor="#b26a00" />
            </linearGradient>
          </defs>
          <path d="M48 102 L 50 60 L 52 102" stroke="#4e342e" strokeWidth="5.5" />
          <polygon points="15,75 50,40 85,75" fill="url(#gold-pine)" />
          <polygon points="22,58 50,28 78,58" fill="url(#gold-pine)" />
          <polygon points="30,40 50,12 70,40" fill="url(#gold-pine)" />
          <polygon points="38,22 50,4 62,22" fill="#fffde7" />
          <circle cx="50" cy="4" r="3" fill="#ffe082" />
        </svg>
      );

    case 'magic-forest-cluster':
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          {/* Left glowing birch */}
          <path d="M28 102 L 28 50" stroke="#cfd8dc" strokeWidth="3" />
          <circle cx="28" cy="40" r="16" fill="#80cbc4" />
          {/* Right glowing sakura */}
          <path d="M72 102 L 72 50" stroke="#5d4037" strokeWidth="3" />
          <circle cx="72" cy="40" r="16" fill="#f48fb1" />
          {/* Center ancient mystical tree */}
          <path d="M50 102 L 50 45" stroke="#3e2723" strokeWidth="5.5" />
          <circle cx="50" cy="30" r="24" fill="#a5d6a7" />
          <circle cx="50" cy="22" r="14" fill="#c8e6c9" />
          {/* Magic motes */}
          <circle cx="38" cy="25" r="2" fill="#fff59d" />
          <circle cx="62" cy="25" r="2" fill="#80deea" />
        </svg>
      );

    case 'grand-mythic-world-tree':
    default:
      // Ultimate Grand Mythic World Tree
      return (
        <svg viewBox="0 0 100 110" className="w-full h-full">
          <defs>
            <radialGradient id="mythic-canopy" cx="45%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#e8f5e9" />
              <stop offset="25%" stopColor="#a5d6a7" />
              <stop offset="55%" stopColor="#43a047" />
              <stop offset="85%" stopColor="#1b5e20" />
              <stop offset="100%" stopColor="#0d3311" />
            </radialGradient>
            <linearGradient id="rune-glow" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#64ffda" />
              <stop offset="100%" stopColor="#00b0ff" />
            </linearGradient>
          </defs>
          {/* Colossal ancient trunk with spreading roots */}
          <path d="M32 102 C 40 70 38 50 20 40 M 68 102 C 60 70 62 50 80 40 M 42 75 L 40 35 M 58 75 L 60 35" stroke="#332115" strokeWidth="10" strokeLinecap="round" />
          {/* Glowing Runic Carvings on trunk */}
          <path d="M48 85 L 52 88 L 48 92 M 52 72 L 48 76 L 52 80" stroke="url(#rune-glow)" strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.9" />
          
          {/* Massive Layered Ancient Canopy */}
          <circle cx="22" cy="40" r="22" fill="url(#mythic-canopy)" />
          <circle cx="78" cy="40" r="22" fill="url(#mythic-canopy)" />
          <circle cx="50" cy="26" r="30" fill="url(#mythic-canopy)" />
          <circle cx="36" cy="18" r="18" fill="#c8e6c9" opacity="0.8" />
          <circle cx="64" cy="18" r="18" fill="#c8e6c9" opacity="0.8" />

          {/* Hanging Celestial Vines & Blossoms */}
          <path d="M22 52 Q 24 68 22 76 M 78 52 Q 76 68 78 76 M 35 48 Q 33 65 35 72 M 65 48 Q 67 65 65 72" stroke="#81c784" strokeWidth="1.8" strokeLinecap="round" fill="none" />
          
          {/* Cosmic Aura & Glowing Particles */}
          <circle cx="50" cy="26" r="35" stroke="#80cbc4" strokeWidth="1" strokeDasharray="3,3" opacity="0.7" fill="none" />
          <circle cx="32" cy="68" r="2.2" fill="#ffe082" />
          <circle cx="68" cy="68" r="2.2" fill="#ff80ab" />
          <circle cx="50" cy="12" r="3" fill="#ffffff" />
          <circle cx="50" cy="12" r="6" fill="#80deea" opacity="0.4" />
        </svg>
      );
  }
}

// ---------------------------------------------------------------------------
// Botanical Blossoming and Fruiting Profiles for all 20 Tree Species
// ---------------------------------------------------------------------------
interface FruitBlossomNode {
  x: number;
  y: number;
  scale?: number;
  blossomOffset?: { x: number; y: number };
}

interface BotanicalFruitingProfile {
  fruitType:
    | 'apple'
    | 'berry'
    | 'cherry'
    | 'pinecone'
    | 'acorn'
    | 'plum'
    | 'peach'
    | 'orange'
    | 'celestial'
    | 'mana'
    | 'dewdrop';
  fruitColor1: string;
  fruitColor2: string;
  fruitHighlight?: string;
  fruitRadius: number;

  blossomPetalColor1: string;
  blossomPetalColor2: string;
  blossomCenterColor: string;
  blossomRadius: number;

  nodes: FruitBlossomNode[];
}

const BOTANICAL_FRUITING_PROFILES: Record<string, BotanicalFruitingProfile> = {
  'basic-sapling': {
    fruitType: 'apple',
    fruitColor1: '#ef4444',
    fruitColor2: '#b91c1c',
    fruitHighlight: '#fca5a5',
    fruitRadius: 4.2,
    blossomPetalColor1: '#fce7f3',
    blossomPetalColor2: '#f472b6',
    blossomCenterColor: '#fef08a',
    blossomRadius: 3.8,
    nodes: [
      { x: 30, y: 56, scale: 0.95 },
      { x: 68, y: 48, scale: 1.0 },
      { x: 50, y: 24, scale: 1.05 },
      { x: 33, y: 36, scale: 0.9 },
      { x: 62, y: 28, scale: 0.92 },
    ],
  },
  'evergreen-pine': {
    fruitType: 'pinecone',
    fruitColor1: '#d97706',
    fruitColor2: '#78350f',
    fruitHighlight: '#fde68a',
    fruitRadius: 4.4,
    blossomPetalColor1: '#fda4af',
    blossomPetalColor2: '#e11d48',
    blossomCenterColor: '#fbbf24',
    blossomRadius: 3.2,
    nodes: [
      { x: 32, y: 74, scale: 0.95 },
      { x: 68, y: 74, scale: 0.95 },
      { x: 40, y: 58, scale: 1.0 },
      { x: 60, y: 58, scale: 1.0 },
      { x: 48, y: 40, scale: 0.9 },
      { x: 52, y: 24, scale: 0.85 },
    ],
  },
  'bushy-shrub': {
    fruitType: 'berry',
    fruitColor1: '#3b82f6',
    fruitColor2: '#1e3a8a',
    fruitHighlight: '#93c5fd',
    fruitRadius: 3.5,
    blossomPetalColor1: '#ffffff',
    blossomPetalColor2: '#e0e7ff',
    blossomCenterColor: '#facc15',
    blossomRadius: 3.5,
    nodes: [
      { x: 26, y: 68, scale: 0.9 },
      { x: 36, y: 76, scale: 1.0 },
      { x: 62, y: 75, scale: 1.0 },
      { x: 74, y: 66, scale: 0.9 },
      { x: 44, y: 50, scale: 1.05 },
      { x: 56, y: 46, scale: 1.0 },
      { x: 35, y: 48, scale: 0.92 },
      { x: 65, y: 46, scale: 0.95 },
    ],
  },
  'young-birch': {
    fruitType: 'plum',
    fruitColor1: '#f97316',
    fruitColor2: '#c2410c',
    fruitHighlight: '#ffedd5',
    fruitRadius: 3.6,
    blossomPetalColor1: '#fef08a',
    blossomPetalColor2: '#84cc16',
    blossomCenterColor: '#eab308',
    blossomRadius: 3.4,
    nodes: [
      { x: 36, y: 42, scale: 0.95 },
      { x: 44, y: 46, scale: 1.0 },
      { x: 58, y: 35, scale: 1.05 },
      { x: 66, y: 40, scale: 0.9 },
      { x: 50, y: 22, scale: 0.95 },
      { x: 44, y: 16, scale: 0.88 },
    ],
  },
  'forest-elm': {
    fruitType: 'peach',
    fruitColor1: '#fb923c',
    fruitColor2: '#ea580c',
    fruitHighlight: '#ffedd5',
    fruitRadius: 4.0,
    blossomPetalColor1: '#fed7aa',
    blossomPetalColor2: '#f43f5e',
    blossomCenterColor: '#fde047',
    blossomRadius: 3.6,
    nodes: [
      { x: 28, y: 46, scale: 0.92 },
      { x: 36, y: 34, scale: 1.0 },
      { x: 50, y: 24, scale: 1.05 },
      { x: 64, y: 34, scale: 1.0 },
      { x: 72, y: 46, scale: 0.92 },
      { x: 50, y: 58, scale: 0.95 },
    ],
  },
  'sprawling-oak': {
    fruitType: 'acorn',
    fruitColor1: '#d97706',
    fruitColor2: '#78350f',
    fruitHighlight: '#fef3c7',
    fruitRadius: 4.3,
    blossomPetalColor1: '#fef08a',
    blossomPetalColor2: '#ca8a04',
    blossomCenterColor: '#eab308',
    blossomRadius: 3.5,
    nodes: [
      { x: 24, y: 46, scale: 0.95 },
      { x: 34, y: 42, scale: 1.0 },
      { x: 46, y: 32, scale: 1.05 },
      { x: 56, y: 32, scale: 1.05 },
      { x: 66, y: 42, scale: 1.0 },
      { x: 76, y: 48, scale: 0.92 },
      { x: 48, y: 54, scale: 0.96 },
    ],
  },
  'tall-birch': {
    fruitType: 'plum',
    fruitColor1: '#eab308',
    fruitColor2: '#a16207',
    fruitHighlight: '#fef9c3',
    fruitRadius: 3.8,
    blossomPetalColor1: '#fef08a',
    blossomPetalColor2: '#facc15',
    blossomCenterColor: '#ca8a04',
    blossomRadius: 3.5,
    nodes: [
      { x: 45, y: 36, scale: 1.0 },
      { x: 55, y: 34, scale: 1.0 },
      { x: 44, y: 24, scale: 0.95 },
      { x: 54, y: 20, scale: 0.9 },
      { x: 50, y: 10, scale: 0.85 },
    ],
  },
  'dense-pine-cluster': {
    fruitType: 'pinecone',
    fruitColor1: '#7c3aed',
    fruitColor2: '#4c1d95',
    fruitHighlight: '#ddd6fe',
    fruitRadius: 4.0,
    blossomPetalColor1: '#f472b6',
    blossomPetalColor2: '#be185d',
    blossomCenterColor: '#fde047',
    blossomRadius: 3.2,
    nodes: [
      { x: 26, y: 68, scale: 0.95 },
      { x: 34, y: 52, scale: 0.9 },
      { x: 48, y: 46, scale: 1.05 },
      { x: 54, y: 26, scale: 0.9 },
      { x: 66, y: 68, scale: 0.95 },
      { x: 74, y: 54, scale: 0.9 },
    ],
  },
  'cherry-blossom': {
    fruitType: 'cherry',
    fruitColor1: '#be123c',
    fruitColor2: '#881337',
    fruitHighlight: '#fda4af',
    fruitRadius: 3.8,
    blossomPetalColor1: '#fce7f3',
    blossomPetalColor2: '#ec4899',
    blossomCenterColor: '#fef08a',
    blossomRadius: 4.2,
    nodes: [
      { x: 28, y: 40, scale: 0.95 },
      { x: 38, y: 34, scale: 1.0 },
      { x: 48, y: 26, scale: 1.05 },
      { x: 62, y: 30, scale: 1.0 },
      { x: 72, y: 40, scale: 0.95 },
      { x: 52, y: 48, scale: 0.92 },
      { x: 34, y: 52, scale: 0.9 },
      { x: 66, y: 50, scale: 0.92 },
    ],
  },
  'maple-tree': {
    fruitType: 'cherry',
    fruitColor1: '#dc2626',
    fruitColor2: '#991b1b',
    fruitHighlight: '#fca5a5',
    fruitRadius: 3.8,
    blossomPetalColor1: '#fef08a',
    blossomPetalColor2: '#84cc16',
    blossomCenterColor: '#eab308',
    blossomRadius: 3.5,
    nodes: [
      { x: 34, y: 48, scale: 0.95 },
      { x: 48, y: 34, scale: 1.05 },
      { x: 64, y: 42, scale: 1.0 },
      { x: 42, y: 58, scale: 0.9 },
      { x: 58, y: 58, scale: 0.92 },
      { x: 50, y: 22, scale: 0.95 },
    ],
  },
  'autumn-maple': {
    fruitType: 'orange',
    fruitColor1: '#ea580c',
    fruitColor2: '#9a3412',
    fruitHighlight: '#ffedd5',
    fruitRadius: 4.2,
    blossomPetalColor1: '#fed7aa',
    blossomPetalColor2: '#ea580c',
    blossomCenterColor: '#facc15',
    blossomRadius: 3.8,
    nodes: [
      { x: 28, y: 46, scale: 0.95 },
      { x: 38, y: 36, scale: 1.0 },
      { x: 48, y: 26, scale: 1.05 },
      { x: 62, y: 34, scale: 1.0 },
      { x: 72, y: 44, scale: 0.95 },
      { x: 50, y: 52, scale: 0.92 },
    ],
  },
  'weeping-willow': {
    fruitType: 'dewdrop',
    fruitColor1: '#a7f3d0',
    fruitColor2: '#059669',
    fruitHighlight: '#ffffff',
    fruitRadius: 3.5,
    blossomPetalColor1: '#e0e7ff',
    blossomPetalColor2: '#a5b4fc',
    blossomCenterColor: '#fef08a',
    blossomRadius: 3.2,
    nodes: [
      { x: 22, y: 66, scale: 0.9 },
      { x: 32, y: 74, scale: 1.0 },
      { x: 46, y: 80, scale: 1.05 },
      { x: 54, y: 80, scale: 1.05 },
      { x: 66, y: 74, scale: 1.0 },
      { x: 78, y: 66, scale: 0.9 },
      { x: 50, y: 42, scale: 0.95 },
    ],
  },
  'twisted-bonsai-oak': {
    fruitType: 'apple',
    fruitColor1: '#f43f5e',
    fruitColor2: '#be123c',
    fruitHighlight: '#fecdd3',
    fruitRadius: 3.6,
    blossomPetalColor1: '#fff1f2',
    blossomPetalColor2: '#fb7185',
    blossomCenterColor: '#fef08a',
    blossomRadius: 3.5,
    nodes: [
      { x: 32, y: 54, scale: 0.95 },
      { x: 40, y: 46, scale: 1.0 },
      { x: 58, y: 38, scale: 1.05 },
      { x: 68, y: 42, scale: 0.92 },
      { x: 48, y: 26, scale: 0.9 },
    ],
  },
  'ancient-oak': {
    fruitType: 'acorn',
    fruitColor1: '#f59e0b',
    fruitColor2: '#78350f',
    fruitHighlight: '#fef3c7',
    fruitRadius: 4.8,
    blossomPetalColor1: '#fef08a',
    blossomPetalColor2: '#eab308',
    blossomCenterColor: '#f59e0b',
    blossomRadius: 4.0,
    nodes: [
      { x: 22, y: 42, scale: 0.95 },
      { x: 32, y: 34, scale: 1.0 },
      { x: 46, y: 24, scale: 1.08 },
      { x: 58, y: 24, scale: 1.08 },
      { x: 68, y: 34, scale: 1.0 },
      { x: 78, y: 42, scale: 0.95 },
      { x: 44, y: 48, scale: 0.98 },
      { x: 56, y: 48, scale: 0.98 },
    ],
  },
  'flowering-shrub': {
    fruitType: 'berry',
    fruitColor1: '#7e22ce',
    fruitColor2: '#3b0764',
    fruitHighlight: '#e9d5ff',
    fruitRadius: 3.6,
    blossomPetalColor1: '#f3e8ff',
    blossomPetalColor2: '#c084fc',
    blossomCenterColor: '#fde047',
    blossomRadius: 3.8,
    nodes: [
      { x: 26, y: 64, scale: 0.92 },
      { x: 36, y: 72, scale: 1.0 },
      { x: 48, y: 50, scale: 1.05 },
      { x: 58, y: 56, scale: 1.0 },
      { x: 66, y: 68, scale: 0.95 },
      { x: 74, y: 60, scale: 0.92 },
      { x: 42, y: 40, scale: 0.95 },
    ],
  },
  'golden-canopy-tree': {
    fruitType: 'celestial',
    fruitColor1: '#fbbf24',
    fruitColor2: '#d97706',
    fruitHighlight: '#fffbeb',
    fruitRadius: 4.6,
    blossomPetalColor1: '#fffbeb',
    blossomPetalColor2: '#f59e0b',
    blossomCenterColor: '#ffffff',
    blossomRadius: 4.2,
    nodes: [
      { x: 30, y: 42, scale: 0.95 },
      { x: 40, y: 30, scale: 1.0 },
      { x: 50, y: 20, scale: 1.08 },
      { x: 60, y: 30, scale: 1.0 },
      { x: 70, y: 42, scale: 0.95 },
      { x: 50, y: 48, scale: 0.92 },
    ],
  },
  'magic-glowing-pine': {
    fruitType: 'mana',
    fruitColor1: '#22d3ee',
    fruitColor2: '#0891b2',
    fruitHighlight: '#ecfeff',
    fruitRadius: 4.2,
    blossomPetalColor1: '#cffafe',
    blossomPetalColor2: '#06b6d4',
    blossomCenterColor: '#ffffff',
    blossomRadius: 3.6,
    nodes: [
      { x: 34, y: 70, scale: 0.95 },
      { x: 66, y: 70, scale: 0.95 },
      { x: 40, y: 54, scale: 1.0 },
      { x: 60, y: 54, scale: 1.0 },
      { x: 46, y: 34, scale: 0.95 },
      { x: 54, y: 34, scale: 0.95 },
      { x: 50, y: 18, scale: 0.9 },
    ],
  },
  'ancient-golden-pine': {
    fruitType: 'celestial',
    fruitColor1: '#facc15',
    fruitColor2: '#ca8a04',
    fruitHighlight: '#fef9c3',
    fruitRadius: 4.5,
    blossomPetalColor1: '#fef9c3',
    blossomPetalColor2: '#eab308',
    blossomCenterColor: '#ffffff',
    blossomRadius: 3.8,
    nodes: [
      { x: 32, y: 68, scale: 0.95 },
      { x: 68, y: 68, scale: 0.95 },
      { x: 40, y: 50, scale: 1.0 },
      { x: 60, y: 50, scale: 1.0 },
      { x: 45, y: 32, scale: 0.95 },
      { x: 55, y: 32, scale: 0.95 },
      { x: 50, y: 16, scale: 0.9 },
    ],
  },
  'magic-forest-cluster': {
    fruitType: 'mana',
    fruitColor1: '#ec4899',
    fruitColor2: '#831843',
    fruitHighlight: '#fdf2f8',
    fruitRadius: 4.0,
    blossomPetalColor1: '#fbcfe8',
    blossomPetalColor2: '#a855f7',
    blossomCenterColor: '#67e8f9',
    blossomRadius: 3.8,
    nodes: [
      { x: 24, y: 40, scale: 0.92 },
      { x: 32, y: 34, scale: 1.0 },
      { x: 46, y: 24, scale: 1.05 },
      { x: 54, y: 24, scale: 1.05 },
      { x: 68, y: 36, scale: 1.0 },
      { x: 76, y: 42, scale: 0.92 },
      { x: 50, y: 40, scale: 0.95 },
    ],
  },
  'grand-mythic-world-tree': {
    fruitType: 'celestial',
    fruitColor1: '#fde047',
    fruitColor2: '#ea580c',
    fruitHighlight: '#ffffff',
    fruitRadius: 5.2,
    blossomPetalColor1: '#fef08a',
    blossomPetalColor2: '#38bdf8',
    blossomCenterColor: '#f43f5e',
    blossomRadius: 4.5,
    nodes: [
      { x: 20, y: 38, scale: 0.95 },
      { x: 32, y: 30, scale: 1.0 },
      { x: 44, y: 20, scale: 1.08 },
      { x: 56, y: 20, scale: 1.08 },
      { x: 68, y: 30, scale: 1.0 },
      { x: 80, y: 38, scale: 0.95 },
      { x: 34, y: 54, scale: 0.92 },
      { x: 66, y: 54, scale: 0.92 },
      { x: 50, y: 36, scale: 1.05 },
    ],
  },
};

function renderTreeBlossomsAndFruits(
  speciesId: string,
  progress: number,
  isWilting: boolean
): React.ReactNode {
  const profile =
    BOTANICAL_FRUITING_PROFILES[speciesId] ||
    BOTANICAL_FRUITING_PROFILES['basic-sapling'];

  // Progress p normalized strictly between 0 and 1
  const p = Math.max(0, Math.min(1, progress));

  // If p is less than 0.58, tree is still expanding leaves and trunk, no blossoms/fruits yet
  if (p < 0.58) return null;

  // Phase 4: Continuous Blossoming (starts at 0.58, opens to full bloom by 0.78)
  const blossomProgress = smoothstep(0.58, 0.78, p);
  const blossomYield = smoothstep(0.80, 0.98, p);
  const blossomScale = blossomProgress * (1 - 0.32 * blossomYield);
  const blossomOpacity = smoothstep(0.58, 0.66, p);

  // Phase 5: Continuous Fruiting Swelling (monotonically expands from 0.72 to full ripe harvest at 1.00)
  const fruitProgress = smoothstep(0.72, 1.00, p);
  const fruitScale = Math.pow(fruitProgress, 0.92);
  const fruitOpacity = smoothstep(0.72, 0.80, p);

  const gradId = `fruit-grad-${speciesId}`;

  return (
    <svg
      viewBox="0 0 100 110"
      className="w-full h-full absolute inset-0 pointer-events-none"
      style={{ overflow: 'visible' }}
    >
      <defs>
        <radialGradient id={gradId} cx="35%" cy="30%" r="70%">
          <stop
            offset="0%"
            stopColor={profile.fruitHighlight || '#ffffff'}
            stopOpacity={0.65}
          />
          <stop offset="25%" stopColor={profile.fruitColor1} />
          <stop offset="85%" stopColor={profile.fruitColor2} />
          <stop offset="100%" stopColor={profile.fruitColor2} />
        </radialGradient>
      </defs>

      {/* Blossoms Layer */}
      {blossomScale > 0 &&
        profile.nodes.map((node, i) => {
          const bx = node.x + (node.blossomOffset?.x || (i % 2 === 0 ? 1 : -1));
          const by = node.y + (node.blossomOffset?.y || (i % 2 === 0 ? -1 : 1));
          const r = profile.blossomRadius;

          return (
            <g
              key={`blossom-${i}`}
              transform={`translate(${bx}, ${by}) scale(${blossomScale})`}
              opacity={blossomOpacity}
            >
              {[0, 72, 144, 216, 288].map((angle, petalIdx) => (
                <ellipse
                  key={petalIdx}
                  cx="0"
                  cy={-r * 0.75}
                  rx={r * 0.52}
                  ry={r * 0.75}
                  fill={
                    petalIdx % 2 === 0
                      ? profile.blossomPetalColor1
                      : profile.blossomPetalColor2
                  }
                  stroke={profile.blossomPetalColor2}
                  strokeWidth="0.25"
                  transform={`rotate(${angle})`}
                  opacity={0.92}
                />
              ))}
              <circle
                cx="0"
                cy="0"
                r={r * 0.38}
                fill={profile.blossomCenterColor}
              />
              <circle
                cx="0"
                cy="0"
                r={r * 0.16}
                fill="#ffffff"
                opacity={0.85}
              />
            </g>
          );
        })}

      {/* Fruits Layer */}
      {fruitScale > 0 &&
        profile.nodes.map((node, i) => {
          const r = profile.fruitRadius * (node.scale || 1);
          const fx = node.x;
          const fy = node.y;

          return (
            <g
              key={`fruit-${i}`}
              transform={`translate(${fx}, ${fy}) scale(${fruitScale})`}
              opacity={fruitOpacity}
            >
              {renderFruitGraphic(profile.fruitType, r, gradId, profile)}
            </g>
          );
        })}
    </svg>
  );
}

function renderFruitGraphic(
  fruitType: BotanicalFruitingProfile['fruitType'],
  r: number,
  gradId: string,
  profile: BotanicalFruitingProfile
): React.ReactNode {
  switch (fruitType) {
    case 'apple':
      return (
        <g>
          {/* Stem & leaf */}
          <path
            d="M0 -3 Q 2 -6, 2.5 -8"
            stroke="#451a03"
            strokeWidth="0.9"
            fill="none"
            strokeLinecap="round"
          />
          <path
            d="M1.5 -6 Q 4 -8, 5 -6 Q 3.5 -5, 1.5 -6"
            fill="#4ade80"
          />
          {/* Plump Apple Body */}
          <path
            d={`M 0 -${r * 0.6} C -${r * 0.6} -${r * 1.15}, -${r * 1.15} -${r * 0.4}, -${r} ${r * 0.35} C -${r * 0.8} ${r * 1.05}, -${r * 0.3} ${r * 1.12}, 0 ${r * 0.95} C ${r * 0.3} ${r * 1.12}, ${r * 0.8} ${r * 1.05}, ${r} ${r * 0.35} C ${r * 1.15} -${r * 0.4}, ${r * 0.6} -${r * 1.15}, 0 -${r * 0.6} Z`}
            fill={`url(#${gradId})`}
          />
          {/* Specular shine */}
          <ellipse
            cx={-r * 0.35}
            cy={-r * 0.25}
            rx={r * 0.28}
            ry={r * 0.42}
            fill="#ffffff"
            opacity="0.65"
            transform="rotate(-25)"
          />
          <circle
            cx={r * 0.25}
            cy={r * 0.4}
            r={r * 0.15}
            fill="#ffffff"
            opacity="0.35"
          />
        </g>
      );

    case 'cherry':
      return (
        <g>
          {/* Twin stems joining at branch */}
          <path
            d={`M0 -${r * 2.2} Q -${r * 0.8} -${r * 1.2}, -${r * 0.6} 0`}
            stroke="#15803d"
            strokeWidth="0.8"
            fill="none"
          />
          <path
            d={`M0 -${r * 2.2} Q ${r * 0.8} -${r * 1.2}, ${r * 0.6} ${r * 0.3}`}
            stroke="#15803d"
            strokeWidth="0.8"
            fill="none"
          />
          <circle cx="0" cy={-r * 2.2} r="0.8" fill="#15803d" />
          {/* Left cherry */}
          <circle cx={-r * 0.6} cy="0" r={r * 0.85} fill={`url(#${gradId})`} />
          <circle
            cx={-r * 0.8}
            cy={-r * 0.25}
            r={r * 0.25}
            fill="#ffffff"
            opacity="0.75"
          />
          {/* Right cherry */}
          <circle
            cx={r * 0.6}
            cy={r * 0.3}
            r={r * 0.85}
            fill={`url(#${gradId})`}
          />
          <circle
            cx={r * 0.4}
            cy={r * 0.05}
            r={r * 0.25}
            fill="#ffffff"
            opacity="0.75"
          />
        </g>
      );

    case 'acorn':
      return (
        <g>
          {/* Stalk */}
          <path
            d={`M0 -${r * 0.8} L0 -${r * 1.3}`}
            stroke="#3d2008"
            strokeWidth="0.9"
            strokeLinecap="round"
          />
          {/* Nut body */}
          <path
            d={`M -${r * 0.85} -${r * 0.2} C -${r * 0.95} ${r * 0.6}, -${r * 0.4} ${r * 1.3}, 0 ${r * 1.4} C ${r * 0.4} ${r * 1.3}, ${r * 0.95} ${r * 0.6}, ${r * 0.85} -${r * 0.2} Z`}
            fill={`url(#${gradId})`}
          />
          {/* Cupule Cap */}
          <ellipse
            cx="0"
            cy={-r * 0.2}
            rx={r * 0.95}
            ry={r * 0.42}
            fill="#5c2c06"
          />
          <path
            d={`M -${r * 0.6} -${r * 0.25} Q 0 -${r * 0.45}, ${r * 0.6} -${r * 0.25}`}
            stroke="#92400e"
            strokeWidth="0.6"
            fill="none"
          />
          {/* Gloss */}
          <ellipse
            cx={-r * 0.3}
            cy={r * 0.35}
            rx={r * 0.2}
            ry={r * 0.4}
            fill={profile.fruitHighlight || '#ffffff'}
            opacity="0.6"
            transform="rotate(-15)"
          />
        </g>
      );

    case 'pinecone':
      return (
        <g>
          <ellipse
            cx="0"
            cy="0"
            rx={r * 0.75}
            ry={r * 1.15}
            fill={`url(#${gradId})`}
          />
          <path
            d={`M -${r * 0.5} -${r * 0.4} Q 0 -${r * 0.1}, ${r * 0.5} -${r * 0.4}`}
            stroke="#451a03"
            strokeWidth="0.8"
            fill="none"
          />
          <path
            d={`M -${r * 0.6} 0 Q 0 ${r * 0.3}, ${r * 0.6} 0`}
            stroke="#451a03"
            strokeWidth="0.8"
            fill="none"
          />
          <path
            d={`M -${r * 0.4} ${r * 0.4} Q 0 ${r * 0.65}, ${r * 0.4} ${r * 0.4}`}
            stroke="#451a03"
            strokeWidth="0.8"
            fill="none"
          />
          <circle
            cx={-r * 0.22}
            cy={-r * 0.28}
            r={r * 0.22}
            fill="#ffffff"
            opacity="0.6"
          />
        </g>
      );

    case 'berry':
      return (
        <g>
          <path
            d={`M0 -${r} Q 1 -${r * 1.3}, 1.8 -${r * 1.5}`}
            stroke="#14532d"
            strokeWidth="0.7"
            fill="none"
          />
          <circle cx="0" cy="0" r={r} fill={`url(#${gradId})`} />
          <circle
            cx="0"
            cy="0"
            r={r * 0.35}
            fill="none"
            stroke="#93c5fd"
            strokeWidth="0.5"
            opacity="0.7"
          />
          <circle
            cx={-r * 0.32}
            cy={-r * 0.32}
            r={r * 0.28}
            fill="#ffffff"
            opacity="0.75"
          />
        </g>
      );

    case 'orange':
      return (
        <g>
          <path
            d={`M0 -${r * 0.8} Q 1 -${r * 1.2}, 1.5 -${r * 1.4}`}
            stroke="#3e2723"
            strokeWidth="0.8"
            fill="none"
          />
          <ellipse
            cx="0"
            cy="0"
            rx={r * 1.05}
            ry={r * 0.95}
            fill={`url(#${gradId})`}
          />
          <path
            d={`M -${r * 0.35} -${r * 0.65} L 0 -${r * 0.82} L ${r * 0.35} -${r * 0.65} L 0 -${r * 0.5} Z`}
            fill="#3e2723"
          />
          <ellipse
            cx={-r * 0.3}
            cy={-r * 0.2}
            rx={r * 0.28}
            ry={r * 0.38}
            fill="#ffffff"
            opacity="0.55"
            transform="rotate(-20)"
          />
        </g>
      );

    case 'peach':
    case 'plum':
      return (
        <g>
          <path
            d={`M0 -${r * 0.9} Q 1 -${r * 1.3}, 1.8 -${r * 1.5}`}
            stroke="#451a03"
            strokeWidth="0.7"
            fill="none"
          />
          <circle cx="0" cy="0" r={r} fill={`url(#${gradId})`} />
          <path
            d={`M 0 -${r * 0.7} Q -${r * 0.12} 0, 0 ${r * 0.7}`}
            stroke="#78350f"
            strokeWidth="0.5"
            opacity="0.45"
            fill="none"
          />
          <circle
            cx={-r * 0.3}
            cy={-r * 0.25}
            r={r * 0.28}
            fill="#ffffff"
            opacity="0.65"
          />
        </g>
      );

    case 'dewdrop':
      return (
        <g>
          <path
            d={`M 0 -${r * 1.15} C -${r * 0.85} -${r * 0.25}, -${r * 0.95} ${r * 0.45}, 0 ${r * 1.05} C ${r * 0.95} ${r * 0.45}, ${r * 0.85} -${r * 0.25}, 0 -${r * 1.15} Z`}
            fill={`url(#${gradId})`}
          />
          <circle
            cx={-r * 0.25}
            cy="0"
            r={r * 0.26}
            fill="#ffffff"
            opacity="0.8"
          />
        </g>
      );

    case 'mana':
      return (
        <g>
          <circle
            cx="0"
            cy="0"
            r={r * 1.4}
            fill="#22d3ee"
            opacity="0.3"
            filter="blur(0.8px)"
          />
          <circle cx="0" cy="0" r={r} fill={`url(#${gradId})`} />
          <polygon
            points={`0,-${r * 0.85} ${r * 0.65},0 0,${r * 0.85} -${r * 0.65},0`}
            fill="#ffffff"
            opacity="0.4"
          />
          <circle
            cx={-r * 0.28}
            cy={-r * 0.28}
            r={r * 0.28}
            fill="#ffffff"
            opacity="0.9"
          />
        </g>
      );

    case 'celestial':
    default:
      return (
        <g>
          <circle
            cx="0"
            cy="0"
            r={r * 1.5}
            fill="#fef08a"
            opacity="0.35"
            filter="blur(1px)"
          />
          <circle cx="0" cy="0" r={r} fill={`url(#${gradId})`} />
          {/* Star glint */}
          <path
            d={`M 0 -${r * 1.25} L 0 ${r * 1.25} M -${r * 1.25} 0 L ${r * 1.25} 0`}
            stroke="#ffffff"
            strokeWidth="0.8"
            opacity="0.8"
          />
          <circle
            cx={-r * 0.28}
            cy={-r * 0.28}
            r={r * 0.3}
            fill="#ffffff"
            opacity="0.9"
          />
        </g>
      );
  }
}
