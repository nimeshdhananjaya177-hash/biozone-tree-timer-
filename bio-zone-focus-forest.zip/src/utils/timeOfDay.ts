import { TimeOfDay } from '../types';

export interface CelestialDetails {
  timeOfDay: TimeOfDay;
  label: string;
  phaseLabel: string;
  description: string;
  skyBg: string;
  accentColor: string;
  islandGlow: string;
  celestialType: 'sun' | 'moon';
  celestialColor: string;
  celestialGlow: string;
  starCount: number;
  starOpacity: number;
  sunbeam: boolean;
  timeFormatted: string;
}

/**
 * Calculates current time of day based strictly and automatically on the device's clock.
 * No manual user override is permitted.
 */
export function getDeviceTimeOfDay(): TimeOfDay {
  const now = new Date();
  const hours = now.getHours();
  const minutes = now.getMinutes();
  const totalMins = hours * 60 + minutes;

  // Sunrise: 05:00 to 07:59 (300 to 479 mins)
  if (totalMins >= 300 && totalMins < 480) {
    return 'sunrise';
  }
  // Daytime Sun: 08:00 to 16:59 (480 to 1019 mins)
  else if (totalMins >= 480 && totalMins < 1020) {
    return 'day';
  }
  // Sunset: 17:00 to 19:29 (1020 to 1169 mins)
  else if (totalMins >= 1020 && totalMins < 1170) {
    return 'sunset';
  }
  // Moonrise: 19:30 to 21:59 (1170 to 1319 mins)
  else if (totalMins >= 1170 && totalMins < 1320) {
    return 'moonrise';
  }
  // Deep Starlight Night: 22:00 to 04:59
  else {
    return 'night';
  }
}

export function getTimeThemeDetails(time: TimeOfDay): CelestialDetails {
  const now = new Date();
  const timeFormatted = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  switch (time) {
    case 'sunrise':
      return {
        timeOfDay: 'sunrise',
        label: 'Sunrise Dawn',
        phaseLabel: 'Sunrise',
        description: 'Golden morning rays rise over the misty forest canopy',
        skyBg: 'linear-gradient(160deg, #fcead9 0%, #fad0c4 35%, #e0f2fe 75%, #d1f4e0 100%)',
        accentColor: '#9a3412',
        islandGlow: 'rgba(254, 215, 170, 0.55)',
        celestialType: 'sun',
        celestialColor: '#f59e0b',
        celestialGlow: 'rgba(251, 191, 36, 0.65)',
        starCount: 6,
        starOpacity: 0.15,
        sunbeam: true,
        timeFormatted,
      };

    case 'day':
      return {
        timeOfDay: 'day',
        label: 'Sunlit Day',
        phaseLabel: 'Sunlight',
        description: 'Clear daylight illuminating vibrant forest greenery',
        skyBg: 'linear-gradient(165deg, #e0f2fe 0%, #bae6fd 45%, #dcfce7 80%, #bbf7d0 100%)',
        accentColor: '#166534',
        islandGlow: 'rgba(187, 247, 208, 0.45)',
        celestialType: 'sun',
        celestialColor: '#fbbf24',
        celestialGlow: 'rgba(245, 158, 11, 0.5)',
        starCount: 0,
        starOpacity: 0,
        sunbeam: true,
        timeFormatted,
      };

    case 'sunset':
      return {
        timeOfDay: 'sunset',
        label: 'Golden Sunset',
        phaseLabel: 'Sunset',
        description: 'Warm peach and crimson dusk bathing the island',
        skyBg: 'linear-gradient(160deg, #fed7aa 0%, #f472b6 40%, #c084fc 70%, #6366f1 100%)',
        accentColor: '#831843',
        islandGlow: 'rgba(244, 114, 182, 0.5)',
        celestialType: 'sun',
        celestialColor: '#f97316',
        celestialGlow: 'rgba(239, 68, 68, 0.6)',
        starCount: 15,
        starOpacity: 0.35,
        sunbeam: false,
        timeFormatted,
      };

    case 'moonrise':
      return {
        timeOfDay: 'moonrise',
        label: 'Luminous Moonrise',
        phaseLabel: 'Moonrise',
        description: 'Silver-blue moon ascends as twilight deepens',
        skyBg: 'linear-gradient(165deg, #0f172a 0%, #1e293b 35%, #064e3b 75%, #022c22 100%)',
        accentColor: '#38bdf8',
        islandGlow: 'rgba(56, 189, 248, 0.35)',
        celestialType: 'moon',
        celestialColor: '#e0f2fe',
        celestialGlow: 'rgba(186, 230, 253, 0.7)',
        starCount: 35,
        starOpacity: 0.8,
        sunbeam: false,
        timeFormatted,
      };

    case 'night':
      return {
        timeOfDay: 'night',
        label: 'Starlit Night',
        phaseLabel: 'Moonlit Night',
        description: 'Peaceful celestial night with glittering stars and moon',
        skyBg: 'linear-gradient(165deg, #030712 0%, #0b1329 40%, #064e3b 80%, #022c22 100%)',
        accentColor: '#4ade80',
        islandGlow: 'rgba(74, 222, 128, 0.25)',
        celestialType: 'moon',
        celestialColor: '#f8fafc',
        celestialGlow: 'rgba(224, 242, 254, 0.8)',
        starCount: 50,
        starOpacity: 1.0,
        sunbeam: false,
        timeFormatted,
      };
  }
}
