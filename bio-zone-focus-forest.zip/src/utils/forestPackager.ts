import JSZip from 'jszip';
import { AppState } from '../types';
import { TREE_SPECIES_MAP } from '../data/trees';
import { DECORATIONS_MAP } from '../data/decorations';
import { getProportionalAssetInfo } from './proportionalScaling';

/**
 * Creates a standalone, self-contained single-file HTML offline viewer
 * that can be opened in any web browser without internet or a server.
 */
function generateOfflineHtmlViewer(state: AppState): string {
  const treeCount = state.plantedObjects.filter((o) => o.kind === 'tree').length;
  const decorCount = state.plantedObjects.filter((o) => o.kind === 'decoration').length;
  const totalFocusMinutes = state.sessions.reduce((acc, s) => acc + s.durationMinutes, 0);

  const objectsJson = JSON.stringify(
    state.plantedObjects.map((obj) => {
      const info = getProportionalAssetInfo(obj.kind, obj.itemId);
      return {
        ...obj,
        name: info.name,
        category: info.category,
        pixelHeight: info.pixelHeight,
        realWorldEstimate: info.realWorldEstimate,
      };
    })
  );

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Bio Zone Focus Forest — Offline 3D Sanctuary</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: linear-gradient(180deg, #dcfce7 0%, #bbf7d0 50%, #86efac 100%);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      overflow-x: hidden;
      user-select: none;
      color: #064e3b;
    }
    header {
      width: 100%;
      max-width: 900px;
      padding: 16px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(255, 255, 255, 0.7);
      backdrop-filter: blur(8px);
      border-bottom: 1px solid rgba(16, 185, 129, 0.2);
    }
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 10px;
      border-radius: 9999px;
      background: #ecfdf5;
      border: 1px solid #10b981;
      font-size: 12px;
      font-weight: 600;
      color: #065f46;
    }
    .viewport {
      width: 100%;
      height: 65vh;
      min-height: 400px;
      display: flex;
      align-items: center;
      justify-content: center;
      perspective: 1000px;
      cursor: grab;
    }
    .viewport:active { cursor: grabbing; }
    .camera {
      transform-style: preserve-3d;
      transform: scale(1.05) rotateX(48deg);
      transition: transform 0.1s ease-out;
    }
    .island {
      width: ${state.islandRadius * 2}px;
      height: ${state.islandRadius * 2}px;
      transform-style: preserve-3d;
      border-radius: 50%;
      position: relative;
      background: radial-gradient(circle at 40% 35%, #81c784 0%, #4caf50 45%, #2e7d32 85%, #1b5e20 100%);
      box-shadow: inset 0 6px 14px rgba(255, 255, 255, 0.4), inset 0 -8px 20px rgba(10, 40, 15, 0.5), 0 25px 40px rgba(6, 78, 59, 0.3);
      will-change: transform;
    }
    .island-strata {
      position: absolute;
      inset: -5px;
      border-radius: 50%;
      transform: translateZ(-24px);
      background: radial-gradient(ellipse at 45% 45%, #5d4037 0%, #3e2723 60%, #271406 100%);
      box-shadow: 0 35px 50px rgba(20, 10, 5, 0.5);
      pointer-events: none;
    }
    .object-anchor {
      position: absolute;
      transform-origin: bottom center;
      transform-style: preserve-3d;
      backface-visibility: hidden;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-end;
    }
    .object-card {
      background: rgba(255, 255, 255, 0.92);
      border: 1px solid #10b981;
      padding: 3px 6px;
      border-radius: 6px;
      font-size: 10px;
      font-weight: 700;
      color: #064e3b;
      white-space: nowrap;
      box-shadow: 0 4px 8px rgba(0,0,0,0.15);
      margin-bottom: 2px;
      opacity: 0;
      transition: opacity 0.2s;
    }
    .object-anchor:hover .object-card { opacity: 1; }
    .controls {
      display: flex;
      gap: 10px;
      margin-top: 10px;
      z-index: 20;
    }
    .btn {
      padding: 8px 16px;
      border-radius: 9999px;
      background: #047857;
      color: white;
      border: none;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    .btn:hover { background: #065f46; }
    .stats-panel {
      margin: 15px auto;
      max-width: 800px;
      width: 90%;
      background: white;
      padding: 16px 20px;
      border-radius: 16px;
      border: 1px solid rgba(16, 185, 129, 0.2);
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
      gap: 12px;
      text-align: center;
      box-shadow: 0 4px 12px rgba(6, 78, 59, 0.05);
    }
    .stat-val { font-size: 20px; font-weight: 800; color: #065f46; }
    .stat-lbl { font-size: 11px; font-weight: 600; color: #059669; text-transform: uppercase; margin-top: 2px; }
  </style>
</head>
<body>
  <header>
    <div>
      <h1 style="font-size: 18px; font-weight: 800;">Bio Zone Focus Forest</h1>
      <p style="font-size: 12px; color: #059669;">Standalone Offline 3D Sanctuary</p>
    </div>
    <div class="badge">
      <span>●</span> 100% Offline Device Mode
    </div>
  </header>

  <div class="viewport" id="viewport">
    <div class="camera">
      <div class="island" id="island">
        <div class="island-strata"></div>
      </div>
    </div>
  </div>

  <div class="controls">
    <button class="btn" id="btn-spin">Toggle Auto-Spin</button>
    <button class="btn" id="btn-reset">Reset View</button>
  </div>

  <div class="stats-panel">
    <div>
      <div class="stat-val">${totalFocusMinutes} min</div>
      <div class="stat-lbl">Focus Time</div>
    </div>
    <div>
      <div class="stat-val">${treeCount}</div>
      <div class="stat-lbl">Trees Grown</div>
    </div>
    <div>
      <div class="stat-val">${decorCount}</div>
      <div class="stat-lbl">Decorations</div>
    </div>
    <div>
      <div class="stat-val">${state.level}</div>
      <div class="stat-lbl">Study Level</div>
    </div>
    <div>
      <div class="stat-val">${state.coins}</div>
      <div class="stat-lbl">Harvest Coins</div>
    </div>
  </div>

  <script>
    const objects = ${objectsJson};
    const island = document.getElementById('island');
    const viewport = document.getElementById('viewport');
    let rotY = 35;
    let autoSpin = true;
    let isDragging = false;
    let startX = 0;

    // Render placed objects with proportional scaling and billboarding
    const PITCH = 48;
    const elements = [];

    objects.forEach(obj => {
      const anchor = document.createElement('div');
      anchor.className = 'object-anchor';
      anchor.style.left = 'calc(50% + ' + obj.x + '%)';
      anchor.style.top = 'calc(50% + ' + obj.y + '%)';
      anchor.style.width = obj.pixelHeight + 'px';
      anchor.style.height = obj.pixelHeight + 'px';

      const isTree = obj.kind === 'tree';
      const color = isTree ? '#15803d' : '#d97706';

      anchor.innerHTML = \`
        <div class="object-card">\${obj.name} (\${obj.realWorldEstimate})</div>
        <svg viewBox="0 0 100 100" width="100%" height="100%" style="overflow:visible; filter: drop-shadow(0 4px 6px rgba(0,0,0,0.25));">
          \${isTree ? \`
            <path d="M 45 95 Q 46 65 42 45 Q 50 48 55 45 Q 53 65 55 95 Z" fill="#78350f" />
            <circle cx="50" cy="40" r="32" fill="#22c55e" />
            <circle cx="35" cy="45" r="22" fill="#16a34a" />
            <circle cx="65" cy="45" r="22" fill="#15803d" />
            <!-- Blossoms & Fruits -->
            <circle cx="42" cy="30" r="4.5" fill="#fb7185" />
            <circle cx="58" cy="35" r="4.5" fill="#fb7185" />
            <circle cx="48" cy="48" r="5" fill="#ef4444" />
            <circle cx="36" cy="52" r="4" fill="#ef4444" />
          \` : \`
            <circle cx="50" cy="65" r="28" fill="#f59e0b" />
            <path d="M 30 65 L 50 25 L 70 65 Z" fill="#b45309" />
          \`}
        </svg>
      \`;

      island.appendChild(anchor);
      elements.push({ anchor, obj });
    });

    function updateTransforms() {
      island.style.transform = 'rotateZ(' + rotY + 'deg)';
      const rotRad = (rotY * Math.PI) / 180;

      elements.forEach(({ anchor, obj }) => {
        const rotatedY = obj.x * Math.sin(rotRad) + obj.y * Math.cos(rotRad);
        anchor.style.transform = 'translate3d(-50%, -90%, 1px) rotateZ(' + (-rotY) + 'deg) rotateX(' + (-PITCH) + 'deg)';
        anchor.style.zIndex = Math.floor(200 + rotatedY);
      });
    }

    updateTransforms();

    // Drag rotation
    viewport.addEventListener('pointerdown', (e) => {
      isDragging = true;
      startX = e.clientX;
      viewport.setPointerCapture(e.pointerId);
    });

    viewport.addEventListener('pointermove', (e) => {
      if (!isDragging) return;
      const deltaX = e.clientX - startX;
      startX = e.clientX;
      rotY = (rotY + deltaX * 0.6) % 360;
      if (rotY < 0) rotY += 360;
      updateTransforms();
    });

    viewport.addEventListener('pointerup', () => { isDragging = false; });
    viewport.addEventListener('pointercancel', () => { isDragging = false; });

    // Animation Loop
    function loop() {
      if (autoSpin && !isDragging) {
        rotY = (rotY + 0.25) % 360;
        updateTransforms();
      }
      requestAnimationFrame(loop);
    }
    requestAnimationFrame(loop);

    document.getElementById('btn-spin').addEventListener('click', () => {
      autoSpin = !autoSpin;
    });

    document.getElementById('btn-reset').addEventListener('click', () => {
      rotY = 35;
      updateTransforms();
    });
  </script>
</body>
</html>`;
}

/**
 * Creates a formatted Markdown study journal
 */
function generateStudyJournalMarkdown(state: AppState): string {
  const treeCount = state.plantedObjects.filter((o) => o.kind === 'tree').length;
  const decorCount = state.plantedObjects.filter((o) => o.kind === 'decoration').length;
  const totalFocusMinutes = state.sessions.reduce((acc, s) => acc + s.durationMinutes, 0);

  const lines = [
    `# Bio Zone Focus Forest — Personal Study Journal`,
    `Generated on: ${new Date().toLocaleString()}`,
    ``,
    `## Summary Statistics`,
    `- **Study Level**: Level ${state.level} (${state.xp} XP)`,
    `- **Harvest Coins**: ${state.coins} Coins`,
    `- **Total Focus Time**: ${totalFocusMinutes} minutes (${(totalFocusMinutes / 60).toFixed(1)} hours)`,
    `- **Trees in Sanctuary**: ${treeCount} mature trees`,
    `- **Sanctuary Elements**: ${decorCount} wildlife & buildings placed`,
    `- **Island Radius**: ${state.islandRadius}px`,
    ``,
    `## Planted Trees & Elements (Proportionally Scaled)`,
  ];

  state.plantedObjects.forEach((obj, idx) => {
    const info = getProportionalAssetInfo(obj.kind, obj.itemId);
    lines.push(`${idx + 1}. **${info.name}** (${info.category}) — ${info.realWorldEstimate} [Coordinates: (${obj.x}%, ${obj.y}%)]`);
  });

  lines.push(``);
  lines.push(`## Recent Study Sessions Log`);
  if (state.sessions.length === 0) {
    lines.push(`*No completed sessions recorded yet.*`);
  } else {
    lines.push(`| Date & Time | Duration | Tree Grown | Coins Earned | XP Earned |`);
    lines.push(`| :--- | :--- | :--- | :--- | :--- |`);
    state.sessions.slice(-25).reverse().forEach((s) => {
      const tree = TREE_SPECIES_MAP[s.treeId]?.name || s.treeId;
      const formattedDate = s.dateStr || (s.timestamp ? new Date(s.timestamp).toLocaleString() : 'Recent');
      lines.push(`| ${formattedDate} | ${s.durationMinutes} min | ${tree} | +${s.coinsEarned} | +${s.xpEarned} |`);
    });
  }

  lines.push(``);
  lines.push(`---`);
  lines.push(`*Bio Zone Focus Forest — Dedicated to Sri Lankan A/L Student Mindfulness & Productivity*`);

  return lines.join('\n');
}

/**
 * Generates a standalone, self-contained interactive offline growth timer HTML application.
 * Features the continuous, progressive botanical growth animation from planted seed to full fruiting harvest.
 */
function generateOfflineGrowthTimerHtml(state: AppState): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Bio Zone Focus Forest — Standalone Offline Growth Timer</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: linear-gradient(180deg, #ecfdf5 0%, #d1fae5 50%, #a7f3d0 100%);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: space-between;
      padding: 16px;
      color: #064e3b;
      user-select: none;
    }
    header {
      width: 100%;
      max-width: 500px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 16px;
      background: rgba(255, 255, 255, 0.85);
      backdrop-filter: blur(8px);
      border-radius: 9999px;
      border: 1px solid rgba(16, 185, 129, 0.3);
      box-shadow: 0 4px 12px rgba(6, 78, 59, 0.08);
    }
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      font-weight: 700;
      color: #065f46;
    }
    .main-container {
      width: 100%;
      max-width: 420px;
      display: flex;
      flex-direction: column;
      align-items: center;
      margin: auto 0;
    }
    .stage-pill {
      margin-bottom: 12px;
      padding: 6px 14px;
      border-radius: 9999px;
      background: rgba(255, 255, 255, 0.9);
      border: 1px solid rgba(16, 185, 129, 0.3);
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      color: #065f46;
      box-shadow: 0 2px 6px rgba(6, 78, 59, 0.06);
    }
    .glass-orb {
      position: relative;
      width: 250px;
      height: 250px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: radial-gradient(circle at 35% 30%, rgba(255, 255, 255, 0.95) 0%, rgba(220, 248, 230, 0.6) 40%, rgba(144, 219, 175, 0.3) 75%, rgba(65, 150, 100, 0.4) 100%);
      border: 2px solid rgba(255, 255, 255, 0.85);
      box-shadow: 0 20px 40px -10px rgba(27, 77, 43, 0.25), inset 0 -12px 24px rgba(45, 100, 60, 0.2), inset 0 8px 16px rgba(255, 255, 255, 0.8);
      overflow: hidden;
    }
    .soil-mound {
      position: absolute;
      bottom: 24px;
      width: 180px;
      height: 52px;
      border-radius: 50%;
      background: linear-gradient(180deg, #4e3825 0%, #342416 100%);
      box-shadow: inset 0 2px 4px rgba(0,0,0,0.4);
    }
    .grass-fringe {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 6px;
      background: linear-gradient(90deg, #15803d, #22c55e, #166534);
      border-radius: 50% 50% 0 0;
    }
    .tree-stage {
      position: absolute;
      bottom: 38px;
      width: 160px;
      height: 160px;
      display: flex;
      align-items: flex-end;
      justify-content: center;
    }
    .timer-display {
      font-size: 48px;
      font-weight: 800;
      letter-spacing: -1px;
      color: #064e3b;
      margin-top: 14px;
      text-shadow: 0 1px 2px rgba(255,255,255,0.8);
    }
    .progress-bar-container {
      width: 100%;
      max-width: 280px;
      height: 8px;
      background: rgba(255, 255, 255, 0.7);
      border-radius: 9999px;
      overflow: hidden;
      margin-top: 8px;
      border: 1px solid rgba(16, 185, 129, 0.3);
    }
    .progress-bar-fill {
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, #10b981, #059669);
      border-radius: 9999px;
      transition: width 0.1s linear;
    }
    .controls {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-top: 20px;
    }
    .btn {
      border: none;
      outline: none;
      cursor: pointer;
      font-weight: 700;
      border-radius: 16px;
      transition: all 0.15s ease;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
    }
    .btn:active { transform: scale(0.96); }
    .btn-primary {
      background: #059669;
      color: white;
      padding: 12px 28px;
      font-size: 15px;
      box-shadow: 0 4px 14px rgba(5, 150, 105, 0.35);
    }
    .btn-primary:hover { background: #047857; }
    .btn-secondary {
      background: rgba(255, 255, 255, 0.85);
      border: 1px solid rgba(16, 185, 129, 0.4);
      color: #065f46;
      padding: 10px 18px;
      font-size: 13px;
    }
    .btn-secondary:hover { background: white; }
    .duration-chips {
      display: flex;
      gap: 8px;
      margin-top: 14px;
    }
    .duration-chip {
      padding: 6px 12px;
      border-radius: 12px;
      font-size: 11px;
      font-weight: 700;
      background: rgba(255, 255, 255, 0.7);
      border: 1px solid rgba(16, 185, 129, 0.25);
      color: #065f46;
      cursor: pointer;
    }
    .duration-chip.active {
      background: #059669;
      color: white;
      border-color: #059669;
    }
    .preview-slider-wrap {
      width: 100%;
      margin-top: 16px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
    }
    .preview-slider-wrap label {
      font-size: 11px;
      font-weight: 600;
      color: #065f46;
    }
    .preview-slider-wrap input[type=range] {
      width: 240px;
      accent-color: #059669;
    }
    footer {
      font-size: 11px;
      color: #047857;
      text-align: center;
      padding: 10px;
    }
  </style>
</head>
<body>
  <header>
    <div class="badge">🌱 Bio Zone Offline Focus Timer</div>
    <div class="badge" id="coins-display">🪙 100% Offline</div>
  </header>

  <div class="main-container">
    <div class="stage-pill" id="stage-pill">Planting Seed in Loam… 🌱</div>

    <div class="glass-orb">
      <div class="soil-mound">
        <div class="grass-fringe"></div>
      </div>

      <div class="tree-stage">
        <!-- Botanical Vector Container -->
        <svg id="botanical-svg" width="160" height="160" viewBox="0 0 100 110" style="overflow: visible;">
          <defs>
            <radialGradient id="shadow-grad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#1b3820" stopOpacity="0.45" />
              <stop offset="60%" stopColor="#244d2b" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#244d2b" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="trunk-grad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#78350f" />
              <stop offset="50%" stopColor="#92400e" />
              <stop offset="100%" stopColor="#451a03" />
            </linearGradient>
            <linearGradient id="crown-grad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#4ade80" />
              <stop offset="50%" stopColor="#22c55e" />
              <stop offset="100%" stopColor="#15803d" />
            </linearGradient>
            <radialGradient id="fruit-grad" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.6" />
              <stop offset="30%" stopColor="#f87171" />
              <stop offset="100%" stopColor="#b91c1c" />
            </radialGradient>
          </defs>

          <!-- Contact Shadow -->
          <ellipse id="root-shadow" cx="50" cy="104" rx="28" ry="8" fill="url(#shadow-grad)" />

          <!-- Root Radicles -->
          <path id="sub-roots" d="M42 104 Q 48 103, 50 102 Q 52 103, 58 104" stroke="#332115" stroke-width="1.8" stroke-linecap="round" fill="none" opacity="0.6" />

          <!-- Seed Entity (p in 0..0.25) -->
          <g id="seed-entity" transform="translate(42, 92)">
            <path d="M8 2 C11 5, 12 9, 11 12 C10 14, 5 14, 4 12 C3 9, 5 5, 8 2 Z" fill="#8d5b36" stroke="#451a03" stroke-width="0.8" />
            <circle cx="8" cy="8" r="1.6" fill="#fef08a" opacity="0.75" />
          </g>

          <!-- Continuous Species Tree -->
          <g id="tree-canopy-group" transform-origin="50 102" transform="scale(0, 0)">
            <!-- Trunk -->
            <path d="M47 102 C46 80, 44 65, 47 48 C49 65, 54 80, 53 102 Z" fill="url(#trunk-grad)" />
            <!-- Branches -->
            <path d="M47 62 Q 32 50, 24 45 M 50 56 Q 64 46, 74 42 M 48 48 Q 42 34, 38 26 M 49 48 Q 56 34, 60 26" stroke="#5c2c0e" stroke-width="3" stroke-linecap="round" fill="none" />
            <!-- Foliage Crown -->
            <circle cx="50" cy="34" r="28" fill="url(#crown-grad)" opacity="0.94" />
            <circle cx="34" cy="40" r="18" fill="#16a34a" opacity="0.92" />
            <circle cx="66" cy="40" r="18" fill="#16a34a" opacity="0.92" />
            <circle cx="48" cy="24" r="18" fill="#4ade80" opacity="0.95" />

            <!-- Blossoms (Continuous opening from 0.58 to 0.78) -->
            <g id="blossoms-layer" opacity="0" transform="scale(0)">
              <circle cx="36" cy="32" r="3.5" fill="#fbcfe8" stroke="#f472b6" stroke-width="0.4" />
              <circle cx="64" cy="32" r="3.5" fill="#fbcfe8" stroke="#f472b6" stroke-width="0.4" />
              <circle cx="50" cy="20" r="3.8" fill="#fce7f3" stroke="#f472b6" stroke-width="0.4" />
              <circle cx="42" cy="42" r="3.2" fill="#fbcfe8" stroke="#f472b6" stroke-width="0.4" />
              <circle cx="58" cy="42" r="3.2" fill="#fbcfe8" stroke="#f472b6" stroke-width="0.4" />
            </g>

            <!-- Fruits (Continuous swelling from 0.72 to 1.00) -->
            <g id="fruits-layer" opacity="0" transform="scale(0)">
              <circle cx="34" cy="36" r="4.2" fill="url(#fruit-grad)" />
              <circle cx="66" cy="36" r="4.2" fill="url(#fruit-grad)" />
              <circle cx="50" cy="24" r="4.5" fill="url(#fruit-grad)" />
              <circle cx="40" cy="46" r="3.8" fill="url(#fruit-grad)" />
              <circle cx="60" cy="46" r="3.8" fill="url(#fruit-grad)" />
            </g>
          </g>
        </svg>
      </div>
    </div>

    <div class="timer-display" id="timer-display">25:00</div>

    <div class="progress-bar-container">
      <div class="progress-bar-fill" id="progress-bar-fill"></div>
    </div>

    <div class="duration-chips">
      <div class="duration-chip" onclick="setDuration(5)">5 min</div>
      <div class="duration-chip active" onclick="setDuration(25)">25 min</div>
      <div class="duration-chip" onclick="setDuration(45)">45 min</div>
      <div class="duration-chip" onclick="setDuration(60)">60 min</div>
    </div>

    <div class="controls">
      <button class="btn btn-secondary" onclick="resetTimer()">Reset</button>
      <button class="btn btn-primary" id="start-btn" onclick="toggleStart()">Start Focus</button>
    </div>

    <div class="preview-slider-wrap">
      <label for="scrubber">Botanical Growth Progress Scrubber:</label>
      <input type="range" id="scrubber" min="0" max="1" step="0.005" value="0" oninput="onScrub(this.value)" />
    </div>
  </div>

  <footer>
    Bio Zone Focus Forest &bull; 100% Offline Local Device Processing &bull; Sri Lankan A/L Mindfulness
  </footer>

  <script>
    // Pure Web Audio Synthesizer for 100% offline acoustic feedback
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    function playChime(freq, type, duration) {
      if (!audioCtx) return;
      if (audioCtx.state === 'suspended') audioCtx.resume();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = type || 'sine';
      osc.frequency.setValueAtTime(freq || 528, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + (duration || 0.8));
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + (duration || 0.8));
    }

    // Hermite smoothstep for monotonic C1 growth
    function smoothstep(min, max, val) {
      if (val <= min) return 0;
      if (val >= max) return 1;
      const t = (val - min) / (max - min);
      return t * t * (3 - 2 * t);
    }

    let durationMins = 25;
    let totalSeconds = 25 * 60;
    let elapsedSeconds = 0;
    let isRunning = false;
    let startTime = 0;
    let animFrame = null;

    function renderGrowth(p) {
      p = Math.max(0, Math.min(1, p));

      // 1. Shadow & Soil roots
      const shadow = document.getElementById('root-shadow');
      if (shadow) {
        shadow.setAttribute('rx', (26 + p * 16).toString());
        shadow.setAttribute('ry', (7 + p * 4).toString());
      }

      // 2. Seed presence (settles and transforms into root collar flare)
      const seed = document.getElementById('seed-entity');
      if (seed) {
        const seedPresence = Math.max(0, 1 - smoothstep(0.06, 0.30, p));
        const sinkY = smoothstep(0, 0.14, p) * 5;
        seed.style.opacity = seedPresence;
        seed.setAttribute('transform', 'translate(42, ' + (92 + sinkY) + ') scale(' + (1 - sinkY * 0.05) + ')');
      }

      // 3. Species Tree scaling (starts at p=0.05, monotonically expands)
      const treeGroup = document.getElementById('tree-canopy-group');
      if (treeGroup) {
        const hProg = smoothstep(0.05, 0.95, p);
        const wProg = smoothstep(0.09, 0.98, p);
        const sy = Math.pow(hProg, 0.82);
        const sx = Math.pow(wProg, 0.92);
        const opacity = smoothstep(0.04, 0.14, p);

        treeGroup.setAttribute('transform', 'scale(' + sx + ', ' + sy + ')');
        treeGroup.style.opacity = opacity;
      }

      // 4. Blossoms
      const blossoms = document.getElementById('blossoms-layer');
      if (blossoms) {
        const bProg = smoothstep(0.58, 0.78, p);
        const bYield = smoothstep(0.80, 0.98, p);
        const bScale = bProg * (1 - 0.32 * bYield);
        blossoms.setAttribute('transform', 'scale(' + bScale + ')');
        blossoms.style.opacity = smoothstep(0.58, 0.66, p);
      }

      // 5. Fruits
      const fruits = document.getElementById('fruits-layer');
      if (fruits) {
        const fProg = smoothstep(0.72, 1.00, p);
        const fScale = Math.pow(fProg, 0.92);
        fruits.setAttribute('transform', 'scale(' + fScale + ')');
        fruits.style.opacity = smoothstep(0.72, 0.80, p);
      }

      // 6. UI Stages
      const pill = document.getElementById('stage-pill');
      if (pill) {
        if (p < 0.15) pill.textContent = 'Planting Seed in Loam… 🌱 (' + Math.floor(p*100) + '%)';
        else if (p < 0.58) pill.textContent = 'Branching & Foliage Growth… 🌿 (' + Math.floor(p*100) + '%)';
        else if (p < 0.76) pill.textContent = 'Blossoming in Full Bloom… 🌸 (' + Math.floor(p*100) + '%)';
        else if (p < 0.98) pill.textContent = 'Bearing Ripe Fruits… 🍎 (' + Math.floor(p*100) + '%)';
        else pill.textContent = '100% Mature Fruiting Harvest! 🎉';
      }

      const fill = document.getElementById('progress-bar-fill');
      if (fill) fill.style.width = (p * 100) + '%';
    }

    function updateDisplay(secondsRemaining) {
      const mins = Math.floor(secondsRemaining / 60);
      const secs = secondsRemaining % 60;
      document.getElementById('timer-display').textContent =
        String(mins).padStart(2, '0') + ':' + String(secs).padStart(2, '0');
    }

    function tick() {
      if (!isRunning) return;
      const now = performance.now();
      const currentElapsed = Math.max(0, (now - startTime) / 1000);

      if (currentElapsed >= totalSeconds) {
        elapsedSeconds = totalSeconds;
        isRunning = false;
        document.getElementById('start-btn').textContent = 'Start Focus';
        updateDisplay(0);
        renderGrowth(1.0);
        document.getElementById('scrubber').value = 1.0;
        playChime(659, 'triangle', 1.5);
        setTimeout(() => playChime(880, 'sine', 2.0), 300);
      } else {
        elapsedSeconds = currentElapsed;
        const remaining = Math.max(0, Math.ceil(totalSeconds - elapsedSeconds));
        updateDisplay(remaining);
        const p = currentElapsed / totalSeconds;
        renderGrowth(p);
        document.getElementById('scrubber').value = p;
        animFrame = requestAnimationFrame(tick);
      }
    }

    function toggleStart() {
      if (isRunning) {
        // Pause
        isRunning = false;
        if (animFrame) cancelAnimationFrame(animFrame);
        document.getElementById('start-btn').textContent = 'Resume Focus';
        playChime(392, 'sine', 0.4);
      } else {
        // Start / Resume
        isRunning = true;
        startTime = performance.now() - elapsedSeconds * 1000;
        document.getElementById('start-btn').textContent = 'Pause';
        playChime(528, 'sine', 0.6);
        animFrame = requestAnimationFrame(tick);
      }
    }

    function resetTimer() {
      isRunning = false;
      if (animFrame) cancelAnimationFrame(animFrame);
      elapsedSeconds = 0;
      updateDisplay(totalSeconds);
      renderGrowth(0);
      document.getElementById('scrubber').value = 0;
      document.getElementById('start-btn').textContent = 'Start Focus';
    }

    function setDuration(mins) {
      if (isRunning) return;
      durationMins = mins;
      totalSeconds = mins * 60;
      elapsedSeconds = 0;
      document.querySelectorAll('.duration-chip').forEach(c => c.classList.remove('active'));
      event.target.classList.add('active');
      resetTimer();
    }

    function onScrub(val) {
      if (isRunning) {
        isRunning = false;
        if (animFrame) cancelAnimationFrame(animFrame);
        document.getElementById('start-btn').textContent = 'Resume Focus';
      }
      const p = parseFloat(val);
      elapsedSeconds = p * totalSeconds;
      const remaining = Math.max(0, Math.ceil(totalSeconds - elapsedSeconds));
      updateDisplay(remaining);
      renderGrowth(p);
    }

    // Initialize initial state
    renderGrowth(0);
    updateDisplay(totalSeconds);
  </script>
</body>
</html>`;
}

/**
 * Packages all forest files, offline viewer, data, and journal into a downloadable ZIP.
 */
export async function downloadForestZipPackage(state: AppState): Promise<void> {
  const zip = new JSZip();

  // 1. Raw JSON state
  zip.file('forest-data.json', JSON.stringify(state, null, 2));

  // 2. Standalone Offline 3D HTML Viewer
  zip.file('offline-forest.html', generateOfflineHtmlViewer(state));

  // 3. Standalone Offline Interactive Growth Timer
  zip.file('offline-growth-timer.html', generateOfflineGrowthTimerHtml(state));

  // 4. Markdown Study Journal
  zip.file('study-journal.md', generateStudyJournalMarkdown(state));

  // 5. Complete Botanical Species & Decoration Catalog
  zip.file(
    'species-catalog.json',
    JSON.stringify(
      {
        trees: Object.values(TREE_SPECIES_MAP),
        decorations: Object.values(DECORATIONS_MAP),
      },
      null,
      2
    )
  );

  // 6. Offline Manifest Metadata
  zip.file(
    'manifest.json',
    JSON.stringify(
      {
        app: 'Bio Zone Focus Forest',
        exportedAt: new Date().toISOString(),
        version: state.version,
        offlineCapable: true,
        stats: {
          coins: state.coins,
          xp: state.xp,
          level: state.level,
          treesCount: state.plantedObjects.filter((o) => o.kind === 'tree').length,
          decorationsCount: state.plantedObjects.filter((o) => o.kind === 'decoration').length,
          sessionsCount: state.sessions.length,
        },
      },
      null,
      2
    )
  );

  // 7. Readme Instructions
  zip.file(
    'README.txt',
    `BIO ZONE FOCUS FOREST — DOWNLOADABLE OFFLINE PACKAGE
======================================================
Thank you for downloading your personal focus sanctuary!

Files included in this package:
1. offline-forest.html:
   Double-click this file to open and interact with your 3D floating island
   in any web browser. It runs 100% offline with full 360-degree rotation,
   proportional assets, and zero internet or server dependencies.

2. offline-growth-timer.html:
   Double-click this file to run your standalone offline focus timer!
   Features the continuous, progressive botanical growth animation from planted
   seed in rich loam to full fruiting harvest, acoustic chimes, duration chips,
   and growth scrubber — completely offline in your browser.

3. forest-data.json:
   Your complete saved progress. You can re-import this file into the web app
   at any time to restore your trees, coins, decorations, and sessions.

4. study-journal.md:
   A clean markdown record of your study hours, A/L focus milestones, and
   harvest achievements.

5. species-catalog.json:
   Full biological descriptions, Latin botanical nomenclature, and fruiting
   profiles for all 20 Sri Lankan forest tree species and sanctuary decorations.

6. manifest.json:
   Application export metadata.

Stay focused and keep nurturing your biological sanctuary!
`
  );

  // Generate ZIP blob and trigger download
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `biozone-forest-complete-package-${new Date().toISOString().slice(0, 10)}.zip`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/**
 * Downloads a direct JSON backup
 */
export function downloadForestJsonBackup(state: AppState): void {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `biozone-forest-backup-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/**
 * Parses an uploaded JSON file to restore state
 */
export async function importForestStateFromFile(file: File): Promise<AppState> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const parsed = JSON.parse(text);
        if (!parsed || typeof parsed !== 'object') {
          throw new Error('Invalid JSON structure');
        }
        resolve(parsed);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsText(file);
  });
}
