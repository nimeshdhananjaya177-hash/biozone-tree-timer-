import { TREE_SPECIES_MAP } from '../data/trees';
import { DECORATIONS_MAP } from '../data/decorations';

export type AssetCategory = 'tree' | 'building' | 'structure' | 'wildlife' | 'flora';

export interface ProportionalAssetInfo {
  id: string;
  name: string;
  category: AssetCategory;
  pixelHeight: number; // Proportional base render size in pixels
  realWorldEstimate: string; // Real-world scale description
  relativeRatio: number; // Scale ratio relative to average 8m tree (~80px = 1.0)
}

// Proportional real-world specifications for all decorations, wildlife, and buildings
export const PROPORTIONAL_DECORATION_SPECS: Record<string, {
  pixelHeight: number;
  realWorldEstimate: string;
  category: AssetCategory;
}> = {
  // WILDLIFE (Proportionally small relative to towering trees)
  squirrel: {
    pixelHeight: 21,
    realWorldEstimate: '0.25m small squirrel',
    category: 'wildlife',
  },
  hedgehog: {
    pixelHeight: 20,
    realWorldEstimate: '0.22m little hedgehog',
    category: 'wildlife',
  },
  rabbit: {
    pixelHeight: 24,
    realWorldEstimate: '0.35m meadow rabbit',
    category: 'wildlife',
  },
  turtle: {
    pixelHeight: 22,
    realWorldEstimate: '0.30m pond turtle',
    category: 'wildlife',
  },
  owl: {
    pixelHeight: 32,
    realWorldEstimate: '0.60m wise owl',
    category: 'wildlife',
  },
  deer: {
    pixelHeight: 52,
    realWorldEstimate: '1.60m woodland stag',
    category: 'wildlife',
  },
  butterflies: {
    pixelHeight: 26,
    realWorldEstimate: 'Fluttering meadow swarm',
    category: 'wildlife',
  },
  fireflies: {
    pixelHeight: 24,
    realWorldEstimate: 'Bioluminescent sprites',
    category: 'wildlife',
  },

  // BUILDINGS & LARGE ARCHITECTURAL STRUCTURES (Prominent relative to trees)
  'log-cabin': {
    pixelHeight: 84,
    realWorldEstimate: '4.8m timber cabin dwelling',
    category: 'building',
  },
  'mushroom-house': {
    pixelHeight: 72,
    realWorldEstimate: '3.2m toadstool cottage',
    category: 'building',
  },
  waterfall: {
    pixelHeight: 76,
    realWorldEstimate: '3.8m alpine crag cascade',
    category: 'structure',
  },
  pond: {
    pixelHeight: 68,
    realWorldEstimate: '4.2m lotus reflection pond',
    category: 'structure',
  },
  'wooden-bridge': {
    pixelHeight: 62,
    realWorldEstimate: '3.5m arched timber footbridge',
    category: 'structure',
  },
  fountain: {
    pixelHeight: 54,
    realWorldEstimate: '2.1m tiered stone fountain',
    category: 'structure',
  },
  'rune-stone': {
    pixelHeight: 52,
    realWorldEstimate: '2.4m ancient runic monolith',
    category: 'structure',
  },

  // MEDIUM STRUCTURES & SANCTUARY FURNISHINGS
  swing: {
    pixelHeight: 46,
    realWorldEstimate: '2.0m suspended rope swing',
    category: 'structure',
  },
  birdhouse: {
    pixelHeight: 40,
    realWorldEstimate: '1.4m perched cedar birdhouse',
    category: 'structure',
  },
  bench: {
    pixelHeight: 38,
    realWorldEstimate: '0.8m carved timber bench',
    category: 'structure',
  },
  lantern: {
    pixelHeight: 36,
    realWorldEstimate: '1.2m garden post lantern',
    category: 'structure',
  },
  fence: {
    pixelHeight: 32,
    realWorldEstimate: '1.0m rustic cedar fence',
    category: 'structure',
  },
  'stone-path': {
    pixelHeight: 28,
    realWorldEstimate: 'River stone ground pavers',
    category: 'structure',
  },

  // FLORA & PRISMATIC ARTIFACTS
  'crystal-cyan': {
    pixelHeight: 44,
    realWorldEstimate: '1.6m focused cyan crystal',
    category: 'flora',
  },
  'crystal-purple': {
    pixelHeight: 44,
    realWorldEstimate: '1.6m mystic purple crystal',
    category: 'flora',
  },
  'crystal-amber': {
    pixelHeight: 44,
    realWorldEstimate: '1.6m solar amber crystal',
    category: 'flora',
  },
  'zen-stones': {
    pixelHeight: 32,
    realWorldEstimate: '0.7m stacked river cairn',
    category: 'flora',
  },
  'flower-patch': {
    pixelHeight: 28,
    realWorldEstimate: 'Low alpine wildflower turf',
    category: 'flora',
  },
  'mushrooms-glow': {
    pixelHeight: 25,
    realWorldEstimate: '0.3m bioluminescent fungi',
    category: 'flora',
  },
};

/**
 * Returns mathematically proportioned dimensions and real-world metadata
 * for any planted object (tree or decoration).
 */
export function getProportionalAssetInfo(kind: 'tree' | 'decoration', itemId: string): ProportionalAssetInfo {
  if (kind === 'tree') {
    const spec = TREE_SPECIES_MAP[itemId];
    const treeHeight = spec ? spec.height : 80;
    // Real-world tree heights range from 1.5m (Bonsai) to 30m+ (Ancient Redwood / World Tree)
    let estimate = '8m mature tree';
    if (itemId === 'bonsai') estimate = '1.2m miniature bonsai';
    else if (itemId === 'basic-sapling') estimate = '3.5m orchard sapling';
    else if (itemId === 'shrub') estimate = '2.2m blooming shrub';
    else if (itemId === 'willow') estimate = '10m weeping willow';
    else if (itemId === 'oak') estimate = '14m grand oak';
    else if (itemId === 'redwood') estimate = '28m ancient redwood';
    else if (itemId === 'world-tree') estimate = '35m mythical world tree';
    else if (spec) estimate = `~${Math.round(spec.height / 7)}m ${spec.name}`;

    return {
      id: itemId,
      name: spec ? spec.name : 'Forest Tree',
      category: 'tree',
      pixelHeight: Math.max(68, treeHeight),
      realWorldEstimate: estimate,
      relativeRatio: Number((treeHeight / 80).toFixed(2)),
    };
  }

  const spec = PROPORTIONAL_DECORATION_SPECS[itemId];
  const decor = DECORATIONS_MAP[itemId];
  const name = decor ? decor.name : itemId;

  if (spec) {
    return {
      id: itemId,
      name,
      category: spec.category,
      pixelHeight: spec.pixelHeight,
      realWorldEstimate: spec.realWorldEstimate,
      relativeRatio: Number((spec.pixelHeight / 80).toFixed(2)),
    };
  }

  // Fallback
  return {
    id: itemId,
    name,
    category: 'structure',
    pixelHeight: 40,
    realWorldEstimate: '1.2m sanctuary element',
    relativeRatio: 0.5,
  };
}
