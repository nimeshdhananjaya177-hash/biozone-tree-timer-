import { AppState, PlantedObject, FocusSession } from '../types';

const STORAGE_KEY = 'biozone-focus-forest-v1';

export const INITIAL_STATE: AppState = {
  version: 1,
  coins: 30, // welcoming starter balance
  xp: 0,
  level: 1,
  selectedDuration: 25,
  selectedTreeId: 'basic-sapling',
  unlockedTrees: ['basic-sapling'],
  purchasedDecorations: {},
  placedDecorationsCount: {},
  plantedObjects: [
    // Starter sapling in forest
    {
      id: 'starter-tree-1',
      kind: 'tree',
      itemId: 'basic-sapling',
      x: 0,
      y: 0,
      scale: 1,
      rotation: 0,
      plantedAt: Date.now() - 10000,
    }
  ],
  islandRadius: 240, // Base island radius in px
  sessions: [],
  soundEnabled: true,
};

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...INITIAL_STATE };

    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return { ...INITIAL_STATE };

    return {
      version: 1,
      coins: typeof parsed.coins === 'number' ? parsed.coins : INITIAL_STATE.coins,
      xp: typeof parsed.xp === 'number' ? parsed.xp : INITIAL_STATE.xp,
      level: typeof parsed.level === 'number' ? parsed.level : INITIAL_STATE.level,
      selectedDuration: typeof parsed.selectedDuration === 'number' ? parsed.selectedDuration : INITIAL_STATE.selectedDuration,
      selectedTreeId: typeof parsed.selectedTreeId === 'string' ? parsed.selectedTreeId : INITIAL_STATE.selectedTreeId,
      unlockedTrees: Array.isArray(parsed.unlockedTrees) && parsed.unlockedTrees.length > 0 ? parsed.unlockedTrees : ['basic-sapling'],
      purchasedDecorations: parsed.purchasedDecorations && typeof parsed.purchasedDecorations === 'object' ? parsed.purchasedDecorations : {},
      placedDecorationsCount: parsed.placedDecorationsCount && typeof parsed.placedDecorationsCount === 'object' ? parsed.placedDecorationsCount : {},
      plantedObjects: Array.isArray(parsed.plantedObjects) ? parsed.plantedObjects : INITIAL_STATE.plantedObjects,
      islandRadius: typeof parsed.islandRadius === 'number' && parsed.islandRadius >= 200 ? parsed.islandRadius : INITIAL_STATE.islandRadius,
      sessions: Array.isArray(parsed.sessions) ? parsed.sessions : [],
      soundEnabled: typeof parsed.soundEnabled === 'boolean' ? parsed.soundEnabled : true,
    };
  } catch (e) {
    console.warn('Failed to load BioZone Focus Forest state, falling back to safe defaults', e);
    return { ...INITIAL_STATE };
  }
}

export function saveState(state: AppState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error('Error saving state locally:', e);
  }
}

export function exportForestBackup(state: AppState): void {
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(state, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `biozone-forest-backup-${new Date().toISOString().slice(0, 10)}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

export function parseForestBackup(jsonString: string): AppState | null {
  try {
    const parsed = JSON.parse(jsonString);
    if (!parsed || typeof parsed !== 'object') return null;

    return {
      version: 1,
      coins: typeof parsed.coins === 'number' ? parsed.coins : 0,
      xp: typeof parsed.xp === 'number' ? parsed.xp : 0,
      level: typeof parsed.level === 'number' ? parsed.level : 1,
      selectedDuration: typeof parsed.selectedDuration === 'number' ? parsed.selectedDuration : 25,
      selectedTreeId: typeof parsed.selectedTreeId === 'string' ? parsed.selectedTreeId : 'basic-sapling',
      unlockedTrees: Array.isArray(parsed.unlockedTrees) ? parsed.unlockedTrees : ['basic-sapling'],
      purchasedDecorations: parsed.purchasedDecorations || {},
      placedDecorationsCount: parsed.placedDecorationsCount || {},
      plantedObjects: Array.isArray(parsed.plantedObjects) ? parsed.plantedObjects : [],
      islandRadius: typeof parsed.islandRadius === 'number' ? parsed.islandRadius : 240,
      sessions: Array.isArray(parsed.sessions) ? parsed.sessions : [],
      soundEnabled: typeof parsed.soundEnabled === 'boolean' ? parsed.soundEnabled : true,
    };
  } catch (e) {
    console.error('Failed to parse forest backup:', e);
    return null;
  }
}

// Global Diagnostics
if (typeof window !== 'undefined') {
  (window as unknown as { BioZoneDiagnostics: unknown }).BioZoneDiagnostics = {
    report: () => {
      const state = loadState();
      return {
        storageAvailable: true,
        version: state.version,
        islandRadius: state.islandRadius,
        plantedCount: state.plantedObjects.length,
        coins: state.coins,
        xp: state.xp,
        level: state.level,
        unlockedCount: state.unlockedTrees.length,
        sessionsCount: state.sessions.length,
        localTime: new Date().toLocaleTimeString(),
      };
    },
    log: () => {
      console.log('--- Bio Zone Focus Forest Diagnostics ---');
      console.table((window as unknown as { BioZoneDiagnostics: { report: () => unknown } }).BioZoneDiagnostics.report());
    }
  };
}
