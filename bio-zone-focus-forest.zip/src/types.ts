export type TimeOfDay = 'sunrise' | 'day' | 'sunset' | 'moonrise' | 'night';

export type NavTab = 'focus' | 'forest' | 'shop' | 'history';

export type TreeRarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary' | 'mythic';

export interface TreeSpecies {
  id: string;
  name: string;
  category: string;
  cost: number;
  rarity: TreeRarity;
  description: string;
  height: number;
}

export type DecorationCategory = 'wildlife' | 'structures' | 'flora';

export interface DecorationItem {
  id: string;
  name: string;
  category: DecorationCategory;
  cost: number;
  description: string;
}

export interface PlantedObject {
  id: string;
  kind: 'tree' | 'decoration';
  itemId: string;
  x: number; // -85 to +85 on circular island
  y: number; // -85 to +85 on circular island
  scale: number;
  rotation: number;
  plantedAt: number;
  isSprouting?: boolean;
}

export interface FocusSession {
  id: string;
  timestamp: number;
  dateStr: string;
  durationMinutes: number;
  coinsEarned: number;
  xpEarned: number;
  treeId: string;
}

export interface AppState {
  version: number;
  coins: number;
  xp: number;
  level: number;
  selectedDuration: number;
  selectedTreeId: string;
  unlockedTrees: string[];
  purchasedDecorations: Record<string, number>;
  placedDecorationsCount: Record<string, number>;
  plantedObjects: PlantedObject[];
  islandRadius: number; // expandable radius in visual pixels
  sessions: FocusSession[];
  soundEnabled: boolean;
}
