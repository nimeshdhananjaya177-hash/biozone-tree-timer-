import fs from 'fs';
import zlib from 'zlib';

function createPNG(width, height) {
  // Simple uncompressed or deflate-compressed PNG
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  function chunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const crcBuf = Buffer.alloc(4);
    
    // Calculate CRC32
    let c = 0xffffffff;
    const buf = Buffer.concat([typeBuf, data]);
    for (let i = 0; i < buf.length; i++) {
      c ^= buf[i];
      for (let k = 0; k < 8; k++) {
        c = (c >>> 1) ^ (c & 1 ? 0xedb88320 : 0);
      }
    }
    c ^= 0xffffffff;
    crcBuf.writeUInt32BE(c >>> 0, 0);

    return Buffer.concat([len, typeBuf, data, crcBuf]);
  }

  // IHDR
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr.writeUInt8(8, 8); // 8-bit depth
  ihdr.writeUInt8(6, 9); // RGBA color type
  ihdr.writeUInt8(0, 10); // compression
  ihdr.writeUInt8(0, 11); // filter
  ihdr.writeUInt8(0, 12); // interlace

  const ihdrChunk = chunk('IHDR', ihdr);

  // Raw image scanlines
  // Filter type 0 (None) for each scanline + (width * 4) bytes
  const rowSize = 1 + width * 4;
  const rawData = Buffer.alloc(rowSize * height);

  const cx = width / 2;
  const cy = height / 2;
  const rCircle = width * 0.44;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0; // Filter: none

    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist <= rCircle) {
        // Emerald brand circle with floating island gradient
        const t = (y / height);
        // Emerald green top to deep forest brown bottom
        if (t < 0.6) {
          // Lush forest emerald #10b981 to #059669
          rawData[pxOffset + 0] = Math.floor(16 + (5 - 16) * t); // R
          rawData[pxOffset + 1] = Math.floor(185 + (150 - 185) * t); // G
          rawData[pxOffset + 2] = Math.floor(129 + (105 - 129) * t); // B
          rawData[pxOffset + 3] = 255;
        } else {
          // Island loam earth
          rawData[pxOffset + 0] = Math.floor(120 - 40 * (t - 0.6));
          rawData[pxOffset + 1] = Math.floor(53 - 20 * (t - 0.6));
          rawData[pxOffset + 2] = Math.floor(15 - 10 * (t - 0.6));
          rawData[pxOffset + 3] = 255;
        }

        // Inner highlight
        if (Math.abs(y - height * 0.58) < 4 && Math.abs(dx) < rCircle * 0.7) {
          rawData[pxOffset + 0] = 52;
          rawData[pxOffset + 1] = 211;
          rawData[pxOffset + 2] = 153;
        }
      } else {
        // Transparent outside
        rawData[pxOffset + 0] = 0;
        rawData[pxOffset + 1] = 0;
        rawData[pxOffset + 2] = 0;
        rawData[pxOffset + 3] = 0;
      }
    }
  }

  const compressed = zlib.deflateSync(rawData);
  const idatChunk = chunk('IDAT', compressed);
  const iendChunk = chunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

fs.writeFileSync('public/pwa-192x192.png', createPNG(192, 192));
fs.writeFileSync('public/pwa-512x512.png', createPNG(512, 512));
fs.writeFileSync('public/pwa-maskable-512x512.png', createPNG(512, 512));
fs.writeFileSync('public/apple-touch-icon.png', createPNG(180, 180));
console.log('PWA icons created successfully');
