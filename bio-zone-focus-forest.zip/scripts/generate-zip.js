import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const indexHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Bio Zone Focus Forest</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>

  <!-- ==========================================================================
       HEADER & LIVE STATS BAR
       ========================================================================== -->
  <header>
    <div class="brand">
      <div class="logo-icon">🌳</div>
      <div>
        <h1>Bio Zone Focus Forest</h1>
        <p class="tagline">Offline Botanical Focus Sanctuary</p>
      </div>
    </div>

    <div class="header-right">
      <div class="stats-group">
        <div class="stat-pill" title="Harvest Coins">
          <span class="pill-icon">🪙</span>
          <span id="coinCount">45</span>
        </div>
        <div class="stat-pill" title="Experience Points">
          <span class="pill-icon">✨</span>
          <span id="xpCount">120 XP</span>
        </div>
        <div class="stat-pill" title="Total Planted Trees">
          <span class="pill-icon">🌱</span>
          <span id="treeCount">2 Trees</span>
        </div>
      </div>

      <div class="header-actions">
        <button id="soundToggleBtn" class="icon-btn" title="Toggle Sound" onclick="toggleSound()">
          <span id="soundIcon">🔊</span>
        </button>
        <button class="download-pkg-btn" onclick="openDownloadModal()">
          <span>📦</span>
          <span>Download Package</span>
        </button>
      </div>
    </div>
  </header>

  <!-- ==========================================================================
       NAVIGATION TABS
       ========================================================================== -->
  <nav class="nav-bar">
    <div class="nav-tabs">
      <button class="tab-btn active" id="tab-focus" onclick="switchTab('focus')">
        <span class="tab-icon">⏱️</span>
        <span>Growth Timer</span>
      </button>
      <button class="tab-btn" id="tab-forest" onclick="switchTab('forest')">
        <span class="tab-icon">🏝️</span>
        <span>My Forest Island</span>
      </button>
      <button class="tab-btn" id="tab-shop" onclick="switchTab('shop')">
        <span class="tab-icon">🛒</span>
        <span>Botanical Nursery</span>
      </button>
      <button class="tab-btn" id="tab-journal" onclick="switchTab('journal')">
        <span class="tab-icon">📜</span>
        <span>Study Journal</span>
      </button>
    </div>
  </nav>

  <!-- ==========================================================================
       MAIN SCREEN VIEWS
       ========================================================================== -->
  <main class="main-content">
    <!-- SCREEN 1: FOCUS & BOTANICAL GROWTH TIMER -->
    <section id="view-focus" class="screen-view active">
      <div class="focus-layout">
        <!-- Species Selector Pill -->
        <div class="tree-picker-bar">
          <label for="speciesSelect">Active Seed:</label>
          <select id="speciesSelect" onchange="onSelectTreeSpecies(this.value)">
            <!-- Options populated dynamically by app.js -->
          </select>
        </div>

        <!-- Glass Botanical Growth Terrarium Orb -->
        <div class="orb-wrapper">
          <div class="glass-orb" id="glassOrb">
            <!-- Ambient Growth Aura Glow -->
            <div class="aura-glow" id="orbAura"></div>
            <!-- Loam Bed Soil Base -->
            <div class="soil-bed">
              <div class="soil-texture"></div>
            </div>
            <!-- Procedural SVG Plant -->
            <div class="plant-artwork-stage" id="plantArtworkStage">
              <!-- SVG dynamically updated via requestAnimationFrame in app.js -->
            </div>
          </div>
        </div>

        <!-- Growth Stage Badge & Biological Status -->
        <div class="stage-badge-container">
          <span class="stage-badge" id="growthStageBadge">Stage 1: Seed in Loam</span>
        </div>
        <p class="stage-description" id="growthStageDesc">Anchor radicles sinking deep into mineral loam…</p>

        <!-- Monotonic Countdown Timer -->
        <div class="timer-digits" id="timerDigits">25:00</div>

        <!-- Duration Preset Steppers -->
        <div class="duration-chips" id="durationChips">
          <button class="chip" onclick="setPresetDuration(1, this)">1m (Demo)</button>
          <button class="chip" onclick="setPresetDuration(5, this)">5m</button>
          <button class="chip" onclick="setPresetDuration(15, this)">15m</button>
          <button class="chip active" onclick="setPresetDuration(25, this)">25m</button>
          <button class="chip" onclick="setPresetDuration(45, this)">45m</button>
          <button class="chip" onclick="setPresetDuration(60, this)">60m</button>
        </div>

        <!-- Primary Focus Session Controls -->
        <div class="timer-controls">
          <button class="ctrl-btn main-btn" id="startTimerBtn" onclick="handleTimerToggle()">
            <span id="startBtnIcon">🌱</span>
            <span id="startBtnText">Plant Seed & Focus</span>
          </button>
          <button class="ctrl-btn cancel-btn" id="cancelTimerBtn" onclick="handleCancelSession()" style="display: none;">
            <span>🥀</span>
            <span>Give Up</span>
          </button>
        </div>

        <!-- Interactive Scrubber (Preview full growth anytime) -->
        <div class="scrubber-bar">
          <label for="growthScrubber">Biology Scrubber Preview:</label>
          <input type="range" id="growthScrubber" min="0" max="1" step="0.01" value="0" oninput="onScrubGrowth(this.value)" />
        </div>
      </div>
    </section>

    <!-- SCREEN 2: 3D FLOATING ISLAND (360-DEGREE ROTATING) -->
    <section id="view-forest" class="screen-view">
      <div class="island-hud-bar">
        <div class="island-stat">
          <span class="hud-label">Diameter:</span>
          <span class="hud-val" id="islandDiameterVal">480m</span>
        </div>
        <div class="island-stat">
          <span class="hud-label">Flora & Wildlife:</span>
          <span class="hud-val" id="islandSpecimensVal">2 specimens</span>
        </div>
        <div class="island-controls">
          <button class="hud-action-btn" id="autoSpinBtn" onclick="toggleAutoSpin()">
            <span>🔄 Auto-Spin: ON</span>
          </button>
          <button class="hud-action-btn" onclick="resetIslandCamera()">
            <span>🧭 Reset View</span>
          </button>
        </div>
      </div>

      <!-- 3D Interactive Viewport -->
      <div class="viewport-3d-stage" id="islandViewport">
        <div class="camera-rig" id="cameraRig">
          <div class="floating-island-disk" id="islandDisk">
            <!-- Bedrock Foundation Layers (Visible in 3D pitch) -->
            <div class="bedrock-strata"></div>
            <div class="bedrock-core"></div>
            <!-- Fertile Turf Surface -->
            <div class="turf-surface">
              <div class="turf-path-ring"></div>
            </div>
            <!-- Pinned Billboard Layer -->
            <div id="plantedBillboardLayer"></div>
          </div>
        </div>
        <!-- Orbit Overlay Hint -->
        <div class="orbit-hint-pill">
          <span>↔ Click & drag left or right to rotate 360°</span>
        </div>
      </div>
    </section>

    <!-- SCREEN 3: BOTANICAL NURSERY & WILDLIFE SHOP -->
    <section id="view-shop" class="screen-view">
      <div class="shop-container">
        <div class="shop-header">
          <h2>Botanical Species & Forest Wildlife</h2>
          <p>Unlock new plant species, canopy shade, and friendly wildlife with earned study coins.</p>
        </div>

        <!-- Filter Sub-tabs -->
        <div class="shop-subtabs">
          <button class="subtab-btn active" onclick="filterShopCategory('all', this)">All Items</button>
          <button class="subtab-btn" onclick="filterShopCategory('trees', this)">Trees & Plants</button>
          <button class="subtab-btn" onclick="filterShopCategory('wildlife', this)">Forest Wildlife</button>
          <button class="subtab-btn" onclick="filterShopCategory('decor', this)">Garden Decor</button>
        </div>

        <div class="shop-grid" id="shopCatalogGrid">
          <!-- Populated dynamically by app.js -->
        </div>
      </div>
    </section>

    <!-- SCREEN 4: STUDY JOURNAL & SESSIONS HISTORY -->
    <section id="view-journal" class="screen-view">
      <div class="journal-container">
        <div class="journal-summary-cards">
          <div class="summary-card">
            <span class="card-icon">⏳</span>
            <div class="card-val" id="journalTotalMinutes">0m</div>
            <div class="card-label">Total Focus Time</div>
          </div>
          <div class="summary-card">
            <span class="card-icon">🌲</span>
            <div class="card-val" id="journalTotalTrees">0</div>
            <div class="card-label">Trees Harvested</div>
          </div>
          <div class="summary-card">
            <span class="card-icon">🔥</span>
            <div class="card-val" id="journalStreak">1 Day</div>
            <div class="card-label">Focus Streak</div>
          </div>
        </div>

        <div class="sessions-list-wrapper">
          <h3>Study Session History</h3>
          <div class="sessions-list" id="sessionsList">
            <!-- Populated dynamically by app.js -->
          </div>
        </div>
      </div>
    </section>
  </main>

  <!-- ==========================================================================
       CELEBRATION TOAST & MODALS
       ========================================================================== -->
  <div id="celebrationToast" class="toast-banner">
    <div class="toast-icon">✨</div>
    <div class="toast-body">
      <h4 id="toastTitle">Harvest Ready!</h4>
      <p id="toastMessage">Automatically planting in My Forest…</p>
    </div>
  </div>

  <!-- Download Package Modal -->
  <div id="downloadModal" class="modal-overlay" style="display: none;">
    <div class="modal-card">
      <div class="modal-header">
        <div class="modal-title-group">
          <span class="modal-icon">📦</span>
          <div>
            <h3>Download Offline Package</h3>
            <p>Export your full offline sanctuary files, code, and saved data</p>
          </div>
        </div>
        <button class="modal-close-btn" onclick="closeDownloadModal()">✕</button>
      </div>

      <div class="modal-body">
        <div class="package-feature-list">
          <div class="pkg-item">
            <span>📄</span>
            <div>
              <strong>index.html, styles.css, app.js</strong>
              <p>The complete modular website code ready for local editing or web hosting.</p>
            </div>
          </div>
          <div class="pkg-item">
            <span>💾</span>
            <div>
              <strong>forest-data.json</strong>
              <p>Your full sanctuary progress, planted specimens, and coins backup.</p>
            </div>
          </div>
          <div class="pkg-item">
            <span>🏝️</span>
            <div>
              <strong>offline-forest.html</strong>
              <p>Single-file 360° interactive 3D floating island viewer (runs without internet).</p>
            </div>
          </div>
          <div class="pkg-item">
            <span>⏱️</span>
            <div>
              <strong>offline-growth-timer.html</strong>
              <p>Standalone offline botanical growth timer with acoustic chimes.</p>
            </div>
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <button class="primary-download-btn" onclick="downloadCompleteZip()">
          <span>⬇️</span>
          <span>Download All Files (.ZIP)</span>
        </button>
      </div>
    </div>
  </div>

  <script src="app.js"></script>
</body>
</html>
`;

const stylesCss = `/* ==========================================================================
   BIO ZONE FOCUS FOREST — COMPLETE STYLESHEET
   ========================================================================== */
:root {
  --bg-gradient: radial-gradient(circle at 50% 15%, #ecfdf5 0%, #d1fae5 45%, #a7f3d0 100%);
  --surface-glass: rgba(255, 255, 255, 0.82);
  --surface-card: #ffffff;
  --primary-emerald: #059669;
  --primary-dark: #064e3b;
  --emerald-deep: #065f46;
  --emerald-accent: #10b981;
  --accent-amber: #d97706;
  --soil-brown: #78350f;
  --text-main: #064e3b;
  --text-muted: #047857;
  --border-light: rgba(16, 185, 129, 0.22);
  --radius-island: 190px;
}

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  user-select: none;
  -webkit-user-select: none;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  background: var(--bg-gradient);
  color: var(--text-main);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  overflow-x: hidden;
}

/* --- HEADER --- */
header {
  background: var(--surface-glass);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  border-bottom: 1px solid var(--border-light);
  padding: 12px 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: sticky;
  top: 0;
  z-index: 120;
}

.brand {
  display: flex;
  align-items: center;
  gap: 12px;
}

.logo-icon {
  font-size: 1.8rem;
  line-height: 1;
}

.brand h1 {
  font-size: 1.15rem;
  font-weight: 800;
  letter-spacing: -0.02em;
  color: var(--primary-dark);
}

.brand .tagline {
  font-size: 0.72rem;
  font-weight: 600;
  color: var(--text-muted);
}

.header-right {
  display: flex;
  align-items: center;
  gap: 14px;
}

.stats-group {
  display: flex;
  align-items: center;
  gap: 8px;
}

.stat-pill {
  background: #ffffff;
  padding: 6px 14px;
  border-radius: 9999px;
  border: 1px solid var(--border-light);
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 0.85rem;
  font-weight: 700;
  color: var(--primary-dark);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.icon-btn {
  background: #ffffff;
  border: 1px solid var(--border-light);
  border-radius: 12px;
  padding: 8px 10px;
  cursor: pointer;
  font-size: 0.95rem;
  transition: all 0.2s;
}

.icon-btn:hover {
  background: #ecfdf5;
}

.download-pkg-btn {
  background: linear-gradient(135deg, #059669 0%, #047857 100%);
  color: #ffffff;
  border: none;
  padding: 8px 16px;
  border-radius: 14px;
  font-size: 0.85rem;
  font-weight: 700;
  display: flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
  box-shadow: 0 3px 8px rgba(5, 150, 105, 0.25);
  transition: transform 0.1s, box-shadow 0.1s;
}

.download-pkg-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 5px 14px rgba(5, 150, 105, 0.35);
}

/* --- NAVIGATION TABS --- */
.nav-bar {
  display: flex;
  justify-content: center;
  padding: 14px 20px 4px;
}

.nav-tabs {
  display: flex;
  background: rgba(255, 255, 255, 0.6);
  padding: 4px;
  border-radius: 18px;
  border: 1px solid var(--border-light);
  gap: 4px;
  max-width: 600px;
  width: 100%;
}

.tab-btn {
  flex: 1;
  background: transparent;
  border: none;
  color: var(--text-muted);
  font-size: 0.86rem;
  font-weight: 700;
  padding: 10px 14px;
  border-radius: 14px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  transition: all 0.2s ease;
}

.tab-btn.active {
  background: var(--primary-emerald);
  color: #ffffff;
  box-shadow: 0 3px 10px rgba(5, 150, 105, 0.3);
}

/* --- MAIN CONTENT & VIEWS --- */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16px;
  max-width: 960px;
  margin: 0 auto;
  width: 100%;
}

.screen-view {
  display: none;
  width: 100%;
  flex-direction: column;
  align-items: center;
  animation: fadeIn 0.3s ease-out;
}

.screen-view.active {
  display: flex;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(6px); }
  to { opacity: 1; transform: translateY(0); }
}

/* --- 1. FOCUS SCREEN --- */
.focus-layout {
  background: var(--surface-glass);
  backdrop-filter: blur(16px);
  border: 1px solid rgba(255, 255, 255, 0.8);
  border-radius: 30px;
  padding: 24px;
  width: 100%;
  max-width: 440px;
  box-shadow: 0 20px 45px -15px rgba(6, 78, 59, 0.12);
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.tree-picker-bar {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
  font-size: 0.85rem;
  font-weight: 700;
  color: var(--primary-dark);
}

.tree-picker-bar select {
  background: #ffffff;
  border: 1px solid var(--border-light);
  padding: 6px 12px;
  border-radius: 12px;
  font-weight: 700;
  color: var(--primary-dark);
  cursor: pointer;
}

.orb-wrapper {
  position: relative;
  width: 220px;
  height: 220px;
  margin: 8px 0 12px;
}

.glass-orb {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  background: radial-gradient(circle at 40% 30%, #ffffff 0%, #ecfdf5 45%, #d1fae5 100%);
  box-shadow: inset 0 4px 14px rgba(255, 255, 255, 0.9),
              inset 0 -8px 24px rgba(5, 150, 105, 0.18),
              0 14px 32px rgba(6, 78, 59, 0.1);
  position: relative;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 2px solid rgba(255, 255, 255, 0.95);
}

.aura-glow {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.5s;
}

.aura-glow.active {
  opacity: 1;
  box-shadow: 0 0 28px rgba(52, 211, 153, 0.8), inset 0 0 16px rgba(253, 224, 71, 0.5);
  animation: auraPulse 2.2s infinite ease-in-out;
}

@keyframes auraPulse {
  0%, 100% { transform: scale(1); opacity: 0.7; }
  50% { transform: scale(1.04); opacity: 1; }
}

.soil-bed {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 40px;
  background: radial-gradient(ellipse at 50% 100%, #5d4037 0%, #3e2723 80%);
  border-radius: 50% 50% 0 0 / 16px 16px 0 0;
  box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.22);
}

.plant-artwork-stage {
  position: relative;
  width: 180px;
  height: 180px;
  z-index: 10;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  padding-bottom: 20px;
}

.stage-badge {
  font-size: 0.75rem;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--primary-emerald);
  background: #ecfdf5;
  border: 1px solid var(--border-light);
  padding: 4px 14px;
  border-radius: 9999px;
  display: inline-block;
  margin-bottom: 6px;
}

.stage-description {
  font-size: 0.86rem;
  font-weight: 600;
  color: var(--text-muted);
  margin-bottom: 12px;
  min-height: 22px;
}

.timer-digits {
  font-size: 2.85rem;
  font-weight: 800;
  letter-spacing: -0.04em;
  color: var(--primary-dark);
  font-variant-numeric: tabular-nums;
  margin: 4px 0 12px;
}

.duration-chips {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 6px;
  margin-bottom: 16px;
}

.chip {
  background: #ffffff;
  border: 1px solid var(--border-light);
  padding: 6px 12px;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 700;
  color: var(--text-main);
  cursor: pointer;
  transition: all 0.15s;
}

.chip.active {
  background: var(--primary-emerald);
  color: #ffffff;
  border-color: var(--primary-emerald);
}

.timer-controls {
  display: flex;
  gap: 10px;
  width: 100%;
}

.ctrl-btn {
  padding: 14px 20px;
  border-radius: 16px;
  font-size: 0.95rem;
  font-weight: 700;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: transform 0.1s;
}

.main-btn {
  flex: 1;
  background: linear-gradient(135deg, #059669 0%, #047857 100%);
  color: #ffffff;
  border: none;
  box-shadow: 0 4px 14px rgba(5, 150, 105, 0.35);
}

.main-btn:active {
  transform: scale(0.98);
}

.cancel-btn {
  background: #ffffff;
  color: #dc2626;
  border: 1px solid rgba(220, 38, 38, 0.25);
}

.scrubber-bar {
  margin-top: 16px;
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 4px;
  font-size: 0.75rem;
  font-weight: 600;
  color: var(--text-muted);
}

.scrubber-bar input[type="range"] {
  width: 100%;
  accent-color: var(--primary-emerald);
  cursor: pointer;
}

/* --- 2. 3D FLOATING ISLAND SCREEN --- */
.island-hud-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  max-width: 780px;
  background: var(--surface-glass);
  backdrop-filter: blur(12px);
  padding: 10px 18px;
  border-radius: 18px;
  border: 1px solid var(--border-light);
  box-shadow: 0 4px 14px rgba(6, 78, 59, 0.08);
  margin-bottom: 8px;
  font-size: 0.85rem;
}

.island-stat {
  display: flex;
  gap: 6px;
}

.hud-label {
  color: var(--text-muted);
  font-weight: 600;
}

.hud-val {
  color: var(--primary-dark);
  font-weight: 800;
}

.island-controls {
  display: flex;
  gap: 8px;
}

.hud-action-btn {
  background: #ffffff;
  border: 1px solid var(--border-light);
  padding: 6px 12px;
  border-radius: 10px;
  font-size: 0.78rem;
  font-weight: 700;
  color: var(--primary-dark);
  cursor: pointer;
}

.viewport-3d-stage {
  width: 100%;
  height: 520px;
  perspective: 1100px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: grab;
  touch-action: none;
}

.viewport-3d-stage:active {
  cursor: grabbing;
}

.camera-rig {
  transform-style: preserve-3d;
  transform: rotateX(46deg);
  transition: transform 0.05s ease-out;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.floating-island-disk {
  width: calc(var(--radius-island) * 2);
  height: calc(var(--radius-island) * 2);
  border-radius: 50%;
  position: relative;
  transform-style: preserve-3d;
  background: radial-gradient(circle at 40% 35%, #86efac 0%, #4ade80 40%, #22c55e 75%, #15803d 100%);
  box-shadow: inset 0 6px 16px rgba(255, 255, 255, 0.65),
              inset 0 -8px 24px rgba(20, 83, 45, 0.5),
              0 30px 65px rgba(6, 78, 59, 0.28);
}

.bedrock-strata {
  position: absolute;
  inset: -6px;
  border-radius: 50%;
  transform: translateZ(-25px);
  background: radial-gradient(ellipse at 45% 45%, #78350f 0%, #451a03 65%, #1c0a00 100%);
  box-shadow: 0 40px 60px rgba(0, 0, 0, 0.45);
  pointer-events: none;
}

.bedrock-core {
  position: absolute;
  inset: 20px;
  border-radius: 50%;
  transform: translateZ(-50px);
  background: #2a1103;
  box-shadow: 0 50px 80px rgba(0, 0, 0, 0.6);
  pointer-events: none;
}

.turf-surface {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  overflow: hidden;
  pointer-events: none;
}

.turf-path-ring {
  position: absolute;
  inset: 22px;
  border-radius: 50%;
  border: 1px dashed rgba(255, 255, 255, 0.4);
}

/* Placed billboard objects */
.island-billboard {
  position: absolute;
  transform-origin: bottom center;
  transform-style: preserve-3d;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  pointer-events: auto;
  cursor: pointer;
}

.auto-planted-pill {
  background: #064e3b;
  color: #a7f3d0;
  font-size: 10px;
  font-weight: 800;
  padding: 3px 8px;
  border-radius: 9999px;
  border: 1px solid #34d399;
  box-shadow: 0 4px 10px rgba(0,0,0,0.25);
  white-space: nowrap;
  margin-bottom: 4px;
  animation: badgeHop 1s infinite alternate ease-in-out;
}

@keyframes badgeHop {
  from { transform: translateY(0); }
  to { transform: translateY(-4px); }
}

@keyframes sproutGrow {
  0% { transform: scale(0.1) translateY(24px); opacity: 0; }
  60% { transform: scale(1.15) translateY(-6px); opacity: 1; }
  100% { transform: scale(1) translateY(0); opacity: 1; }
}

.sprouting-anim {
  animation: sproutGrow 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
}

.orbit-hint-pill {
  position: absolute;
  bottom: 12px;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(8px);
  padding: 6px 14px;
  border-radius: 9999px;
  font-size: 0.78rem;
  font-weight: 700;
  color: var(--text-muted);
  border: 1px solid var(--border-light);
  pointer-events: none;
}

/* --- 3. SHOP / NURSERY SCREEN --- */
.shop-container {
  width: 100%;
  max-width: 820px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.shop-header {
  text-align: center;
}

.shop-header h2 {
  font-size: 1.4rem;
  font-weight: 800;
  color: var(--primary-dark);
}

.shop-header p {
  font-size: 0.88rem;
  color: var(--text-muted);
}

.shop-subtabs {
  display: flex;
  justify-content: center;
  gap: 8px;
}

.subtab-btn {
  background: #ffffff;
  border: 1px solid var(--border-light);
  padding: 8px 16px;
  border-radius: 12px;
  font-size: 0.82rem;
  font-weight: 700;
  color: var(--primary-dark);
  cursor: pointer;
  transition: all 0.15s;
}

.subtab-btn.active {
  background: var(--primary-emerald);
  color: #ffffff;
  border-color: var(--primary-emerald);
}

.shop-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 14px;
}

.shop-card {
  background: var(--surface-card);
  border: 1px solid var(--border-light);
  border-radius: 20px;
  padding: 16px;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  box-shadow: 0 4px 12px rgba(6, 78, 59, 0.05);
  transition: transform 0.15s, box-shadow 0.15s;
}

.shop-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(6, 78, 59, 0.1);
}

.card-preview {
  width: 90px;
  height: 90px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 8px;
}

.card-title {
  font-size: 0.95rem;
  font-weight: 800;
  color: var(--primary-dark);
  margin-bottom: 2px;
}

.card-desc {
  font-size: 0.75rem;
  color: var(--text-muted);
  margin-bottom: 12px;
  line-height: 1.3;
}

.buy-btn {
  width: 100%;
  background: linear-gradient(135deg, #059669 0%, #047857 100%);
  color: white;
  border: none;
  padding: 8px 14px;
  border-radius: 12px;
  font-size: 0.82rem;
  font-weight: 700;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}

.buy-btn.unlocked {
  background: #ecfdf5;
  color: var(--primary-emerald);
  border: 1px solid var(--border-light);
  cursor: default;
}

/* --- 4. STUDY JOURNAL SCREEN --- */
.journal-container {
  width: 100%;
  max-width: 680px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.journal-summary-cards {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
}

.summary-card {
  background: var(--surface-glass);
  backdrop-filter: blur(12px);
  border: 1px solid var(--border-light);
  border-radius: 18px;
  padding: 16px;
  text-align: center;
  box-shadow: 0 4px 12px rgba(6, 78, 59, 0.05);
}

.card-icon {
  font-size: 1.5rem;
  margin-bottom: 4px;
}

.card-val {
  font-size: 1.3rem;
  font-weight: 800;
  color: var(--primary-dark);
}

.card-label {
  font-size: 0.75rem;
  font-weight: 600;
  color: var(--text-muted);
}

.sessions-list-wrapper {
  background: var(--surface-card);
  border: 1px solid var(--border-light);
  border-radius: 20px;
  padding: 20px;
  box-shadow: 0 4px 14px rgba(6, 78, 59, 0.05);
}

.sessions-list-wrapper h3 {
  font-size: 1rem;
  font-weight: 800;
  color: var(--primary-dark);
  margin-bottom: 12px;
}

.sessions-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  max-height: 320px;
  overflow-y: auto;
}

.session-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #f0fdf4;
  border: 1px solid rgba(16, 185, 129, 0.15);
  padding: 10px 14px;
  border-radius: 12px;
  font-size: 0.85rem;
}

.session-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.session-tree-icon {
  font-size: 1.2rem;
}

.session-name {
  font-weight: 700;
  color: var(--primary-dark);
}

.session-time {
  font-size: 0.72rem;
  color: var(--text-muted);
}

.session-reward {
  font-weight: 800;
  color: var(--primary-emerald);
}

/* --- TOAST NOTIFICATION --- */
.toast-banner {
  position: fixed;
  bottom: 24px;
  left: 50%;
  transform: translateX(-50%) translateY(120px);
  background: #064e3b;
  color: #ffffff;
  padding: 14px 22px;
  border-radius: 18px;
  box-shadow: 0 12px 30px rgba(0, 0, 0, 0.28);
  border: 1px solid rgba(52, 211, 153, 0.4);
  display: flex;
  align-items: center;
  gap: 12px;
  z-index: 1000;
  transition: transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
  pointer-events: none;
}

.toast-banner.show {
  transform: translateX(-50%) translateY(0);
}

.toast-icon {
  font-size: 1.5rem;
}

.toast-body h4 {
  font-size: 0.92rem;
  font-weight: 800;
  margin-bottom: 2px;
}

.toast-body p {
  font-size: 0.8rem;
  opacity: 0.9;
}

/* --- MODAL DIALOG --- */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.55);
  backdrop-filter: blur(4px);
  z-index: 200;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
  animation: fadeIn 0.2s;
}

.modal-card {
  background: #ffffff;
  border-radius: 24px;
  width: 100%;
  max-width: 480px;
  padding: 24px;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  border-bottom: 1px solid var(--border-light);
  padding-bottom: 12px;
}

.modal-title-group {
  display: flex;
  gap: 10px;
}

.modal-icon {
  font-size: 1.6rem;
}

.modal-header h3 {
  font-size: 1.1rem;
  font-weight: 800;
  color: var(--primary-dark);
}

.modal-header p {
  font-size: 0.78rem;
  color: var(--text-muted);
}

.modal-close-btn {
  background: none;
  border: none;
  font-size: 1.2rem;
  cursor: pointer;
  color: var(--text-muted);
}

.package-feature-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.pkg-item {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  background: #f0fdf4;
  padding: 10px 14px;
  border-radius: 12px;
  font-size: 0.82rem;
}

.pkg-item span {
  font-size: 1.3rem;
}

.pkg-item strong {
  display: block;
  color: var(--primary-dark);
}

.pkg-item p {
  color: var(--text-muted);
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
}

.primary-download-btn {
  width: 100%;
  background: linear-gradient(135deg, #059669 0%, #047857 100%);
  color: white;
  border: none;
  padding: 12px 20px;
  border-radius: 14px;
  font-size: 0.95rem;
  font-weight: 700;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  box-shadow: 0 4px 12px rgba(5, 150, 105, 0.3);
}
`;

const appJs = `/* ==========================================================================
   BIO ZONE FOCUS FOREST — COMPLETE JAVASCRIPT LOGIC ENGINE
   ========================================================================== */

/* --------------------------------------------------------------------------
   1. BOTANICAL SPECIES & DECORATIONS CATALOG (ORIGINAL DATA)
   -------------------------------------------------------------------------- */
const TREE_SPECIES = [
  {
    id: 'basic-sapling',
    name: 'Basic Sapling',
    category: 'Starter',
    cost: 0,
    rarity: 'common',
    description: 'A delicate young sapling just rooted in fresh loam, symbolizing your first study commitment.',
    svgType: 'sapling',
    color: '#15803d'
  },
  {
    id: 'evergreen-pine',
    name: 'Evergreen Pine',
    category: 'Conifer',
    cost: 20,
    rarity: 'common',
    description: 'A hardy, fragrant pine that stands resilient through long study nights.',
    svgType: 'pine',
    color: '#047857'
  },
  {
    id: 'bushy-shrub',
    name: 'Bushy Shrub',
    category: 'Shrub',
    cost: 25,
    rarity: 'common',
    description: 'A lush rounded shrub with dense clusters of emerald leaves.',
    svgType: 'shrub',
    color: '#16a34a'
  },
  {
    id: 'young-birch',
    name: 'Young Birch',
    category: 'Deciduous',
    cost: 35,
    rarity: 'uncommon',
    description: 'Slender silver bark with fluttering mint-green foliage.',
    svgType: 'birch',
    color: '#10b981'
  },
  {
    id: 'forest-elm',
    name: 'Forest Elm',
    category: 'Deciduous',
    cost: 45,
    rarity: 'uncommon',
    description: 'An elegant vase-shaped canopy offering calm shade and steady energy.',
    svgType: 'elm',
    color: '#059669'
  },
  {
    id: 'sprawling-oak',
    name: 'Sprawling Oak',
    category: 'Broadleaf',
    cost: 55,
    rarity: 'uncommon',
    description: 'Wide, sturdy boughs that represent deep comprehension and memory.',
    svgType: 'oak',
    color: '#15803d'
  },
  {
    id: 'cherry-sakura',
    name: 'Flowering Cherry',
    category: 'Flowering',
    cost: 75,
    rarity: 'rare',
    description: 'Soft pink sakura petals that bloom when study focus reaches its peak.',
    svgType: 'cherry',
    color: '#f43f5e'
  },
  {
    id: 'golden-maple',
    name: 'Golden Maple',
    category: 'Deciduous',
    cost: 90,
    rarity: 'rare',
    description: 'Radiant amber and crimson leaves that celebrate fruitful study milestones.',
    svgType: 'maple',
    color: '#d97706'
  },
  {
    id: 'weeping-willow',
    name: 'Weeping Willow',
    category: 'Waterfront',
    cost: 110,
    rarity: 'rare',
    description: 'Flowing verdant tendrils that sway gently, instilling quiet calm.',
    svgType: 'willow',
    color: '#059669'
  },
  {
    id: 'ancient-redwood',
    name: 'Ancient Redwood',
    category: 'Conifer',
    cost: 160,
    rarity: 'legendary',
    description: 'Colossal titan with deeply furrowed cinnamon bark and sky-touching canopy.',
    svgType: 'redwood',
    color: '#b91c1c'
  },
  {
    id: 'mystic-baobab',
    name: 'Mystic Baobab',
    category: 'Exotic',
    cost: 200,
    rarity: 'legendary',
    description: 'Ancient tree of life whose massive trunk stores infinite reservoir of knowledge.',
    svgType: 'baobab',
    color: '#b45309'
  }
];

const DECORATIONS = [
  { id: 'squirrel', name: 'Squirrel', category: 'wildlife', cost: 15, description: 'Inquisitive visitor holding an acorn.' },
  { id: 'rabbit', name: 'White Rabbit', category: 'wildlife', cost: 18, description: 'Gentle dweller hopping among clover.' },
  { id: 'hedgehog', name: 'Little Hedgehog', category: 'wildlife', cost: 20, description: 'Cozy companion resting in the grass.' },
  { id: 'owl', name: 'Wise Owl', category: 'wildlife', cost: 30, description: 'Perched sentinel watching over quiet midnight hours.' },
  { id: 'deer', name: 'Graceful Deer', category: 'wildlife', cost: 45, description: 'Majestic golden-spotted fawn bringing serene focus.' },
  { id: 'turtle', name: 'Pond Turtle', category: 'wildlife', cost: 22, description: 'Patient reminder that steady pacing wins.' },
  { id: 'butterflies', name: 'Meadow Butterflies', category: 'wildlife', cost: 25, description: 'Azure and gold wings dancing over flowers.' },
  { id: 'lantern', name: 'Stone Lantern', category: 'decor', cost: 35, description: 'Carved granite pagoda lantern casting warm glow.' },
  { id: 'bench', name: 'Teak Zen Bench', category: 'decor', cost: 40, description: 'A quiet resting place under the trees.' }
];

/* --------------------------------------------------------------------------
   2. STATE MANAGEMENT & LOCAL STORAGE
   -------------------------------------------------------------------------- */
const STORAGE_KEY = 'biozone-focus-forest-v1';

let state = {
  version: 1,
  coins: 45,
  xp: 120,
  level: 2,
  selectedTreeId: 'basic-sapling',
  unlockedTrees: ['basic-sapling'],
  purchasedDecorations: {},
  plantedObjects: [
    { id: 'starter-1', kind: 'tree', itemId: 'basic-sapling', x: -45, y: -25, progress: 1.0 },
    { id: 'starter-2', kind: 'tree', itemId: 'evergreen-pine', x: 40, y: 30, progress: 1.0 }
  ],
  sessions: [
    { id: 'sess-1', durationMinutes: 25, treeId: 'basic-sapling', timestamp: Date.now() - 3600000 * 24 }
  ],
  soundEnabled: true
};

function loadSavedState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      state = { ...state, ...parsed };
    }
  } catch (e) {
    console.warn('Using fresh default state');
  }
  syncStatsHeader();
}

function saveStateLocally() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {}
  syncStatsHeader();
}

function syncStatsHeader() {
  document.getElementById('coinCount').textContent = state.coins;
  document.getElementById('xpCount').textContent = \`\${state.xp} XP\`;
  const treeCount = state.plantedObjects.filter(o => o.kind === 'tree').length;
  document.getElementById('treeCount').textContent = \`\${treeCount} Trees\`;
  document.getElementById('islandDiameterVal').textContent = \`\${380 + treeCount * 14}m\`;
  document.getElementById('islandSpecimensVal').textContent = \`\${state.plantedObjects.length} specimens\`;
}

/* --------------------------------------------------------------------------
   3. PROCEDURAL ACOUSTIC AUDIO SYNTHESIZER
   -------------------------------------------------------------------------- */
let audioCtx = null;

function getAudioContext() {
  if (!audioCtx) {
    const AudioClass = window.AudioContext || window.webkitAudioContext;
    audioCtx = new AudioClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

function toggleSound() {
  state.soundEnabled = !state.soundEnabled;
  document.getElementById('soundIcon').textContent = state.soundEnabled ? '🔊' : '🔇';
  saveStateLocally();
}

const audio = {
  playStart() {
    if (!state.soundEnabled) return;
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(329.63, now);
    osc.frequency.exponentialRampToValueAtTime(659.25, now + 0.35);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.4);
  },

  playFanfare() {
    if (!state.soundEnabled) return;
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    [523.25, 659.25, 783.99, 1046.50].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.12);
      gain.gain.setValueAtTime(0.25, now + i * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.12 + 0.65);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + i * 0.12);
      osc.stop(now + i * 0.12 + 0.65);
    });
  },

  playPlantThud() {
    if (!state.soundEnabled) return;
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(70, now + 0.28);
    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.3);
  }
};

/* --------------------------------------------------------------------------
   4. BOTANICAL GROWTH ENGINE & CONTINUOUS TIMER
   -------------------------------------------------------------------------- */
let selectedDurationMins = 25;
let timerTotalSeconds = 25 * 60;
let elapsedSeconds = 0;
let isTimerRunning = false;
let startPerfTime = null;
let animReqId = null;
let newlyPlantedObjId = null;

function setPresetDuration(mins, btnElement) {
  if (isTimerRunning) return;
  selectedDurationMins = mins;
  timerTotalSeconds = mins * 60;
  elapsedSeconds = 0;
  document.querySelectorAll('#durationChips .chip').forEach(c => c.classList.remove('active'));
  btnElement.classList.add('active');
  updateTimerText();
  renderPlantSvg(0);
}

function updateTimerText() {
  const rem = Math.max(0, timerTotalSeconds - elapsedSeconds);
  const m = Math.floor(rem / 60);
  const s = Math.floor(rem % 60);
  document.getElementById('timerDigits').textContent = \`\${String(m).padStart(2, '0')}:\${String(s).padStart(2, '0')}\`;
}

function handleTimerToggle() {
  if (!isTimerRunning) {
    startSession();
  }
}

function startSession() {
  isTimerRunning = true;
  startPerfTime = performance.now() - (elapsedSeconds * 1000);
  audio.playStart();

  document.getElementById('startTimerBtn').style.display = 'none';
  document.getElementById('cancelTimerBtn').style.display = 'flex';
  document.getElementById('durationChips').style.pointerEvents = 'none';
  document.getElementById('durationChips').style.opacity = '0.5';

  animReqId = requestAnimationFrame(onFrameTick);
}

function onFrameTick(now) {
  if (!isTimerRunning) return;

  elapsedSeconds = Math.min(timerTotalSeconds, (now - startPerfTime) / 1000);
  const progress = Math.min(1.0, elapsedSeconds / timerTotalSeconds);

  updateTimerText();
  renderPlantSvg(progress);
  updateGrowthLabel(progress);
  document.getElementById('growthScrubber').value = progress;

  if (elapsedSeconds >= timerTotalSeconds) {
    onSessionCompleted();
  } else {
    animReqId = requestAnimationFrame(onFrameTick);
  }
}

function handleCancelSession() {
  isTimerRunning = false;
  cancelAnimationFrame(animReqId);
  elapsedSeconds = 0;
  updateTimerText();
  renderPlantSvg(0);
  updateGrowthLabel(0);
  document.getElementById('growthScrubber').value = 0;

  document.getElementById('startTimerBtn').style.display = 'flex';
  document.getElementById('cancelTimerBtn').style.display = 'none';
  document.getElementById('durationChips').style.pointerEvents = 'auto';
  document.getElementById('durationChips').style.opacity = '1.0';
  document.getElementById('growthStageDesc').textContent = 'Session rested. Ready to anchor a fresh seed.';
}

function onScrubGrowth(val) {
  if (isTimerRunning) return;
  const p = parseFloat(val);
  renderPlantSvg(p);
  updateGrowthLabel(p);
}

/* Mathematical smoothstep curve */
function smoothstep(min, max, value) {
  const x = Math.max(0, Math.min(1, (value - min) / (max - min)));
  return x * x * (3 - 2 * x);
}

function updateGrowthLabel(progress) {
  const badge = document.getElementById('growthStageBadge');
  const desc = document.getElementById('growthStageDesc');
  const aura = document.getElementById('orbAura');

  if (progress <= 0.05) {
    badge.textContent = 'Stage 1: Seed in Loam';
    desc.textContent = 'Anchor radicles sinking deep into mineral loam…';
    aura.classList.remove('active');
  } else if (progress < 0.35) {
    badge.textContent = 'Stage 2: Cotyledon Sprout';
    desc.textContent = 'Tender emerald shoot stretching toward the sunlight…';
    aura.classList.remove('active');
  } else if (progress < 0.70) {
    badge.textContent = 'Stage 3: Sapling Branching';
    desc.textContent = 'Lignifying stem expanding primary branches…';
    aura.classList.remove('active');
  } else if (progress < 0.95) {
    badge.textContent = 'Stage 4: Blossom Flush';
    desc.textContent = 'Canopy opening into fragrant floral bloom…';
    aura.classList.remove('active');
  } else {
    badge.textContent = 'Stage 5: Mature Harvest';
    desc.textContent = 'Full harvest matured! Auto-planting in My Forest… 🌳';
    aura.classList.add('active');
  }
}

function renderPlantSvg(progress) {
  const stage = document.getElementById('plantArtworkStage');
  const activeTree = TREE_SPECIES.find(t => t.id === state.selectedTreeId) || TREE_SPECIES[0];

  const seedFade = 1.0 - smoothstep(0.02, 0.18, progress);
  const sproutGrowth = smoothstep(0.08, 0.38, progress);
  const trunkGrowth = smoothstep(0.30, 0.75, progress);
  const foliageScale = smoothstep(0.45, 0.90, progress);
  const fruitScale = smoothstep(0.78, 1.0, progress);

  const trunkHeight = 14 + (trunkGrowth * 56);
  const crownRadius = 14 + (foliageScale * 38);

  stage.innerHTML = \`
    <svg width="180" height="180" viewBox="0 0 180 180" style="overflow: visible;">
      <!-- Seed in Soil -->
      \${seedFade > 0.01 ? \`
        <g opacity="\${seedFade}">
          <ellipse cx="90" cy="148" rx="6.5" ry="4.5" fill="#78350f" stroke="#451a03" stroke-width="1.5"/>
          <path d="M 90 148 Q 90 156 88 162" stroke="#d97706" stroke-width="1.5" fill="none" opacity="\${1 - seedFade}"/>
        </g>
      \` : ''}

      <!-- Stem & Branches -->
      \${sproutGrowth > 0.01 ? \`
        <path d="M 90 148 Q \${90 + Math.sin(progress * 4) * 3} \${148 - trunkHeight * 0.5} 90 \${148 - trunkHeight}"
              stroke="#78350f" stroke-width="\${3 + (1 - sproutGrowth) * 2}" stroke-linecap="round" fill="none"/>
        <path d="M 90 \${148 - trunkHeight * 0.6} Q 74 \${140 - trunkHeight * 0.7} 70 \${148 - trunkHeight * 0.8}"
              stroke="#78350f" stroke-width="2.5" stroke-linecap="round" fill="none" opacity="\${foliageScale}"/>
        <path d="M 90 \${148 - trunkHeight * 0.75} Q 106 \${140 - trunkHeight * 0.85} 110 \${148 - trunkHeight * 0.9}"
              stroke="#78350f" stroke-width="2.5" stroke-linecap="round" fill="none" opacity="\${foliageScale}"/>
      \` : ''}

      <!-- Foliage Canopy -->
      \${foliageScale > 0.02 ? \`
        <g transform="translate(90, \${148 - trunkHeight}) scale(\${foliageScale})" opacity="\${foliageScale}">
          <circle cx="-16" cy="-10" r="\${crownRadius * 0.7}" fill="\${activeTree.color}" opacity="0.88"/>
          <circle cx="16" cy="-12" r="\${crownRadius * 0.72}" fill="\${activeTree.color}" opacity="0.92"/>
          <circle cx="0" cy="-24" r="\${crownRadius * 0.85}" fill="#22c55e" opacity="0.95"/>
          <circle cx="0" cy="-14" r="\${crownRadius * 0.65}" fill="#86efac" opacity="0.6"/>
        </g>
      \` : ''}

      <!-- Blossoms & Ripened Fruits -->
      \${fruitScale > 0.05 ? \`
        <g transform="translate(90, \${148 - trunkHeight})" opacity="\${fruitScale}">
          <circle cx="-18" cy="-18" r="\${4 * fruitScale}" fill="#ef4444" stroke="#b91c1c" stroke-width="0.8"/>
          <circle cx="14" cy="-22" r="\${4.5 * fruitScale}" fill="#ef4444" stroke="#b91c1c" stroke-width="0.8"/>
          <circle cx="-2" cy="-34" r="\${4 * fruitScale}" fill="#f59e0b" stroke="#d97706" stroke-width="0.8"/>
          <circle cx="2" cy="-8" r="\${3.5 * fruitScale}" fill="#ef4444" stroke="#b91c1c" stroke-width="0.8"/>
        </g>
      \` : ''}
    </svg>
  \`;
}

/* --------------------------------------------------------------------------
   5. HANDS-FREE AUTO-PLANTING ENGINE
   -------------------------------------------------------------------------- */
function onSessionCompleted() {
  isTimerRunning = false;
  cancelAnimationFrame(animReqId);

  audio.playFanfare();

  const coinsEarned = selectedDurationMins + 5;
  const xpEarned = selectedDurationMins * 2;
  state.coins += coinsEarned;
  state.xp += xpEarned;

  // Record session
  state.sessions.unshift({
    id: \`sess-\${Date.now()}\`,
    durationMinutes: selectedDurationMins,
    treeId: state.selectedTreeId,
    timestamp: Date.now()
  });

  // Sunflower phyllotaxis algorithm for organic non-overlapping island placement
  const count = state.plantedObjects.length;
  const angle = count * 137.5 * (Math.PI / 180);
  const dist = 32 + Math.sqrt(count) * 20;
  const x = Math.cos(angle) * Math.min(dist, 115);
  const y = Math.sin(angle) * Math.min(dist, 115);

  const newId = \`tree-\${Date.now()}\`;
  newlyPlantedObjId = newId;

  state.plantedObjects.push({
    id: newId,
    kind: 'tree',
    itemId: state.selectedTreeId,
    x: Math.round(x),
    y: Math.round(y),
    progress: 1.0,
    isNew: true
  });

  saveStateLocally();

  showCelebrationToast('🍎 Mature Harvest Ready!', 'Auto-planting directly on your Floating Island…');

  // Hands-free automated transition directly to My Forest
  setTimeout(() => {
    switchTab('forest');
    renderIslandBillboards();
    audio.playPlantThud();
    showCelebrationToast('🌳 Planted on Floating Island!', \`+\${coinsEarned} Coins • +\${xpEarned} XP added to your sanctuary.\`);
  }, 1200);

  setTimeout(() => {
    elapsedSeconds = 0;
    updateTimerText();
    renderPlantSvg(0);
    updateGrowthLabel(0);
    document.getElementById('startTimerBtn').style.display = 'flex';
    document.getElementById('cancelTimerBtn').style.display = 'none';
    document.getElementById('durationChips').style.pointerEvents = 'auto';
    document.getElementById('durationChips').style.opacity = '1.0';
  }, 2200);
}

function showCelebrationToast(title, msg) {
  const toast = document.getElementById('celebrationToast');
  document.getElementById('toastTitle').textContent = title;
  document.getElementById('toastMessage').textContent = msg;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 4500);
}

/* --------------------------------------------------------------------------
   6. 3D 360-DEGREE ROTATING FLOATING ISLAND
   -------------------------------------------------------------------------- */
let rotZ = 35;
let isDraggingIsland = false;
let lastX = 0;
let autoSpinActive = true;

const viewport = document.getElementById('islandViewport');
const islandDisk = document.getElementById('islandDisk');

function update3DRotation() {
  islandDisk.style.transform = \`rotateZ(\${rotZ}deg)\`;

  // Billboard counter-rotation: locks orientation directly towards user without distorting
  const billboards = document.querySelectorAll('.island-billboard');
  billboards.forEach(el => {
    el.style.transform = \`translate(-50%, -100%) rotateZ(\${-rotZ}deg) rotateX(-46deg)\`;
  });
}

viewport.addEventListener('pointerdown', (e) => {
  isDraggingIsland = true;
  lastX = e.clientX;
  viewport.setPointerCapture(e.pointerId);
});

window.addEventListener('pointermove', (e) => {
  if (!isDraggingIsland) return;
  const deltaX = e.clientX - lastX;
  lastX = e.clientX;
  rotZ = (rotZ + deltaX * 0.75) % 360;
  update3DRotation();
});

window.addEventListener('pointerup', () => { isDraggingIsland = false; });
window.addEventListener('pointercancel', () => { isDraggingIsland = false; });

function toggleAutoSpin() {
  autoSpinActive = !autoSpinActive;
  document.getElementById('autoSpinBtn').textContent = autoSpinActive ? '🔄 Auto-Spin: ON' : '⏸️ Auto-Spin: OFF';
}

function resetIslandCamera() {
  rotZ = 35;
  update3DRotation();
}

function renderIslandBillboards() {
  const layer = document.getElementById('plantedBillboardLayer');
  layer.innerHTML = '';

  state.plantedObjects.forEach(obj => {
    const isTree = obj.kind === 'tree';
    const treeSpecies = TREE_SPECIES.find(t => t.id === obj.itemId) || TREE_SPECIES[0];
    const isRecent = obj.id === newlyPlantedObjId;

    const anchor = document.createElement('div');
    anchor.className = \`island-billboard \${isRecent ? 'sprouting-anim' : ''}\`;
    anchor.style.left = \`calc(50% + \${obj.x}px)\`;
    anchor.style.top = \`calc(50% + \${obj.y}px)\`;

    anchor.innerHTML = \`
      \${isRecent ? '<div class="auto-planted-pill">✨ Auto-Planted!</div>' : ''}
      <svg width="60" height="74" viewBox="0 0 60 74" style="filter: drop-shadow(0 4px 6px rgba(0,0,0,0.25));">
        \${isTree ? \`
          <path d="M 30 70 L 30 42" stroke="#5d4037" stroke-width="4.5" stroke-linecap="round"/>
          <circle cx="30" cy="32" r="22" fill="\${treeSpecies.color}"/>
          <circle cx="20" cy="30" r="16" fill="#16a34a"/>
          <circle cx="38" cy="28" r="16" fill="#22c55e"/>
          <circle cx="30" cy="20" r="14" fill="#86efac" opacity="0.75"/>
          <!-- Blossoms -->
          <circle cx="26" cy="28" r="2.5" fill="#f43f5e"/>
          <circle cx="34" cy="32" r="2.5" fill="#f43f5e"/>
        \` : \`
          <circle cx="30" cy="46" r="18" fill="#d97706"/>
          <path d="M 18 46 L 30 20 L 42 46 Z" fill="#b45309"/>
        \`}
      </svg>
    \`;

    layer.appendChild(anchor);
  });

  update3DRotation();
}

function startIslandLoop() {
  function loop() {
    if (autoSpinActive && !isDraggingIsland) {
      rotZ = (rotZ + 0.2) % 360;
      update3DRotation();
    }
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
}

/* --------------------------------------------------------------------------
   7. BOTANICAL NURSERY & SHOP
   -------------------------------------------------------------------------- */
function populateSpeciesDropdown() {
  const select = document.getElementById('speciesSelect');
  select.innerHTML = '';
  state.unlockedTrees.forEach(id => {
    const t = TREE_SPECIES.find(x => x.id === id);
    if (t) {
      const opt = document.createElement('option');
      opt.value = t.id;
      opt.textContent = \`\${t.name} (\${t.category})\`;
      if (t.id === state.selectedTreeId) opt.selected = true;
      select.appendChild(opt);
    }
  });
}

function onSelectTreeSpecies(id) {
  state.selectedTreeId = id;
  saveStateLocally();
  renderPlantSvg(0);
}

function renderShopGrid(filter = 'all') {
  const grid = document.getElementById('shopCatalogGrid');
  grid.innerHTML = '';

  if (filter === 'all' || filter === 'trees') {
    TREE_SPECIES.forEach(tree => {
      const isUnlocked = state.unlockedTrees.includes(tree.id);
      const card = document.createElement('div');
      card.className = 'shop-card';
      card.innerHTML = \`
        <div class="card-preview">
          <svg width="70" height="70" viewBox="0 0 60 60">
            <path d="M 30 55 L 30 35" stroke="#78350f" stroke-width="4" stroke-linecap="round"/>
            <circle cx="30" cy="26" r="20" fill="\${tree.color}"/>
            <circle cx="22" cy="24" r="14" fill="#22c55e"/>
            <circle cx="38" cy="22" r="14" fill="#16a34a"/>
          </svg>
        </div>
        <div class="card-title">\${tree.name}</div>
        <div class="card-desc">\${tree.description}</div>
        <button class="buy-btn \${isUnlocked ? 'unlocked' : ''}" onclick="buyTree('\${tree.id}', \${tree.cost})">
          \${isUnlocked ? '✓ Unlocked' : \`🪙 \${tree.cost} Coins\`}
        </button>
      \`;
      grid.appendChild(card);
    });
  }

  if (filter === 'all' || filter === 'wildlife' || filter === 'decor') {
    DECORATIONS.forEach(item => {
      if (filter === 'wildlife' && item.category !== 'wildlife') return;
      if (filter === 'decor' && item.category !== 'decor') return;
      const isOwned = Boolean(state.purchasedDecorations[item.id]);
      const card = document.createElement('div');
      card.className = 'shop-card';
      card.innerHTML = \`
        <div class="card-preview">
          <span style="font-size: 2.2rem;">\${item.category === 'wildlife' ? '🐿️' : '🏮'}</span>
        </div>
        <div class="card-title">\${item.name}</div>
        <div class="card-desc">\${item.description}</div>
        <button class="buy-btn \${isOwned ? 'unlocked' : ''}" onclick="buyDecoration('\${item.id}', \${item.cost})">
          \${isOwned ? '✓ Planted' : \`🪙 \${item.cost} Coins\`}
        </button>
      \`;
      grid.appendChild(card);
    });
  }
}

function filterShopCategory(cat, btn) {
  document.querySelectorAll('.subtab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderShopGrid(cat);
}

function buyTree(treeId, cost) {
  if (state.unlockedTrees.includes(treeId)) {
    state.selectedTreeId = treeId;
    saveStateLocally();
    populateSpeciesDropdown();
    renderPlantSvg(0);
    showCelebrationToast('Active Tree Selected', \`Now planting \${treeId}\`);
    return;
  }
  if (state.coins < cost) {
    showCelebrationToast('Need More Coins', \`Complete more focus sessions to earn coins!\`);
    return;
  }
  state.coins -= cost;
  state.unlockedTrees.push(treeId);
  state.selectedTreeId = treeId;
  saveStateLocally();
  populateSpeciesDropdown();
  renderShopGrid();
  showCelebrationToast('Tree Unlocked! 🌱', \`You can now plant this specimen.\`);
}

function buyDecoration(itemId, cost) {
  if (state.purchasedDecorations[itemId]) return;
  if (state.coins < cost) {
    showCelebrationToast('Need More Coins', \`Focus to earn coins for forest decor!\`);
    return;
  }
  state.coins -= cost;
  state.purchasedDecorations[itemId] = true;

  // Place decoration on island
  const count = state.plantedObjects.length;
  const angle = count * 137.5 * (Math.PI / 180);
  const dist = 30 + Math.sqrt(count) * 20;
  state.plantedObjects.push({
    id: \`decor-\${Date.now()}\`,
    kind: 'decoration',
    itemId: itemId,
    x: Math.round(Math.cos(angle) * Math.min(dist, 110)),
    y: Math.round(Math.sin(angle) * Math.min(dist, 110)),
    progress: 1.0
  });

  saveStateLocally();
  renderShopGrid();
  renderIslandBillboards();
  showCelebrationToast('Decoration Added! 🏮', 'Placed in your floating sanctuary.');
}

/* --------------------------------------------------------------------------
   8. STUDY JOURNAL
   -------------------------------------------------------------------------- */
function renderStudyJournal() {
  const totalMins = state.sessions.reduce((acc, s) => acc + s.durationMinutes, 0);
  document.getElementById('journalTotalMinutes').textContent = \`\${totalMins}m\`;
  document.getElementById('journalTotalTrees').textContent = state.sessions.length;

  const list = document.getElementById('sessionsList');
  list.innerHTML = '';

  if (state.sessions.length === 0) {
    list.innerHTML = '<p style="font-size: 0.85rem; color: #047857;">No study sessions logged yet. Start a focus timer to harvest your first tree!</p>';
    return;
  }

  state.sessions.forEach(s => {
    const t = TREE_SPECIES.find(x => x.id === s.treeId) || TREE_SPECIES[0];
    const row = document.createElement('div');
    row.className = 'session-row';
    row.innerHTML = \`
      <div class="session-info">
        <span class="session-tree-icon">🌳</span>
        <div>
          <div class="session-name">\${t.name} — \${s.durationMinutes} minutes</div>
          <div class="session-time">\${new Date(s.timestamp).toLocaleDateString()} at \${new Date(s.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
        </div>
      </div>
      <div class="session-reward">+\${s.durationMinutes + 5} 🪙</div>
    \`;
    list.appendChild(row);
  });
}

/* --------------------------------------------------------------------------
   9. TAB SWITCHING
   -------------------------------------------------------------------------- */
function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.screen-view').forEach(s => s.classList.remove('active'));

  document.getElementById(\`tab-\${tab}\`).classList.add('active');
  document.getElementById(\`view-\${tab}\`).classList.add('active');

  if (tab === 'forest') {
    renderIslandBillboards();
  } else if (tab === 'shop') {
    renderShopGrid();
  } else if (tab === 'journal') {
    renderStudyJournal();
  }
}

/* --------------------------------------------------------------------------
   10. MODAL & PACKAGE DOWNLOAD
   -------------------------------------------------------------------------- */
function openDownloadModal() {
  document.getElementById('downloadModal').style.display = 'flex';
}

function closeDownloadModal() {
  document.getElementById('downloadModal').style.display = 'none';
}

function downloadCompleteZip() {
  // Direct link to the generated zip archive
  window.location.href = '/bio-zone-focus-forest.zip';
  closeDownloadModal();
}

/* --- INITIALIZATION --- */
window.addEventListener('DOMContentLoaded', () => {
  loadSavedState();
  populateSpeciesDropdown();
  updateTimerText();
  renderPlantSvg(0);
  renderIslandBillboards();
  startIslandLoop();
});
`;

async function main() {
  const zip = new JSZip();

  // Add the 3 files
  zip.file('index.html', indexHtml);
  zip.file('styles.css', stylesCss);
  zip.file('app.js', appJs);

  // Add metadata & documentation
  zip.file('README.txt', `BIO ZONE FOCUS FOREST — COMPLETE SOURCE CODE
===================================================
Thank you for downloading your Bio Zone Focus Forest application!

This ZIP package contains the complete, fully separated and standalone code:
1. index.html: Semantic HTML layout for all 4 screens (Focus Timer, 3D Floating Island, Species Nursery, Study Journal).
2. styles.css: Complete responsive styles, CSS 3D transforms, and keyframe animations.
3. app.js: Complete JavaScript logic, full botanical species catalog, Web Audio synthesizer, and LocalStorage persistence.

HOW TO RUN:
Just double-click index.html in any modern browser. No server, node.js, or internet connection required!
`);

  zip.file('forest-data.json', JSON.stringify({
    version: 1,
    coins: 45,
    xp: 120,
    level: 2,
    selectedTreeId: 'basic-sapling',
    unlockedTrees: ['basic-sapling'],
    purchasedDecorations: {},
    plantedObjects: [
      { id: 'starter-1', kind: 'tree', itemId: 'basic-sapling', x: -45, y: -25, progress: 1.0 },
      { id: 'starter-2', kind: 'tree', itemId: 'evergreen-pine', x: 40, y: 30, progress: 1.0 }
    ],
    sessions: [
      { id: 'sess-1', durationMinutes: 25, treeId: 'basic-sapling', timestamp: Date.now() - 3600000 * 24 }
    ],
    soundEnabled: true
  }, null, 2));

  zip.file('manifest.json', JSON.stringify({
    name: 'Bio Zone Focus Forest',
    version: '1.0.0',
    description: 'Offline 3D Botanical Sanctuary & Focus Timer'
  }, null, 2));

  const content = await zip.generateAsync({ type: 'nodebuffer' });
  const outPath = path.join(process.cwd(), 'public', 'bio-zone-focus-forest.zip');
  fs.writeFileSync(outPath, content);
  console.log('Successfully wrote ZIP to', outPath);
}

main().catch(console.error);
